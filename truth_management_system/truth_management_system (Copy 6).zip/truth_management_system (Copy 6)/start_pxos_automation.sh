#!/bin/bash

# This script robustly starts the pxOS backend server and the autonomous agent.

# --- 1. Start the backend server in the background ---

echo "Starting pxOS backend server..."
# Ensure any previous background uvicorn processes are killed to prevent port conflicts
killall uvicorn 2>/dev/null
# Start uvicorn, redirecting all output to a log file, and run in background
uvicorn backend.main:app --host 0.0.0.0 --port 8000 &> server_output.log &
SERVER_PID=$!
echo "Backend server started with PID $SERVER_PID. Output logged to server_output.log"

# --- 2. Wait for the server to become responsive ---

echo "Waiting for backend server to become responsive (polling /docs endpoint)..."
SERVER_READY=false
for i in {1..30}; do # Try for up to 30 seconds
    if curl -sf http://127.0.0.1:8000/docs > /dev/null 2>&1; then
        SERVER_READY=true
        break
    fi
    echo -n "."
    sleep 1
done

if [ "$SERVER_READY" = "true" ]; then
    echo -e "\nServer started successfully!"
else
    echo -e "\nError: Server did not become responsive in time. Check server_output.log for errors."
    exit 1
fi

# --- 3. Run the autonomous agent ---

echo "Starting the autonomous improvement agent..."
# Ensure agent's virtual environment is activated and script is run
background_agent/venv/bin/python background_agent/automated_agent.py &

echo "Autonomous agent started. It will log its cycles in this terminal."
echo "Press Ctrl+C to stop the agent (and then optionally kill the server manually if needed: kill $SERVER_PID)."
