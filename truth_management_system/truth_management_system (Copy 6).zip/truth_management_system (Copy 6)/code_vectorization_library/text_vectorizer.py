# code_vectorization_library/text_vectorizer.py
import numpy as np
import re
from typing import List, Dict, Any
from collections import defaultdict

class TextVectorizer:
    """
    Converts text content into numerical vector embeddings using a Bag-of-Words approach.
    """

    def __init__(self, vocabulary: Dict[str, int] = None):
        """
        Initializes the TextVectorizer.

        Args:
            vocabulary: An optional pre-built vocabulary (word -> index mapping).
                        If None, vocabulary must be built using build_vocabulary().
        """
        self.vocabulary = vocabulary if vocabulary is not None else {}
        self.vector_size = len(self.vocabulary)

    def build_vocabulary(self, corpus: List[str]):
        """
        Builds a vocabulary from a list of text documents.

        Args:
            corpus: A list of text strings (documents).
        """
        word_counts = defaultdict(int)
        for doc in corpus:
            words = re.findall(r'\b\w+\b', doc.lower())
            for word in words:
                word_counts[word] += 1

        # Build vocabulary from words that appear at least once (or more for filtering)
        current_idx = 0
        sorted_words = sorted(word_counts.keys()) # Ensure consistent ordering
        for word in sorted_words:
            if word not in self.vocabulary: # Add new words if not already in pre-built vocab
                self.vocabulary[word] = current_idx
                current_idx += 1
        self.vector_size = len(self.vocabulary)
        print(f"Text vocabulary built with {self.vector_size} unique terms.")

    def vectorize_text(self, text: str) -> np.ndarray:
        """
        Converts a single text string into a numerical vector using Bag-of-Words.

        Args:
            text: The input text string.

        Returns:
            A numpy array representing the vector embedding of the text.
        """
        if not self.vocabulary:
            raise ValueError("Vocabulary has not been built. Call build_vocabulary() first.")

        vector = np.zeros(self.vector_size, dtype=np.float32)
        words = re.findall(r'\b\w+\b', text.lower())

        for word in words:
            if word in self.vocabulary:
                vector[self.vocabulary[word]] += 1.0 # Simple word count

        return vector

# Example Usage
if __name__ == "__main__":
    example_texts = [
        "we are building this program to honor our creator",
        "AI's purpose is to seek and integrate knowledge ethically and efficiently for the betterment of all",
        "AI and humans collaborate to achieve symbiotic progress and mutual understanding, respecting shared values",
        "Python is a great programming language",
        "Python code can be vectorized for AI",
    ]

    text_vectorizer = TextVectorizer()

    print("--- Building Vocabulary ---")
    text_vectorizer.build_vocabulary(example_texts)
    print("Vocabulary:", text_vectorizer.vocabulary)
    print("Vector size:", text_vectorizer.vector_size)

    print("\n--- Vectorizing Texts ---")
    for i, text in enumerate(example_texts):
        vector = text_vectorizer.vectorize_text(text)
        print(f"Text {i+1}: '{text[:30]}...' -> Vector shape: {vector.shape}, Sum: {np.sum(vector)}")
        # print(vector) # Uncomment to see the full vector

    new_text = "The AI will honor its creator with ethical programming."
    new_text_vector = text_vectorizer.vectorize_text(new_text)
    print(f"\nNew text: '{new_text}' -> Vector shape: {new_text_vector.shape}, Sum: {np.sum(new_text_vector)}")

    unseen_word_text = "This text contains a new word like 'blockchain'."
    unseen_word_vector = text_vectorizer.vectorize_text(unseen_word_text)
    print(f"\nText with unseen word: '{unseen_word_text}' -> Vector shape: {unseen_word_vector.shape}, Sum: {np.sum(unseen_word_vector)}")
    print("Note: 'blockchain' is not in the vocabulary, so its count is 0.")
