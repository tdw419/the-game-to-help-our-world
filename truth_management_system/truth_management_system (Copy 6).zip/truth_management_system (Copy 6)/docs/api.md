# API Documentation

## User Management

### Register User
- **Endpoint**: `/user/register`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "username": "string",
    "password": "string"
  }
  ```
- **Response**:
  ```json
  {
    "message": "User registered successfully"
  }
  ```

### Login User
- **Endpoint**: `/user/login`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "username": "string",
    "password": "string"
  }
  ```
- **Response**:
  ```json
  {
    "message": "Login successful for username",
    "token": "token_username"
  }
  ```

## Resource Management

### Allocate Resource
- **Endpoint**: `/resource/allocate`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "type": "string",
    "allocated_to": "string"
  }
  ```
- **Response**:
  ```json
  {
    "message": "Resource allocated successfully",
    "resource_id": integer
  }
  ```

### List Resources
- **Endpoint**: `/resource/list`
- **Method**: `GET`
- **Response**:
  ```json
  {
    "resources": [
      {
        "resource_id": integer,
        "type": "string",
        "allocated_to": "string"
      }
    ]
  }
  ```

## Truth Management

### Propose Truth
- **Endpoint**: `/truth/propose`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "content": "string"
  }
  ```
- **Response**:
  ```json
  {
    "message": "Truth proposed successfully",
    "truth_id": integer
  }
  ```

### List Truths
- **Endpoint**: `/truth/list`
- **Method**: `GET`
- **Response**:
  ```json
  {
    "truths": [
      {
        "id": integer,
        "content": "string",
        "status": "string"
      }
    ]
  }
  ```

### Edit Truth
- **Endpoint**: `/truth/{id}`
- **Method**: `PUT`
- **Request Body**:
  ```json
  {
    "content": "string"
  }
  ```
- **Response**:
  ```json
  {
    "message": "Truth edited successfully"
  }
  ```

### Delete Truth
- **Endpoint**: `/truth/{id}`
- **Method**: `DELETE`
- **Response**:
  ```json
  {
    "message": "Truth deleted successfully"
  }
  ```

## LLM Management

### Generate Text
- **Endpoint**: `/llm/generate`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "prompt": "string"
  }
  ```
- **Response**:
  ```json
  {
    "generated_text": "string"
  }
  ```

### Think
- **Endpoint**: `/abstraction/think`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "query": "string"
  }
  ```
- **Response**:
  ```json
  {
    "status": "success",
    "result": "string"
  }
  ```

## Caching

### List Cached Truths
- **Endpoint**: `/truth/list_cached`
- **Method**: `GET`
- **Response**:
  ```json
  {
    "truths": [
      {
        "id": integer,
        "content": "string",
        "status": "string"
      }
    ]
  }
  ```
