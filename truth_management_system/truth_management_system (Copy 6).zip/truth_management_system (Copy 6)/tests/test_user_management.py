import pytest
from src.user_management import UserManagement

@pytest.fixture
def user_management():
    return UserManagement()

def test_register_user(user_management):
    assert user_management.registerUser("user1", "password1") == "User registered successfully"
    with pytest.raises(Exception) as e:
        user_management.registerUser("user1", "password2")
    assert str(e.value) == "User already exists"

def test_login_user(user_management):
    user_management.registerUser("user1", "password1")
    assert user_management.loginUser("user1", "password1") == "Login successful for user1"
    with pytest.raises(Exception) as e:
        user_management.loginUser("user1", "wrong_password")
    assert str(e.value) == "Invalid credentials"
