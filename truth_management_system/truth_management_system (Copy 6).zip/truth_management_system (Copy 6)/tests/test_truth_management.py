import pytest
from src.components.TruthManagement import TruthManagement

@pytest.fixture
def truth_management():
    return TruthManagement()

def test_propose_truth(truth_management):
    truth_management.handleProposeTruth("This is a new truth.")
    assert len(truth_management.truths) == 1
    assert truth_management.truths[0].content == "This is a new truth."

def test_list_truths(truth_management):
    truth_management.handleProposeTruth("This is a new truth.")
    truths = truth_management.listTruths()
    assert len(truths) == 1
    assert truths[0].content == "This is a new truth."
