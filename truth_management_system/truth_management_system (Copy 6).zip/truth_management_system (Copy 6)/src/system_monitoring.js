const openai = require('openai');
openai.apiKey = 'your-openai-api-key';

class SystemMonitoring {
  constructor() {
    this.truthsDb = {};
  }

  async generateText(prompt) {
    const response = await openai.Completion.create({
      engine: "text-davinci-003",
      prompt,
      maxTokens: 50
    });
    return response.choices[0].text.trim();
  }

  async proposeTruth(content) {
    const truthId = Object.keys(this.truthsDb).length + 1;
    this.truthsDb[truthId] = { content, status: "proposed" };
    return `Truth ${truthId} proposed successfully`;
  }

  async listTruths() {
    return Object.values(this.truthsDb);
  }
}

module.exports = SystemMonitoring;
