import React, { createContext, useContext, useEffect, useCallback, ReactNode } from 'react';

interface UsageEvent {
  componentName: string;
  eventType: 'mount' | 'unmount' | 'interaction';
  timestamp: string;
  details?: Record<string, any>;
}

interface UsageTrackerContextType {
  trackUsage: (componentName: string, eventType: UsageEvent['eventType'], details?: Record<string, any>) => void;
}

const UsageTrackerContext = createContext<UsageTrackerContextType | undefined>(undefined);

interface UsageTrackerProviderProps {
  children: ReactNode;
}

export const UsageTrackerProvider: React.FC<UsageTrackerProviderProps> = ({ children }) => {
  const reportUsage = useCallback(async (event: UsageEvent) => {
    // console.log('Reporting usage:', event); // For debugging
    try {
      // TODO: Replace with actual backend endpoint when created (Todo #3)
      await fetch('/api/usage/frontend', { // Assuming /api/usage/frontend will be the endpoint
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Add authorization token if necessary, e.g., 'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify(event),
      });
    } catch (error) {
      console.error('Failed to report usage:', error);
    }
  }, []);

  const trackUsage = useCallback((componentName: string, eventType: UsageEvent['eventType'], details?: Record<string, any>) => {
    reportUsage({
      componentName,
      eventType,
      timestamp: new Date().toISOString(),
      details,
    });
  }, [reportUsage]);

  return (
    <UsageTrackerContext.Provider value={{ trackUsage }}>
      {children}
    </UsageTrackerContext.Provider>
  );
};

export const useUsageTracker = () => {
  const context = useContext(UsageTrackerContext);
  if (context === undefined) {
    throw new Error('useUsageTracker must be used within a UsageTrackerProvider');
  }
  return context;
};

// Example hook for tracking component mounts/unmounts
export const useComponentUsage = (componentName: string, details?: Record<string, any>) => {
  const { trackUsage } = useUsageTracker();

  useEffect(() => {
    trackUsage(componentName, 'mount', details);
    return () => {
      trackUsage(componentName, 'unmount', details);
    };
  }, [componentName, details, trackUsage]);
};
