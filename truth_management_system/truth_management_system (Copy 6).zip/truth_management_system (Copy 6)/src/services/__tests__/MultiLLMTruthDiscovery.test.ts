// src/services/__tests__/MultiLLMTruthDiscovery.test.ts
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { MultiLLMTruthAssessment, SystematicInterrogationResult, MultiLLMTruthDiscovery, multiLLMTruthDiscovery } from '../MultiLLMTruthDiscovery';
import { llmChainService, LLMConfidenceSignal } from '../LLMChainService';
import { truthApiClient } from '@/api/TruthApiClient';

// Mock dependencies
vi.mock('../LLMChainService', () => ({
  llmChainService: {
    executeChain: vi.fn(),
  },
  LLMConfidenceSignal: vi.fn(), // Mock the interface if needed, but usually just types
}));

vi.mock('@/api/TruthApiClient', () => ({
  truthApiClient: {
    proposeTruth: vi.fn(),
  },
}));

describe('MultiLLMTruthDiscovery', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  // Helper for mock signals
  const createMockSignals = (confidences: number[]): LLMConfidenceSignal[] => {
    return confidences.map((conf, i) => ({
      model: `model-${i}`,
      confidence: conf,
      reasoning: `Reasoning for model-${i}. Related to concept A.`,
      evidence: [`Evidence ${i}`],
      uncertainty_areas: conf < 0.6 ? [`Uncertainty ${i}`] : [],
      extraction_timestamp: new Date().toISOString(),
    }));
  };

  describe('assessTruthWithMultipleModels', () => {
    it('should correctly aggregate confidence and determine consensus', async () => {
      const mockSignals = createMockSignals([0.9, 0.8, 0.7]);
      (llmChainService.executeChain as vi.Mock).mockResolvedValue(mockSignals);

      const content = 'Test truth content.';
      const assessment = await multiLLMTruthDiscovery.assessTruthWithMultipleModels(content);

      expect(llmChainService.executeChain).toHaveBeenCalledWith(content);
      expect(assessment.content).toBe(content);
      expect(assessment.confidence_signals).toEqual(mockSignals);
      expect(assessment.aggregated_confidence).toBeCloseTo(0.8); // (0.9*1.2 + 0.8*1.1 + 0.7*1) / (1.2 + 1.1 + 1)
      expect(assessment.consensus_level).toBe('high');
      expect(assessment.suggested_relationships).toContain('concept A');
      expect(assessment.validation_recommendations).toEqual([]);
    });

                it('should identify conflicting consensus', async () => {
                // Adjusted mock signals to ensure variance > 0.2 to trigger 'conflicting'
                const mockSignals = createMockSignals([1.0, 0.0, 0.0]); // avg=0.333, variance=0.222
                (llmChainService.executeChain as vi.Mock).mockResolvedValue(mockSignals);
          
                const assessment = await multiLLMTruthDiscovery.assessTruthWithMultipleModels('Conflicting truth.');
                expect(assessment.consensus_level).toBe('conflicting');
                expect(assessment.validation_recommendations).toContain('Multiple models show conflicting confidence levels. Requires human verification.');
              });    
        it('should recommend additional evidence for low confidence signals', async () => {
          const mockSignals = createMockSignals([0.4, 0.3, 0.5]);
          (llmChainService.executeChain as vi.Mock).mockResolvedValue(mockSignals);
    
          const assessment = await multiLLMTruthDiscovery.assessTruthWithMultipleModels('Low confidence truth.');
          expect(assessment.validation_recommendations).toContain('Some models show low confidence. Consider additional evidence gathering.');
        });
    
        it('should identify uncertainty areas for follow up', async () => {
            const mockSignals: LLMConfidenceSignal[] = [
                { ...createMockSignals([0.8])[0], uncertainty_areas: ['Area 1', 'Area 2', 'Area 3'] },
                createMockSignals([0.7])[0],
            ];
            (llmChainService.executeChain as vi.Mock).mockResolvedValue(mockSignals);
    
            const assessment = await multiLLMTruthDiscovery.assessTruthWithMultipleModels('Uncertain truth.');
            expect(assessment.validation_recommendations).toContain('Multiple uncertainty areas identified. Focus interrogation on these topics.');
        });
      });
    
      describe('systematicTopicInterrogation', () => {
        it('should perform interrogation and accumulate knowledge gaps', async () => {
          // Adjusted mock signals to ensure two 'high' consensus levels
          const mockSignalsForQuestion1 = createMockSignals([0.95, 0.9, 0.88]); // Should be high consensus
          mockSignalsForQuestion1[0].uncertainty_areas = ['Gap 1'];
          const mockSignalsForQuestion2 = createMockSignals([0.92, 0.85, 0.9]); // Should be high consensus
          mockSignalsForQuestion2[1].uncertainty_areas = ['Gap 2'];
    
          (llmChainService.executeChain as vi.Mock)
            .mockResolvedValueOnce(mockSignalsForQuestion1)
            .mockResolvedValueOnce(mockSignalsForQuestion2);
    
          const topic = 'AI Ethics';
          const depth = 2;
          const result = await multiLLMTruthDiscovery.systematicTopicInterrogation(topic, depth);
    
          expect(llmChainService.executeChain).toHaveBeenCalledTimes(depth);
          expect(result.topic).toBe(topic);
          expect(result.discovered_truths).toHaveLength(depth);
          expect(result.knowledge_gaps).toEqual(['Gap 1', 'Gap 2']);
          expect(result.confidence_distribution.high_confidence).toBe(2); // Now expecting 2 high confidence assessments
          expect(result.extraction_metadata.interrogation_depth).toBe(depth);
        });  });

  describe('proposeDiscoveredTruths', () => {
    it('should propose truths with aggregated confidence above threshold and no conflicts', async () => {
      const mockAssessment: MultiLLMTruthAssessment = {
        truthId: undefined,
        content: 'Proposed truth content.',
        confidence_signals: createMockSignals([0.9, 0.8]),
        aggregated_confidence: 0.85, // Above 0.7
        consensus_level: 'high',
        suggested_relationships: ['concept B'],
        validation_recommendations: [],
      };
      const discoveryResult: SystematicInterrogationResult = {
        topic: 'Proposal Test',
        discovered_truths: [mockAssessment],
        knowledge_gaps: [],
        confidence_distribution: { high_confidence: 1, medium_confidence: 0, low_confidence: 0, conflicting: 0 },
        extraction_metadata: { interrogation_depth: 1, follow_up_questions: [], boundary_proximity: 0 },
      };

      const proposals = await multiLLMTruthDiscovery.proposeDiscoveredTruths(discoveryResult);

      expect(proposals).toHaveLength(1);
      expect(proposals[0].content).toBe(mockAssessment.content);
      expect(proposals[0].initialConfidence).toBe(mockAssessment.aggregated_confidence);
      expect(proposals[0].relationships).toEqual([{ targetTruthContent: 'concept B', relationshipType: 'references' }]);
    });

    it('should not propose truths below threshold or with conflicts', async () => {
      const lowConfidenceAssessment: MultiLLMTruthAssessment = {
        truthId: undefined,
        content: 'Low confidence truth.',
        confidence_signals: createMockSignals([0.6, 0.5]),
        aggregated_confidence: 0.55, // Below 0.7
        consensus_level: 'medium',
        suggested_relationships: [],
        validation_recommendations: [],
      };
      const conflictingAssessment: MultiLLMTruthAssessment = {
        truthId: undefined,
        content: 'Conflicting truth.',
        confidence_signals: createMockSignals([0.9, 0.2]),
        aggregated_confidence: 0.55,
        consensus_level: 'conflicting', // Conflicting
        suggested_relationships: [],
        validation_recommendations: [],
      };
      const discoveryResult: SystematicInterrogationResult = {
        topic: 'No Proposal Test',
        discovered_truths: [lowConfidenceAssessment, conflictingAssessment],
        knowledge_gaps: [],
        confidence_distribution: { high_confidence: 0, medium_confidence: 1, low_confidence: 0, conflicting: 1 },
        extraction_metadata: { interrogation_depth: 1, follow_up_questions: [], boundary_proximity: 0 },
      };

      const proposals = await multiLLMTruthDiscovery.proposeDiscoveredTruths(discoveryResult);
      expect(proposals).toHaveLength(0);
    });
  });
});
