// src/services/__tests__/LLMChainService.test.ts
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { LLMChainService, llmChainService, LLMConfidenceSignal } from '../LLMChainService';
import { lmStudioService } from '../LMStudioService';

// Use vi.mock to mock the entire LMStudioService module.
// Vitest will hoist this and create the vi.fn() internally.
vi.mock('../LMStudioService', () => ({
  lmStudioService: {
    analyzeTruth: vi.fn(), // Let vi.mock define the mock function directly
  },
}));

describe('LLMChainService', () => {
  beforeEach(() => {
    // Access the mocked function directly and clear its calls
    (lmStudioService.analyzeTruth as vi.Mock).mockClear();
    // Removed .mockReset() as it was interfering with mockImplementation
  });

  it('should return confidence signals from available models', async () => {
    // console.log('Is lmStudioService.analyzeTruth a mock?', vi.isMockFunction(lmStudioService.analyzeTruth)); // Debugging line

    // Mock the analyzeTruth response for each model within this test
        (lmStudioService.analyzeTruth as vi.Mock).mockImplementation(async ({ id }) => {
          if (id.includes('qwen')) {
            return {
              analysis: {
                confidence: 0.9,
                reasoning: 'Qwen reasoning',
                supporting_evidence: ['Qwen evidence'],
                contradictions: [],
              },
            };
          } else if (id.includes('lm-studio-default')) {
            return {
              analysis: {
                confidence: 0.8,
                reasoning: 'LM Studio reasoning',
                supporting_evidence: ['LM Studio evidence'],
                contradictions: ['LM Studio uncertainty'],
              },
            };
          } else if (id.includes('confidence-analyzer')) {
            return {
              analysis: {
                confidence: 0.7,
                reasoning: 'Confidence Analyzer reasoning',
                supporting_evidence: [],
                contradictions: ['CA uncertainty 1', 'CA uncertainty 2'],
              },
            };
          }
          return { analysis: { confidence: 0.5, reasoning: '', supporting_evidence: [], contradictions: [] } };
        });

    const content = 'Test content for LLM chain.';
    const signals = await llmChainService.executeChain(content);

    expect(signals).toHaveLength(3); // Based on the 3 default availableModels
    expect(lmStudioService.analyzeTruth).toHaveBeenCalledTimes(3);

    // Verify calls to analyzeTruth with expect.any(String) for ID
    expect(lmStudioService.analyzeTruth).toHaveBeenCalledWith(expect.objectContaining({
        id: expect.any(String),
        content: content,
    }));

    // Verify signals from Qwen
    const qwenSignal = signals.find(s => s.model.includes('qwen'));
    expect(qwenSignal).toBeDefined();
    expect(qwenSignal?.confidence).toBe(0.9);
    expect(qwenSignal?.reasoning).toBe('Qwen reasoning');

    // Verify signals from LM Studio
    const lmStudioSignal = signals.find(s => s.model === 'lm-studio-default');
    expect(lmStudioSignal).toBeDefined();
    expect(lmStudioSignal?.confidence).toBe(0.8);
    expect(lmStudioSignal?.uncertainty_areas).toEqual(['LM Studio uncertainty']);

    // Verify signals from Confidence Analyzer
    const caSignal = signals.find(s => s.model === 'confidence-analyzer');
    expect(caSignal).toBeDefined();
    expect(caSignal?.confidence).toBe(0.7);
    expect(caSignal?.evidence).toEqual([]);
  });

  it('should handle modelsToQuery parameter', async () => {
    (lmStudioService.analyzeTruth as vi.Mock).mockResolvedValue({
      analysis: {
        confidence: 0.6,
        reasoning: 'Specific model reasoning',
        supporting_evidence: [],
        contradictions: [],
      },
    });

    const content = 'Another test content.';
    const modelsToQuery = ['specific-model-1', 'specific-model-2'];
    const signals = await llmChainService.executeChain(content, modelsToQuery);

    expect(signals).toHaveLength(2);
    expect(lmStudioService.analyzeTruth).toHaveBeenCalledTimes(2);
    expect(lmStudioService.analyzeTruth).toHaveBeenCalledWith(expect.objectContaining({ id: expect.any(String), content }));
  });

  it('should handle failed model assessments gracefully', async () => {
    (lmStudioService.analyzeTruth as vi.Mock)
      .mockResolvedValueOnce({
        analysis: {
          confidence: 0.9,
          reasoning: 'Good response',
          supporting_evidence: [],
          contradictions: [],
        },
      })
      .mockRejectedValueOnce(new Error('Model X failed'))
      .mockResolvedValueOnce({
        analysis: {
          confidence: 0.7,
          reasoning: 'Another good response',
          supporting_evidence: [],
          contradictions: [],
        },
      });

    const content = 'Content with a failing model.';
    const signals = await llmChainService.executeChain(content);

    expect(signals).toHaveLength(2); // One model failed, so only two signals should be returned
    expect(lmStudioService.analyzeTruth).toHaveBeenCalledTimes(3);

    const successfulSignals = signals.filter(s => s.confidence !== undefined);
    expect(successfulSignals).toHaveLength(2);
  });
});
