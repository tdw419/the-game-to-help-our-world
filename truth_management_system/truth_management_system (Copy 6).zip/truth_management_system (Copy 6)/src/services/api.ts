// src/services/api.ts

// --- Data Contracts ---
// These interfaces define the data structures used in the API responses.

export interface Anomaly {
  id: string;
  type: 'spike' | 'drop' | 'deviation' | 'unusual_pattern';
  metric: string;
  description: string;
  severity: 'low' | 'medium' | 'high';
  timestamp: string;
}

export interface Prediction {
  id: string;
  type: 'increase' | 'decrease' | 'stability';
  metric: string;
  value: string;
  confidence: number;
  forecastDate: string;
}

export interface SystemStateAnalysisResult {
  anomalies: Anomaly[];
  predictions: Prediction[];
  analysisTimestamp: string;
}


const API_BASE_URL = 'http://localhost:8000';

interface ExecuteOpcodeResponse {
  status: 'success' | 'failure';
  message: string;
  output: any;
  execution_time_ms: number;
}

/**
 * A generic function to execute any opcode on the backend.
 * @param opcodeName The name of the opcode to execute.
 * @param inputParams The input parameters for the opcode.
 * @returns The output from the opcode execution.
 */
async function executeOpcode<T>(opcodeName: string, inputParams: Record<string, any> = {}): Promise<T> {
  const response = await fetch(`${API_BASE_URL}/execute_opcode`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      opcode_name: opcodeName,
      input_params: inputParams,
    }),
  });

  if (!response.ok) {
    const errorBody = await response.json().catch(() => ({ message: 'Failed to decode error response' }));
    throw new Error(`API request failed with status ${response.status}: ${errorBody.message || 'Unknown error'}`);
  }

  const result: ExecuteOpcodeResponse = await response.json();

  if (result.status === 'failure') {
    throw new Error(`Opcode execution failed: ${result.message}`);
  }

  return result.output as T;
}

/**
 * Fetches historical system states from the backend.
 * Executes the FETCH_HISTORICAL_SYSTEM_STATES opcode.
 */
export async function fetchHistoricalSystemStates(): Promise<number[]> {
    const output = await executeOpcode<{ data: number[] }>('FETCH_HISTORICAL_SYSTEM_STATES');
    return output.data;
}

/**
 * Analyzes system state trends using the backend service.
 * Executes the ANALYZE_SYSTEM_STATE_TRENDS opcode.
 * @param historicalStates The historical states to analyze.
 */
export async function analyzeSystemStateTrends(historicalStates: number[]): Promise<SystemStateAnalysisResult> {
    return executeOpcode<SystemStateAnalysisResult>('ANALYZE_SYSTEM_STATE_TRENDS', {
        historical_states: historicalStates,
    });
}

/**
 * Submits user feedback for a given anomaly.
 * Executes the SUBMIT_FEEDBACK opcode.
 * @param anomalyId The ID of the anomaly.
 * @param isCorrect Whether the user marked the anomaly as correct.
 * @param comment Optional user comment.
 */
export async function submitAnomalyFeedback(anomalyId: string, isCorrect: boolean, comment?: string): Promise<{ status: string; feedback_id: string }> {
    return executeOpcode<{ status: string; feedback_id: string }>('SUBMIT_FEEDBACK', {
        anomaly_id: anomalyId,
        is_correct: isCorrect,
        user_comment: comment,
    });
}
