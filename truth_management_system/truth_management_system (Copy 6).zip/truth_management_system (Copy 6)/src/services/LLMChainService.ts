// src/services/LLMChainService.ts
import { lmStudioService } from './LMStudioService';
import { BackendTruthLedgerEntryDTO } from '@/backend-interfaces/truth-dtos'; // Assuming this is needed for LMStudioService

export interface LLMConfidenceSignal {
  model: string;
  confidence: number;
  reasoning: string;
  evidence: string[];
  uncertainty_areas: string[];
  extraction_timestamp: string;
}

export class LLMChainService {
  private availableModels = [
    'qwen/qwen2.5-coder-14b',
    'lm-studio-default',
    'confidence-analyzer'
  ];

  async getModelConfidenceSignal(model: string, content: string): Promise<LLMConfidenceSignal> {
    // This logic will be moved from MultiLLMTruthDiscovery
    const analysis = await lmStudioService.analyzeTruth({
      id: `temp-${model}-${Date.now()}`,
      content,
      confidence: 0.5, // Initial placeholder
      status: 'proposed',
      timestamp: new Date().toISOString(),
      relationships: [],
      contentHash: '',
      previousHash: ''
    } as BackendTruthLedgerEntryDTO);

    return {
      model,
      confidence: analysis.analysis.confidence,
      reasoning: analysis.analysis.reasoning,
      evidence: analysis.analysis.supporting_evidence || [],
      uncertainty_areas: analysis.analysis.contradictions || [],
      extraction_timestamp: new Date().toISOString()
    };
  }

  async executeChain(content: string, modelsToQuery?: string[]): Promise<LLMConfidenceSignal[]> {
    const models = modelsToQuery || this.availableModels;
    const confidenceSignals: LLMConfidenceSignal[] = [];

    const assessmentPromises = models.map(model =>
      this.getModelConfidenceSignal(model, content)
    );

    const results = await Promise.allSettled(assessmentPromises);

    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        confidenceSignals.push(result.value);
      } else {
        console.error(`Model ${models[index]} assessment failed:`, result.reason);
      }
    });

    return confidenceSignals;
  }
}

export const llmChainService = new LLMChainService();
