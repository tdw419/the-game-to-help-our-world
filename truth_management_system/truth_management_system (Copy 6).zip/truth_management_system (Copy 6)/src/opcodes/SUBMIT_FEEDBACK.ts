
import { Opcode } from '@/lib/pxos/opcodes';

export const SUBMIT_FEEDBACK: Opcode = {
  "name": "SUBMIT_FEEDBACK",
  "description": "Submits user feedback about a detected anomaly, labeling it as correct or incorrect.",
  "prompt_template": "Record user feedback for anomaly ID '{anomaly_id}'. The user marked it as {is_correct ? 'correct' : 'incorrect'}.",
  "owner": "system/truth-management",
  "tags": ["feedback", "ml", "training", "annotation"],
  "simulation_enabled": false,
  "avg_execution_time": 100,
  "max_execution_time": 1000,
  "input_schema": {
    "type": "object",
    "properties": {
      "anomaly_id": {
        "type": "string",
        "description": "The unique identifier of the anomaly receiving feedback."
      },
      "is_correct": {
        "type": "boolean",
        "description": "True if the user confirms the anomaly is correct, False otherwise."
      },
       "user_comment": {
        "type": "string",
        "description": "An optional comment from the user about the feedback.",
        "default": null
      }
    },
    "required": ["anomaly_id", "is_correct"]
  },
  "output_schema": {
    "type": "object",
    "properties": {
      "status": { "type": "string", "enum": ["success", "failure"] },
      "feedback_id": { "type": "string" }
    },
    "required": ["status"]
  },
  "pricing": { "input_cost_per_token": 0.0, "output_cost_per_token": 0.0 },
  "rate_limits": { "requests_per_minute": 200 },
  "version": "1.0.0",
  "dependencies": [],
  "sla": { "uptime_percentage": 99.9, "max_latency_ms": 1500 },
  "security": { "access_level": "user", "audit_log_enabled": true },
  "metadata": {
      "use_case": "Collecting training data for machine learning models by verifying AI-detected anomalies.",
      "example_input": {
          "anomaly_id": "anom_1672531200_1",
          "is_correct": true,
          "user_comment": "This was a legitimate CPU spike caused by a batch job."
      }
  },
  "parameters": {}
};
