
import { Opcode } from '@/lib/pxos/opcodes';

export const SEND_ALERT: Opcode = {
  "name": "SEND_ALERT",
  "description": "Sends an alert to a specified channel or system. For demonstration, this prints to the backend console.",
  "prompt_template": "Send an alert with severity '{severity}' from source '{source}' with the message: {message}",
  "owner": "system/truth-management",
  "tags": ["alerting", "monitoring", "notification"],
  "simulation_enabled": false,
  "avg_execution_time": 50,
  "max_execution_time": 500,
  "input_schema": {
    "type": "object",
    "properties": {
      "severity": {
        "type": "string",
        "enum": ["info", "warning", "high", "critical"],
        "description": "The severity level of the alert."
      },
      "message": {
        "type": "string",
        "description": "The content of the alert message."
      },
      "source": {
          "type": "string",
          "description": "The component or agent originating the alert.",
          "default": "AutomatedAnalysisAgent"
      }
    },
    "required": ["severity", "message"]
  },
  "output_schema": {
    "type": "object",
    "properties": {
      "status": { "type": "string", "enum": ["success", "failure"] },
      "confirmation_id": { "type": "string" }
    },
    "required": ["status"]
  },
  "pricing": { "input_cost_per_token": 0.0, "output_cost_per_token": 0.0 },
  "rate_limits": { "requests_per_minute": 100 },
  "version": "1.0.0",
  "dependencies": [],
  "sla": { "uptime_percentage": 99.9, "max_latency_ms": 1000 },
  "security": { "access_level": "system", "audit_log_enabled": true },
  "metadata": {
      "use_case": "Notifying operators of critical system events detected by monitoring agents.",
      "example_input": {
          "severity": "high",
          "message": "Significant spike detected in system state vector.",
          "source": "AutomatedAnalysisAgent"
      }
  },
  "parameters": {}
};
