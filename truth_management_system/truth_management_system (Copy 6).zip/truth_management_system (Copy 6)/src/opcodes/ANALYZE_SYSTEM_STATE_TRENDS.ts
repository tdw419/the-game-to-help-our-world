
import { Opcode } from '@/lib/pxos/opcodes'; // Assuming this is the path for Opcode type definitions

export const ANALYZE_SYSTEM_STATE_TRENDS: Opcode = {
  "name": "ANALYZE_SYSTEM_STATE_TRENDS",
  "description": "Analyzes a series of historical system state vectors to detect anomalies and predict future trends. This opcode serves as a high-level analytical function for system health monitoring.",
  "prompt_template": "Given a history of system state vectors, identify any significant anomalies (spikes, drops, deviations) and generate predictions about future system stability or risks.",
  "owner": "system/truth-management",
  "tags": ["analysis", "prediction", "anomaly-detection", "system-state", "vector"],
  "simulation_enabled": true,
  "avg_execution_time": 4000, // ms, based on mock (1500ms + 2500ms)
  "max_execution_time": 10000, // ms
  "input_schema": {
    "type": "object",
    "properties": {
      "historical_states": {
        "type": "array",
        "items": { "type": "number" }, // Simplified representation of a feature from the state vector
        "description": "An array of numbers representing a key feature (e.g., health score) derived from historical system state vectors."
      }
    },
    "required": ["historical_states"]
  },
  "output_schema": {
    "type": "object",
    "properties": {
      "anomalies": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "id": { "type": "string" },
            "type": { "type": "string", "enum": ["spike", "drop", "deviation", "unusual_pattern"] },
            "metric": { "type": "string" },
            "description": { "type": "string" },
            "severity": { "type": "string", "enum": ["low", "medium", "high"] },
            "timestamp": { "type": "string", "format": "date-time" }
          },
          "required": ["id", "type", "metric", "description", "severity", "timestamp"]
        }
      },
      "predictions": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "id": { "type": "string" },
            "type": { "type": "string", "enum": ["increase", "decrease", "stability"] },
            "metric": { "type": "string" },
            "value": { "type": "string" },
            "confidence": { "type": "number" },
            "forecastDate": { "type": "string", "format": "date-time" }
          },
          "required": ["id", "type", "metric", "value", "confidence", "forecastDate"]
        }
      },
      "analysisTimestamp": { "type": "string", "format": "date-time" }
    },
    "required": ["anomalies", "predictions", "analysisTimestamp"]
  },
  "pricing": {
    "input_cost_per_token": 0.0, // Internal analytical opcode
    "output_cost_per_token": 0.0
  },
  "rate_limits": {
    "requests_per_minute": 10
  },
  "version": "1.0.0",
  "dependencies": ["FETCH_HISTORICAL_SYSTEM_STATES"], // Conceptual dependency
  "sla": {
    "uptime_percentage": 99.9,
    "max_latency_ms": 12000
  },
  "security": {
    "access_level": "user",
    "allowed_ips": [],
    "audit_log_enabled": true
  },
  "metadata": {
    "use_case": "Proactive system monitoring and reliability engineering.",
    "example_input": {
      "historical_states": [70, 75, 80, 72, 95, 85, 40, 50]
    },
    "example_output": {
      "anomalies": [
        {
          "id": "anom_123",
          "type": "spike",
          "metric": "overall_system_health_vector",
          "description": "Significant spike detected.",
          "severity": "high",
          "timestamp": "2025-11-30T10:00:00Z"
        }
      ],
      "predictions": [
        {
          "id": "pred_456",
          "type": "increase",
          "metric": "anomaly_risk_next_hour",
          "value": "High risk of further anomalies.",
          "confidence": 0.85,
          "forecastDate": "2025-11-30T11:00:00Z"
        }
      ],
      "analysisTimestamp": "2025-11-30T10:05:00Z"
    }
  },
  "parameters": {
    "temperature": 0.1,
    "max_output_tokens": 1024,
    "top_p": 1,
    "top_k": -1,
    "stop_sequences": [],
    "frequency_penalty": 0,
    "presence_penalty": 0,
    "confidence_threshold": 0.8 // Minimum confidence to report a prediction
  }
};
