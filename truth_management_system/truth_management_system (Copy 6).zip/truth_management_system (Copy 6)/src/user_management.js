class UserManagement {
  constructor() {
    this.usersDb = {};
    this.rolesDb = {};
  }

  async registerUser(username, password, role = 'user') {
    if (this.usersDb[username]) {
      throw new Error("User already exists");
    }
    this.usersDb[username] = { password, role };
    return "User registered successfully";
  }

  async loginUser(username, password) {
    const user = this.usersDb[username];
    if (!user || user.password !== password) {
      throw new Error("Invalid credentials");
    }
    return `Login successful for ${username} with role ${user.role}`;
  }

  async getUserRole(username) {
    const user = this.usersDb[username];
    if (!user) {
      throw new Error("User not found");
    }
    return user.role;
  }
}

module.exports = UserManagement;
