// src/frontend/services/TruthApiClient.ts
import { 
  BackendTruthLedgerEntryDTO, 
  ProposeTruthRequestDTO, 
  ChallengeTruthRequestDTO, 
  ResolveTruthRequestDTO,
  AddRelationshipRequestDTO
} from '../interfaces/truth-dtos';

// src/frontend/services/TruthApiClient.ts
import { 
  BackendTruthLedgerEntryDTO, 
  ProposeTruthRequestDTO, 
  ChallengeTruthRequestDTO, 
  ResolveTruthRequestDTO,
  AddRelationshipRequestDTO
} from '../interfaces/truth-dtos';

const API_BASE_URL = 'http://localhost:8000'; // FastAPI backend runs on port 8000

// Helper function to get token
const getToken = (): string | null => {
  return localStorage.getItem('jwtToken');
};

const getHeaders = (): HeadersInit => {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };
  const token = getToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
};

// --- New Interfaces Mirroring Python Pydantic Models ---
export interface Truth {
    id: number;
    content: string;
    version: number;
    status: "active" | "pending" | "archived" | "deprecated";
    created_at: string;
    created_by: string;
    source: "human" | "ai";
}

export interface TruthChangeProposal {
    id?: number;
    truth_id?: number;
    proposed_content: string;
    rationale: string;
    status: "draft" | "under_review" | "approved" | "rejected";
    created_at: string;
    created_by: string;
}

export interface TruthDiffRequest {
    truth_id: number;
    proposed_content: string;
}

export interface TruthDiffResponse {
    diff: string;
}

export interface UpdateProposalStatusRequest {
    status: "draft" | "under_review" | "approved" | "rejected";
}


export const TruthApiClient = {
  listTruths: async (): Promise<Truth[]> => {
    const response = await fetch(`${API_BASE_URL}/truth/list`, {
      headers: getHeaders(),
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch truths: ${response.statusText}`);
    }
    return response.json();
  },

  createTruthChangeProposal: async (proposalData: TruthChangeProposal): Promise<TruthChangeProposal> => {
    const response = await fetch(`${API_BASE_URL}/truth/proposals`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(proposalData),
    });
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Failed to create truth change proposal: ${errorData.detail || response.statusText}`);
    }
    return response.json();
  },

  listTruthChangeProposals: async (): Promise<TruthChangeProposal[]> => {
    const response = await fetch(`${API_BASE_URL}/truth/proposals`, {
      headers: getHeaders(),
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch truth change proposals: ${response.statusText}`);
    }
    return response.json();
  },

  getTruthChangeProposalById: async (proposalId: number): Promise<TruthChangeProposal> => {
    const response = await fetch(`${API_BASE_URL}/truth/proposals/${proposalId}`, {
      headers: getHeaders(),
    });
    if (response.status === 404) {
      throw new Error(`Truth change proposal with ID ${proposalId} not found.`);
    }
    if (!response.ok) {
      throw new Error(`Failed to fetch truth change proposal by ID ${proposalId}: ${response.statusText}`);
    }
    return response.json();
  },

  updateTruthChangeProposalStatus: async (proposalId: number, statusData: UpdateProposalStatusRequest): Promise<TruthChangeProposal> => {
    const response = await fetch(`${API_BASE_URL}/truth/proposals/${proposalId}/status`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(statusData),
    });
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Failed to update truth change proposal status: ${errorData.detail || response.statusText}`);
    }
    return response.json();
  },

  getTruthDiff: async (diffRequest: TruthDiffRequest): Promise<TruthDiffResponse> => {
    const response = await fetch(`${API_BASE_URL}/truth/diff`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(diffRequest),
    });
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Failed to get truth diff: ${errorData.detail || response.statusText}`);
    }
    return response.json();
  },
};