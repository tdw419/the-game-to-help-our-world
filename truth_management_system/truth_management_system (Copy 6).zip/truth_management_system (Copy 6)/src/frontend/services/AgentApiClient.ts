import axios from 'axios';

// --- Interfaces mirroring Python Pydantic Models ---
export interface AgentConfig {
  llmModel?: string;
  temperature?: number;
  maxTokens?: number;
  prompt?: string;
}

export interface AgentExecuteRequest {
  input: string;
  config?: AgentConfig;
}

export interface AgentResult {
  output: string;
  success: boolean;
  timestamp: string;
  agentVersion: string;
  processingTimeMs: number;
}

// --- Agent API Client ---
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'; // Adjust as per your frontend's environment variable setup

// Helper function to get token - consistent with TruthApiClient.ts
const getToken = (): string | null => {
  return localStorage.getItem('jwtToken');
};

const getAuthHeaders = (): { Authorization: string } => {
  const token = getToken();
  if (!token) {
    throw new Error('Authentication token is not set in localStorage.');
  }
  return { Authorization: `Bearer ${token}` };
};

export class AgentApiClient {
  // Removed authToken state and constructor, now relies on getToken()

  public async executeTruthAgent(request: AgentExecuteRequest): Promise<AgentResult> {
    try {
      const response = await axios.post<AgentResult>(
        `${API_BASE_URL}/api/agents/truth/execute`,
        request,
        {
          headers: {
            'Content-Type': 'application/json',
            ...getAuthHeaders(),
          },
        }
      );
      return response.data;
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        console.error('Error executing truth agent:', error.response.data);
        throw new Error(error.response.data.detail || 'Failed to execute truth agent');
      } else {
        console.error('Unexpected error:', error);
        throw new Error('An unexpected error occurred while executing truth agent.');
      }
    }
  }
}
