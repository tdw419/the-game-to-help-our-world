class AbstractLayer {
  constructor() {
    this.userManagement = new UserManagement();
    this.resourceAllocation = new ResourceAllocation();
    this.systemMonitoring = new SystemMonitoring();
  }

  async registerUser(username, password, role) {
    return await this.userManagement.registerUser(username, password, role);
  }

  async loginUser(username, password) {
    return await this.userManagement.loginUser(username, password);
  }

  async getUserRole(username) {
    return await this.userManagement.getUserRole(username);
  }

  async allocateResource(resourceType, allocatedTo) {
    return await this.resourceAllocation.allocateResource(resourceType, allocatedTo);
  }

  async listResources() {
    return await this.resourceAllocation.listResources();
  }

  async generateText(prompt) {
    const sessionStartPrompt = `
## Web AI Confidence Protocol (Ultra-Concise)

Use TypeScript-style confidence blocks for reasoning:

\`\`\`typescript
{
  analysis: {
    "key_insight": 0.85,      // [0.0-1.0] honest confidence
    "uncertain_aspect": 0.45, // Show genuine uncertainty
    "boolean_truth": True,    // Use True/False for binary
  }
}
\`\`\`

**Calibration Scale:**
- 1.00: Certain (math proofs)
- 0.95: Very confident (strong evidence)  
- 0.85: Confident (good reasoning)
- 0.70: Moderate (alternatives exist)
- 0.50: Uncertain (multiple possibilities)
- 0.30: Doubtful (weak evidence)
- 0.00: Speculation

**Your Context:** Building Analog OS (continuous substrate + digital containers), spatial memory, hybrid AI with LM Studio + APIs.

**Principle:** Honest uncertainty > false confidence. Scores help distinguish trust vs verify.

Lead with blocks, then explain naturally.
    `;

    const fullPrompt = `${sessionStartPrompt}\n\n${prompt}`;
    return await this.systemMonitoring.generateText(fullPrompt);
  }

  async proposeTruth(content) {
    return await this.systemMonitoring.proposeTruth(content);
  }

  async listTruths() {
    return await this.systemMonitoring.listTruths();
  }
}

module.exports = AbstractLayer;
