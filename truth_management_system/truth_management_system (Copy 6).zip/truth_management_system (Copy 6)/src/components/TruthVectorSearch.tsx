import React, { useState } from 'react';
import { Button } from ' @/components/ui/button';
import { Input } from ' @/components/ui/input';
import { Textarea } from ' @/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from ' @/components/ui/card';
import { Label } from ' @/components/ui/label';
import { Loader2, Search } from 'lucide-react';

// Define TypeScript interfaces for the API response
interface FoundationalTruth {
  name: string;
  content: string;
  source: 'human' | 'ai' | 'hybrid';
  rating: number;
  is_immutable: boolean;
  is_active: boolean;
  last_updated_by: string;
  last_updated_at: string;
  content_vector: number[] | null;
}

interface FoundationalTruthSearchResult {
  truth: FoundationalTruth;
  similarity: number;
}

/**
 * A React component to search for foundational truths using vector similarity.
 * It interacts with the /truths/search_by_vector FastAPI endpoint.
 */
export default function TruthVectorSearch() {
  const [queryText, setQueryText] = useState<string>('');
  const [topK, setTopK] = useState<number>(5);
  const [searchResults, setSearchResults] = useState<FoundationalTruthSearchResult[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    setLoading(true);
    setError(null);
    setSearchResults([]);

    if (!queryText.trim()) {
      setError('Please enter some text to search.');
      setLoading(false);
      return;
    }

    try {
      const response = await fetch('http://localhost:8000/truths/search_by_vector', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Assuming a mock token for development based on the backend verification instructions
          'Authorization': 'token_mockuser',
        },
        body: JSON.stringify({
          query_text: queryText,
          top_k: topK,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || `HTTP error! status: ${response.status}`);
      }

      const data: FoundationalTruthSearchResult[] = await response.json();
      setSearchResults(data);
    } catch (err: any) {
      console.error('Error during vector search:', err);
      setError(err.message || 'An unknown error occurred during search.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto my-8">
      <CardHeader>
        <CardTitle>Vector-Based Truth Search</CardTitle>
        <CardDescription>Search foundational truths by semantic similarity.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div>
            <Label htmlFor="queryText">Query Text</Label>
            <Textarea
              id="queryText"
              placeholder="e.g., AI working with humans for mutual understanding"
              value={queryText}
              onChange={(e) => setQueryText(e.target.value)}
              rows={3}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="topK">Number of Results (top_k)</Label>
            <Input
              id="topK"
              type="number"
              min="1"
              value={topK}
              onChange={(e) => setTopK(Math.max(1, parseInt(e.target.value) || 1))}
              className="mt-1"
            />
          </div>
          <Button onClick={handleSearch} disabled={loading} className="w-full">
            {loading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Search className="mr-2 h-4 w-4" />
            )}
            Search
          </Button>

          {error && (
            <div className="text-red-500 text-sm mt-2">Error: {error}</div>
          )}

          {searchResults.length > 0 && (
            <div className="mt-6 space-y-4">
              <h3 className="text-lg font-semibold">Search Results:</h3>
              {searchResults.map((result, index) => (
                <Card key={result.truth.name} className="p-4 border">
                  <p className="text-sm font-medium">
                    <span className="font-bold">Name:</span> {result.truth.name}
                  </p>
                  <p className="text-sm">
                    <span className="font-bold">Similarity:</span> {result.similarity.toFixed(4)}
                  </p>
                  <p className="text-sm mt-1">
                    <span className="font-bold">Content:</span> {result.truth.content}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Source: {result.truth.source}, Rating: {result.truth.rating}, Updated: {result.truth.last_updated_at}
                  </p>
                </Card>
              ))}
            </div>
          )}

          {/* Show message if no results and not loading/error */}
          {!loading && !error && searchResults.length === 0 && queryText.trim() && (
            <p className="text-center text-gray-500 mt-4">No truths found for your query.</p>
          )}
           {!loading && !error && searchResults.length === 0 && queryText.trim() && (
            <p className="text-center text-gray-500 mt-4">No truths found for your query.</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
