import React, { useState } from 'react';
import { Button, Input, Textarea, Label, Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui';
import { Loader2, Send } from 'lucide-react';

const TruthManagement: React.FC = () => {
  const [newTruthContent, setNewTruthContent] = useState('');
  const [truths, setTruths] = useState<{ id: number; content: string; status: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('');

  const handleProposeTruth = async () => {
    if (!newTruthContent.trim()) {
      setError('Please enter a truth.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const token = 'token_your_username'; // Replace with actual token retrieval logic
      const response = await fetch('http://localhost:8001/truth/propose', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token,
        },
        body: JSON.stringify({ content: newTruthContent }),
      });

      if (!response.ok) {
        throw new Error('Failed to propose truth.');
      }

      const data = await response.json();
      setNewTruthContent('');
      fetchTruths();
    } catch (err) {
      setError(err.message || 'An error occurred while proposing truth.');
    } finally {
      setLoading(false);
    }
  };

  const fetchTruths = async () => {
    try {
      const token = 'token_your_username'; // Replace with actual token retrieval logic
      const response = await fetch('http://localhost:8001/truth/list', {
        headers: {
          'Authorization': token,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch truths.');
      }

      const data = await response.json();
      setTruths(data.truths);
    } catch (err) {
      setError(err.message || 'An error occurred while fetching truths.');
    }
  };

  React.useEffect(() => {
    fetchTruths();
  }, []);

  const filteredTruths = truths.filter(truth =>
    truth.content.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Manage Truths</CardTitle>
        <CardDescription>Propose and list truths in the Vector Universe.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid w-full gap-4">
          <Label htmlFor="truth-content">Truth Content</Label>
          <Textarea
            id="truth-content"
            placeholder="Enter your truth here..."
            rows={4}
            value={newTruthContent}
            onChange={(e) => setNewTruthContent(e.target.value)}
          />
          {error && <p className="text-red-500 text-sm">{error}</p>}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          onClick={handleProposeTruth}
          disabled={loading || !newTruthContent.trim()}
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Proposing...
            </>
          ) : (
            <>
              <Send className="h-4 w-4 mr-2" /> Propose Truth
            </>
          )}
        </Button>
      </CardFooter>
      {filteredTruths.length > 0 && (
        <CardContent>
          <div className="bg-gray-100 p-4 rounded">
            <ul>
              {filteredTruths.map(truth => (
                <li key={truth.id}>
                  <p>{truth.content}</p>
                  <p>Status: {truth.status}</p>
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      )}
    </Card>
  );
};

export default TruthManagement;
