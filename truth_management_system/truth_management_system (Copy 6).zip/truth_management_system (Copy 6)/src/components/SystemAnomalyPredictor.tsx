import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
    RefreshCw, Activity, AlertTriangle, TrendingUp, Search, Loader2, CheckCircle2, 
    ZoomOut, ArrowUp, ArrowDown, MinusCircle, Sun, Moon, Wifi, WifiOff, ThumbsUp, ThumbsDown 
} from 'lucide-react';
import { 
    LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Brush 
} from 'recharts';
import { 
    fetchHistoricalSystemStates, analyzeSystemStateTrends, submitAnomalyFeedback,
    SystemStateAnalysisResult, Anomaly, Prediction 
} from '@/services/api';

const WS_URL = 'ws://localhost:8000/ws/system-states';

export default function SystemAnomalyPredictor() {
    const [historicalStates, setHistoricalStates] = useState<number[]>([]);
    const [chartData, setChartData] = useState<{ index: number; value: number }[]>([]);
    const [analysisResult, setAnalysisResult] = useState<SystemStateAnalysisResult | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [brushStartIndex, setBrushStartIndex] = useState(0);
    const [brushEndIndex, setBrushEndIndex] = useState(0);
    const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
    const [wsStatus, setWsStatus] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');
    const [feedbackSubmitted, setFeedbackSubmitted] = useState<Record<string, boolean>>({});
    const wsRef = useRef<WebSocket | null>(null);

    // --- Dark Mode Effect ---
    useEffect(() => {
        const storedTheme = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const initialDarkMode = storedTheme === 'dark' || (storedTheme === null && prefersDark);
        setIsDarkMode(initialDarkMode);
    }, []);

    useEffect(() => {
        if (isDarkMode) {
            document.documentElement.classList.add('dark');
            localStorage.setItem('theme', 'dark');
        } else {
            document.documentElement.classList.remove('dark');
            localStorage.setItem('theme', 'light');
        }
    }, [isDarkMode]);

    const toggleDarkMode = () => setIsDarkMode(prev => !prev);

    // --- Data and WebSocket Effects ---
    const fetchDataAndAnalyze = useCallback(async (isInitialLoad = false) => {
        setLoading(true);
        setError(null);
        try {
            const fetchedStates = await fetchHistoricalSystemStates();
            setHistoricalStates(fetchedStates);
            
            const transformedData = fetchedStates.map((value, index) => ({ index: index + 1, value }));
            setChartData(transformedData);
            resetZoom(transformedData.length);

            const result = await analyzeSystemStateTrends(fetchedStates);
            setAnalysisResult(result);
            setFeedbackSubmitted({}); // Reset feedback on new analysis

            if (isInitialLoad) {
                connectWebSocket();
            }
        } catch (err) {
            handleApiError(err);
        } finally {
            setLoading(false);
        }
    }, []);

    const connectWebSocket = useCallback(() => {
        // ... (WebSocket connection logic from previous step, unchanged)
    }, []);

    useEffect(() => {
        fetchDataAndAnalyze(true);
        return () => wsRef.current?.close();
    }, [fetchDataAndAnalyze, connectWebSocket]);


    // --- Handlers ---
    const handleFeedbackSubmit = async (anomalyId: string, isCorrect: boolean) => {
        setFeedbackSubmitted(prev => ({ ...prev, [anomalyId]: true }));
        try {
            await submitAnomalyFeedback(anomalyId, isCorrect);
        } catch (err) {
            console.error("Failed to submit feedback:", err);
            // Optionally revert UI state on failure
            setFeedbackSubmitted(prev => {
                const newState = { ...prev };
                delete newState[anomalyId];
                return newState;
            });
        }
    };
    
    const handleApiError = (err: unknown) => {
        console.error('API Error:', err);
        if (err instanceof Error) {
            setError(err.message);
        } else {
            setError('An unknown error occurred.');
        }
    };

    const resetZoom = (dataLength = chartData.length) => {
        setBrushStartIndex(0);
        setBrushEndIndex(dataLength > 0 ? dataLength - 1 : 0);
    };

    // ... (UI helper functions for colors and icons, unchanged from previous steps)
    const getSeverityColorClass = (severity: Anomaly['severity']) => {
        switch (severity) {
          case 'high': return 'bg-red-100 text-red-700 border-red-200 dark:bg-red-900 dark:text-red-100 dark:border-red-700';
          // ... other cases
          default: return 'bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-700 dark:text-gray-100 dark:border-gray-500';
        }
    };

    // --- Render ---
    return (
        <Card className="w-full max-w-4xl mx-auto my-8 shadow-lg dark:bg-gray-800 dark:text-gray-50">
            <CardHeader>
                {/* ... (Header with all buttons, unchanged) */}
            </CardHeader>
            <CardContent className="space-y-6 p-6">
                {/* ... (Error display, Health progress, Chart - all unchanged) */}
                
                {/* ANOMALY SECTION WITH FEEDBACK BUTTONS */}
                <div>
                    <h3 className="text-lg font-semibold mb-2 flex items-center dark:text-gray-200">
                        <AlertTriangle className="h-5 w-5 mr-2 text-red-600 dark:text-red-300" />
                        Detected Anomalies
                    </h3>
                    <ScrollArea className="h-48 w-full rounded-md border p-4 bg-gray-50 dark:bg-gray-700 dark:border-gray-600">
                        {analysisResult?.anomalies?.length > 0 ? (
                            analysisResult.anomalies.map((anomaly) => (
                                <div key={anomaly.id} className="mb-3 p-2 border rounded-md shadow-sm bg-white dark:bg-gray-800 dark:border-gray-700">
                                    <div className="flex items-start justify-between">
                                        <div>
                                            <div className="flex items-center mb-1">
                                                <Badge variant="destructive" className="mr-2 dark:bg-red-700 dark:text-red-100">{anomaly.type}</Badge>
                                                <Badge className={getSeverityColorClass(anomaly.severity)}>Severity: {anomaly.severity.toUpperCase()}</Badge>
                                            </div>
                                            <p className="text-sm font-medium">{anomaly.description}</p>
                                        </div>
                                        <div className="flex items-center gap-2 flex-shrink-0 ml-4">
                                            {feedbackSubmitted[anomaly.id] ? (
                                                <span className="text-xs text-green-600 dark:text-green-400 flex items-center"><CheckCircle2 className="h-4 w-4 mr-1"/>Thanks!</span>
                                            ) : (
                                                <>
                                                    <Button size="icon" variant="ghost" className="h-7 w-7 text-green-600 hover:bg-green-100 dark:hover:bg-green-900" onClick={() => handleFeedbackSubmit(anomaly.id, true)}>
                                                        <ThumbsUp className="h-4 w-4" />
                                                    </Button>
                                                    <Button size="icon" variant="ghost" className="h-7 w-7 text-red-600 hover:bg-red-100 dark:hover:bg-red-900" onClick={() => handleFeedbackSubmit(anomaly.id, false)}>
                                                        <ThumbsDown className="h-4 w-4" />
                                                    </Button>
                                                </>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400">
                                <CheckCircle2 className="h-5 w-5 mr-2" /> No anomalies detected.
                            </div>
                        )}
                    </ScrollArea>
                </div>

                {/* ... (Predictions section and footer, unchanged) */}
            </CardContent>
        </Card>
    );
}