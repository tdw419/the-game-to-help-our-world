import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { PlusCircle, Loader2 } from 'lucide-react';

import { TruthApiClient, TruthChangeProposal } from '../frontend/services/TruthApiClient';

// Assuming a way to get the current user's token (e.g., from context or localStorage)
const getToken = (): string | null => {
  return localStorage.getItem('jwtToken');
};

interface ProposeTruthChangeFormProps {
  onProposalCreated?: () => void;
  initialTruthId?: number; // Optional: if proposing a change to an existing truth
}

export default function ProposeTruthChangeForm({ onProposalCreated, initialTruthId }: ProposeTruthChangeFormProps) {
  const { toast } = useToast();
  const [proposedContent, setProposedContent] = useState('');
  const [rationale, setRationale] = useState('');
  const [truthId, setTruthId] = useState<string>(initialTruthId ? String(initialTruthId) : '');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    const token = getToken();
    if (!token) {
      toast({
        title: "Authentication Error",
        description: "You must be logged in to propose a truth change.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    const apiClient = TruthApiClient; // TruthApiClient doesn't need a constructor token now

    try {
      const proposalData: TruthChangeProposal = {
        proposed_content: proposedContent,
        rationale: rationale,
        truth_id: truthId ? parseInt(truthId) : undefined,
        created_at: new Date().toISOString(), // Backend will re-set this, but good to send
        created_by: "human", // In a real app, this would come from authenticated user
        status: "draft",
      };

      await apiClient.createTruthChangeProposal(proposalData);
      toast({
        title: "Proposal Submitted",
        description: "Your truth change proposal has been submitted successfully.",
      });
      setProposedContent('');
      setRationale('');
      setTruthId(initialTruthId ? String(initialTruthId) : '');
      onProposalCreated?.();
    } catch (error: any) {
      toast({
        title: "Submission Failed",
        description: error.message || "An error occurred while submitting the proposal.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-[600px]">
      <CardHeader>
        <CardTitle className="flex items-center">
          <PlusCircle className="mr-2 h-5 w-5" /> Propose Truth Change
        </CardTitle>
        <CardDescription>
          Submit a new truth or propose an update to an existing truth.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="truthId">Truth ID (Optional, for updates)</Label>
            <Input
              id="truthId"
              type="number"
              placeholder="e.g., 123"
              value={truthId}
              onChange={(e) => setTruthId(e.target.value)}
              disabled={isLoading}
            />
            <p className="text-sm text-muted-foreground">Leave blank to propose a new truth.</p>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="proposedContent">Proposed Truth Content</Label>
            <Textarea
              id="proposedContent"
              placeholder="Enter the full content of the truth you are proposing..."
              value={proposedContent}
              onChange={(e) => setProposedContent(e.target.value)}
              rows={8}
              required
              disabled={isLoading}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="rationale">Rationale for Change</Label>
            <Textarea
              id="rationale"
              placeholder="Explain why this change is necessary or beneficial."
              value={rationale}
              onChange={(e) => setRationale(e.target.value)}
              rows={4}
              required
              disabled={isLoading}
            />
          </div>
        </form>
      </CardContent>
      <CardFooter className="flex justify-end">
        <Button onClick={handleSubmit} disabled={isLoading}>
          {isLoading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <PlusCircle className="mr-2 h-4 w-4" />
          )}
          Submit Proposal
        </Button>
      </CardFooter>
    </Card>
  );
}