import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from ' @/components/ui/tabs'; // Assuming shadcn/ui Tabs component
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from ' @/components/ui/card'; // Added CardHeader, CardTitle, CardDescription

// Import the previously generated components
import TruthVectorSearch from './TruthVectorSearch'; // Adjust path as necessary
import TruthOpcodeVectorSearch from './TruthOpcodeVectorSearch'; // Adjust path as necessary
import AllFoundationalTruths from './AllFoundationalTruths'; // Adjust path as necessary
import PythonCodeVectorizer from './PythonCodeVectorizer'; // NEW: Import PythonCodeVectorizer

/**
 * A dashboard component that integrates different vector-based truth management functionalities.
 * It provides a tabbed interface to switch between:
 * - Direct API search for foundational truths.
 * - Opcode-based search for foundational truths.
 * - Display of all foundational truths.
 * - Python Code Vectorizer.
 */
export default function VectorTruthDashboard() {
  return (
    <div className="container mx-auto p-4">
      <Card className="my-8">
        <CardHeader>
          <CardTitle className="text-3xl font-bold">Vector Truth Management Dashboard</CardTitle>
          <CardDescription>
            Explore and interact with foundational truths using vector similarity and opcodes, and vectorize Python code.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all-truths" className="w-full">
            <TabsList className="grid w-full grid-cols-4"> {/* Updated grid-cols to 4 */}
              <TabsTrigger value="all-truths">All Truths</TabsTrigger>
              <TabsTrigger value="api-search">API Search</TabsTrigger>
              <TabsTrigger value="opcode-search">Opcode Search</TabsTrigger>
              <TabsTrigger value="code-vectorizer">Code Vectorizer</TabsTrigger> {/* New Tab Trigger */}
            </TabsList>

            <TabsContent value="all-truths">
              <AllFoundationalTruths />
            </TabsContent>
            <TabsContent value="api-search">
              <TruthVectorSearch />
            </TabsContent>
            <TabsContent value="opcode-search">
              <TruthOpcodeVectorSearch />
            </TabsContent>
            <TabsContent value="code-vectorizer"> {/* New Tab Content */}
              <PythonCodeVectorizer />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

// Note: To use this dashboard, ensure that:
// 1. The 'TruthVectorSearch', 'TruthOpcodeVectorSearch', 'AllFoundationalTruths', and 'PythonCodeVectorizer' components are
//    available in the specified paths (e.g., in the same directory or a subfolder like 'components').
// 2. You have 'shadcn/ui' and 'lucide-react' installed and configured in your React project.
// 3. Your 'useToast' hook from shadcn/ui is correctly set up with a <Toaster /> component in your root layout.
