import React, { useState } from 'react';
import { Button } from ' @/components/ui/button';
import { Input } from ' @/components/ui/input';
import { Textarea } from ' @/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from ' @/components/ui/card';
import { Label } from ' @/components/ui/label';
import { Loader2, Code, XCircle } from 'lucide-react';
import { useToast } from ' @/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from ' @/components/ui/dialog';

// Define TypeScript interfaces for the opcode interaction
interface VectorizePythonCodeInput {
  code_string: string;
  unit_name: string; // e.g., function name
}

interface VectorizePythonCodeOutput {
  vector_representation: number[];
}

interface ExecuteOpcodeResponse {
  opcode_name: string;
  success: boolean;
  outputs: VectorizePythonCodeOutput;
  error?: string;
  reasoning_blocks?: any[];
  confidence_blocks?: any;
}

/**
 * A React component to vectorize Python code using the VECTORIZE_PYTHON_CODE opcode.
 * It interacts with the /vector_boot_simulator/execute_opcode FastAPI endpoint.
 */
export default function PythonCodeVectorizer() {
  const [codeString, setCodeString] = useState<string>('');
  const [unitName, setUnitName] = useState<string>('');
  const [vectorResult, setVectorResult] = useState<number[] | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleVectorize = async () => {
    setLoading(true);
    setError(null);
    setVectorResult(null);

    if (!codeString.trim()) {
      setError('Please enter Python code to vectorize.');
      toast({
        title: "Vectorization Error",
        description: "Please enter Python code to vectorize.",
        variant: "destructive",
      });
      setLoading(false);
      return;
    }

    if (!unitName.trim()) {
      setError('Please provide a unit name for the code.');
      toast({
        title: "Vectorization Error",
        description: "Please provide a unit name for the code.",
        variant: "destructive",
      });
      setLoading(false);
      return;
    }

    try {
      const opcodeInputs: VectorizePythonCodeInput = {
        code_string: codeString,
        unit_name: unitName,
      };

      const response = await fetch('http://localhost:8000/vector_boot_simulator/execute_opcode', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'token_mockuser',
        },
        body: JSON.stringify({
          opcode_name: 'VECTORIZE_PYTHON_CODE',
          inputs: opcodeInputs,
        }),
      });

      const responseData: ExecuteOpcodeResponse = await response.json();

      if (!response.ok || !responseData.success) {
        const errorMessage = responseData.error || `HTTP error! status: ${response.status}`;
        throw new Error(errorMessage);
      }

      setVectorResult(responseData.outputs.vector_representation || []);
      toast({
        title: "Vectorization Successful",
        description: "Python code vectorized successfully.",
        className: "bg-green-500 text-white",
      });

    } catch (err: any) {
      console.error('Error during code vectorization:', err);
      const displayError = err.message || 'An unknown error occurred during vectorization.';
      setError(displayError);
      toast({
        title: "Vectorization Error",
        description: displayError,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setCodeString('');
    setUnitName('');
    setVectorResult(null);
    setError(null);
    setLoading(false);
    toast({
      title: "Form Reset",
      description: "Code vectorizer form has been reset.",
    });
  };

  return (
    <Card className="w-full max-w-2xl mx-auto my-8">
      <CardHeader>
        <CardTitle>Python Code Vectorizer</CardTitle>
        <CardDescription>
          Convert Python code snippets into their vector representations using the `VECTORIZE_PYTHON_CODE` opcode.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div>
            <Label htmlFor="codeUnitName">Code Unit Name</Label>
            <Input
              id="codeUnitName"
              placeholder="e.g., calculate_fibonacci"
              value={unitName}
              onChange={(e) => setUnitName(e.target.value)}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="pythonCode">Python Code</Label>
            <Textarea
              id="pythonCode"
              placeholder="def hello_world():&#10;    print('Hello, World!')"
              value={codeString}
              onChange={(e) => setCodeString(e.target.value)}
              rows={8}
              className="mt-1 font-mono"
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={handleVectorize} disabled={loading} className="flex-1">
              {loading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Code className="mr-2 h-4 w-4" />
              )}
              Vectorize Code
            </Button>
            <Button onClick={handleReset} variant="outline" className="flex-none">
              <XCircle className="mr-2 h-4 w-4" />
              Reset
            </Button>
          </div>

          {error && (
            <div className="text-red-500 text-sm mt-2 flex items-center">
              <XCircle className="h-4 w-4 mr-1" />
              Error: {error}
            </div>
          )}

          {vectorResult && (
            <div className="mt-6 space-y-4">
              <h3 className="text-lg font-semibold">Vector Representation:</h3>
              <Card className="p-4 border">
                <p className="text-sm break-all font-mono">
                  {JSON.stringify(vectorResult)}
                </p>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="link" className="h-auto p-0 text-xs mt-2">
                      <Code className="h-3 w-3 mr-1" /> Copy to Clipboard
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Vector Value</DialogTitle>
                      <DialogDescription>
                        Copy the vector representation to your clipboard.
                      </DialogDescription>
                    </DialogHeader>
                    <Textarea
                      readOnly
                      value={JSON.stringify(vectorResult)}
                      rows={5}
                      className="font-mono text-xs"
                      onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                    />
                    <Button onClick={() => navigator.clipboard.writeText(JSON.stringify(vectorResult))}>
                      Copy
                    </Button>
                  </DialogContent>
                </Dialog>
              </Card>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
