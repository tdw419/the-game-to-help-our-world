import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from ' @/components/ui/card';
import { Button } from ' @/components/ui/button';
import { Loader2, FileText, RefreshCw } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from ' @/components/ui/dialog';
import { useToast } from ' @/components/ui/use-toast';

// Define TypeScript interface for FoundationalTruth
interface FoundationalTruth {
  name: string;
  content: string;
  source: 'human' | 'ai' | 'hybrid';
  rating: number;
  is_immutable: boolean;
  is_active: boolean;
  last_updated_by: string;
  last_updated_at: string;
  content_vector: number[] | null;
}

/**
 * A React component to display all foundational truths from the backend.
 * It interacts with the GET /truths/foundational FastAPI endpoint.
 */
export default function AllFoundationalTruths() {
  const [truths, setTruths] = useState<FoundationalTruth[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchTruths = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('http://localhost:8000/truths/foundational', {
        method: 'GET',
        headers: {
          'Authorization': 'token_mockuser', // Using the mock token as per backend instructions
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || `HTTP error! status: ${response.status}`);
      }

      const data: FoundationalTruth[] = await response.json();
      setTruths(data);
      toast({
        title: "Truths Loaded",
        description: `${data.length} foundational truths retrieved.`,
        className: "bg-green-500 text-white",
      });
    } catch (err: any) {
      console.error('Error fetching foundational truths:', err);
      const displayError = err.message || 'An unknown error occurred while fetching truths.';
      setError(displayError);
      toast({
        title: "Fetch Error",
        description: displayError,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTruths();
  }, []); // Run once on component mount

  return (
    <Card className="w-full max-w-2xl mx-auto my-8">
      <CardHeader>
        <CardTitle>All Foundational Truths</CardTitle>
        <CardDescription>
          Displays all foundational truths stored in the system, including their content vectors.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <Button onClick={fetchTruths} disabled={loading}>
            {loading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="mr-2 h-4 w-4" />
            )}
            Refresh Truths
          </Button>

          {error && (
            <div className="text-red-500 text-sm mt-2">Error: {error}</div>
          )}

          {loading && <p className="text-center text-gray-500">Loading foundational truths...</p>}

          {!loading && truths.length === 0 && !error && (
            <p className="text-center text-gray-500">No foundational truths found.</p>
          )}

          {!loading && truths.length > 0 && (
            <div className="mt-6 space-y-4">
              <h3 className="text-lg font-semibold">Foundational Truths:</h3>
              {truths.map((truth) => (
                <Card key={truth.name} className="p-4 border">
                  <p className="text-sm font-medium">
                    <span className="font-bold">Name:</span> {truth.name}
                  </p>
                  <p className="text-sm mt-1">
                    <span className="font-bold">Content:</span> {truth.content}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Source: {truth.source}, Rating: {truth.rating}, Updated: {truth.last_updated_at}
                  </p>
                  {truth.content_vector && (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="link" className="h-auto p-0 text-xs mt-2">
                          <FileText className="h-3 w-3 mr-1" /> View Vector
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[425px] md:max-w-[700px]">
                        <DialogHeader>
                          <DialogTitle>Vector for "{truth.name}"</DialogTitle>
                          <DialogDescription>
                            The content vector for this foundational truth.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="max-h-[400px] overflow-y-auto text-xs break-all">
                          {JSON.stringify(truth.content_vector)}
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                  {!truth.content_vector && (
                    <p className="text-xs text-gray-500 mt-2">No content vector available for this truth.</p>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
