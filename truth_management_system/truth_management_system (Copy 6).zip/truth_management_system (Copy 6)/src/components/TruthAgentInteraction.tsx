import React, { useState, useContext } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, CheckCircle, XCircle, Bot } from 'lucide-react';

import { AgentApiClient, AgentExecuteRequest, AgentResult } from '../frontend/services/AgentApiClient';
import { AuthContext } from '../frontend/context/AuthContext'; // Assuming this context exists for auth token

// Define a type for agent status
type AgentStatus = 'idle' | 'running' | 'success' | 'error';

export default function TruthAgentInteraction() {
  const { authToken } = useContext(AuthContext); // Get auth token from context
  const agentApiClient = new AgentApiClient(authToken);

  const [taskInput, setTaskInput] = useState<string>('');
  const [agentResponse, setAgentResponse] = useState<string>('No agent response yet.');
  const [status, setStatus] = useState<AgentStatus>('idle');
  const [error, setError] = useState<string | null>(null);

  // Agent configuration states, mirroring AgentConfig interface
  const [llmModel, setLlmModel] = useState<string>('gpt-4o-mini');
  const [temperature, setTemperature] = useState<number>(0.7);
  const [maxTokens, setMaxTokens] = useState<number>(500);
  const [prompt, setPrompt] = useState<string>(''); // For custom prompt overrides

  const handleRunAgent = async () => {
    if (!taskInput.trim()) {
      setError('Please provide input for the agent task.');
      return;
    }
    if (!authToken) {
      setError('Authentication token is missing. Please log in.');
      return;
    }

    setStatus('running');
    setError(null);
    setAgentResponse('Agent is processing your request...');

    const requestBody: AgentExecuteRequest = {
      input: taskInput,
      config: {
        llmModel: llmModel,
        temperature: temperature,
        maxTokens: maxTokens,
        prompt: prompt.trim() !== '' ? prompt : undefined, // Only send if custom prompt is provided
      },
    };

    try {
      const result: AgentResult = await agentApiClient.executeTruthAgent(requestBody);

      setAgentResponse(result.output);
      setStatus(result.success ? 'success' : 'error');
      if (!result.success) {
        setError('Agent reported an error: ' + result.output);
      }
    } catch (e: any) {
      setAgentResponse('Failed to communicate with the agent service or agent execution failed.');
      setStatus('error');
      setError(e.message || 'Unknown error occurred.');
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'running':
        return <Loader2 className="mr-2 h-4 w-4 animate-spin" />;
      case 'success':
        return <CheckCircle className="mr-2 h-4 w-4 text-green-500" />;
      case 'error':
        return <XCircle className="mr-2 h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <Card className="w-[550px]">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bot className="mr-2 h-5 w-5" /> Truth Agent Interaction
        </CardTitle>
      </CardHeader>
      <CardContent className="grid gap-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="grid gap-2">
            <Label htmlFor="llmModel">LLM Model</Label>
            <Select
              value={llmModel}
              onValueChange={setLlmModel}
              disabled={status === 'running'}
            >
              <SelectTrigger id="llmModel">
                <SelectValue placeholder="Select LLM Model" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="gpt-4o-mini">GPT-4o Mini</SelectItem>
                <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                {/* Add other models as needed */}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="temperature">Temperature</Label>
            <Input
              id="temperature"
              type="number"
              step="0.1"
              min="0"
              max="1"
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              disabled={status === 'running'}
            />
          </div>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="maxTokens">Max Tokens</Label>
          <Input
            id="maxTokens"
            type="number"
            step="10"
            min="100"
            max="4000"
            value={maxTokens}
            onChange={(e) => setMaxTokens(parseInt(e.target.value))}
            disabled={status === 'running'}
          />
        </div>

        <div className="grid gap-2">
          <Label htmlFor="customPrompt">Custom Prompt (Optional)</Label>
          <Textarea
            id="customPrompt"
            placeholder="Override the default agent prompt. Use {input} for the user's task."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            disabled={status === 'running'}
            rows={4}
          />
        </div>

        <div className="grid gap-2">
          <Label htmlFor="taskInput">Agent Task Input</Label>
          <Textarea
            id="taskInput"
            placeholder="Enter the task for the truth agent..."
            value={taskInput}
            onChange={(e) => setTaskInput(e.target.value)}
            disabled={status === 'running'}
            rows={5}
          />
        </div>

        <div className="grid gap-2">
          <Label>Agent Response</Label>
          <Textarea
            value={agentResponse}
            readOnly
            className="min-h-[120px]"
          />
        </div>

        {error && (
          <p className="text-sm text-red-500">Error: {error}</p>
        )}
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <div className="flex items-center text-sm text-muted-foreground">
          {getStatusIcon()}
          Status: <span className="ml-1 capitalize">{status}</span>
        </div>
        <Button
          onClick={handleRunAgent}
          disabled={status === 'running'}
        >
          {status === 'running' ? 'Running Agent...' : 'Execute Truth Agent'}
        </Button>
      </CardFooter>
    </Card>
  );
}
