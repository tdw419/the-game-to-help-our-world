import React, { useState, useEffect, useRef } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Brain, Search, Lightbulb, FlaskConical, Rocket, RefreshCcw, PlayCircle } from 'lucide-react'; // Icons for ANMSO stages

export default function AnsmoDashboard() {
  const [log, setLog] = useState<string[]>([]);
  const [stage, setStage] = useState(0); // 0: Idle, 1: Introspection, 2: Synthesis, 3: Optimization, 4: Complete
  const [currentNeuralComponent, setCurrentNeuralComponent] = useState("MoE Expert 7 (Vision Subsystem)");
  const [inefficiencies, setInefficiencies] = useState<string[]>([]);
  const [optimizedBlueprint, setOptimizedBlueprint] = useState("Pending...");
  const [performanceGain, setPerformanceGain] = useState("N/A");
  const logRef = useRef<HTMLDivElement>(null);

  const stageDescriptions = [
    "Idle. Ready to start ANSMO cycle.",
    "NEURO_INTROSPECTION: Analyzing neural component for inefficiencies.",
    "NEURO_SYMBOLIC_SYNTHESIS: Generating optimized architecture blueprint.",
    "NEURO_COMPONENT_OPTIMIZATION: Testing, validating, and deploying new component.",
    "ANSMO Cycle Complete: Optimized component integrated and live."
  ];

  const handleNextStage = () => {
    setStage(prev => prev + 1);
  };

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;

    const executeNeuroIntrospection = async () => {
      setLog(prev => [`[ANSMO][${new Date().toLocaleTimeString()}] Calling backend to execute NEURO_INTROSPECTION on '${currentNeuralComponent}'...`, ...prev]);
      try {
        const FAKE_TOKEN = "a_placeholder_token_for_development"; // In a real app, this token would be managed by an auth context.
        
        const response = await fetch("http://127.0.0.1:8000/execute_opcode", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${FAKE_TOKEN}`
          },
          body: JSON.stringify({
            opcode_name: "NEURO_INTROSPECTION",
            input_params: {
              component_id: currentNeuralComponent
            }
          })
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.identified_inefficiencies) {
          setInefficiencies(data.identified_inefficiencies);
          setLog(prev => [`[ANSMO][${new Date().toLocaleTimeString()}] NEURO_INTROSPECTION result: ${data.identified_inefficiencies.join(', ')}`, ...prev]);
        } else {
           setInefficiencies(["Failed to fetch inefficiencies from backend."]);
           setLog(prev => [`[ANSMO][${new Date().toLocaleTimeString()}] NEURO_INTROSPECTION result: Failed to fetch inefficiencies.`, ...prev]);
        }
        
      } catch (error) {
        console.error("Failed to fetch from backend:", error);
        setLog(prev => [`[ANSMO][${new Date().toLocaleTimeString()}] NEURO_INTROSPECTION backend call failed. Using fallback data.`, ...prev]);
        setInefficiencies([
            "BACKEND CALL FAILED",
            "High parameter count (1.2M) (fallback)",
            "Suboptimal activation function (fallback)"
        ]);
      } finally {
        // Always advance to the next stage after introspection attempt
        timeoutId = setTimeout(handleNextStage, 3000);
      }
    };

    if (stage === 1) {
      executeNeuroIntrospection();
    } else if (stage > 1 && stage < 4) { // Auto-advance for stages 2 and 3
      timeoutId = setTimeout(handleNextStage, 3000);
    }

    let newLogEntry = '';
    switch (stage) {
      case 2:
        newLogEntry = `[ANSMO][${new Date().toLocaleTimeString()}] Executing NEURO_SYMBOLIC_SYNTHESIS. Input: Inefficiencies, LLM goal 'reduce latency, improve generalization'.`;
        setOptimizedBlueprint("Optimized MoE Expert 7 (Vision Subsystem) v2.0 - Latency-optimized, diversified ensemble.");
        break;
      case 3:
        newLogEntry = `[ANSMO][${new Date().toLocaleTimeString()}] Executing NEURO_COMPONENT_OPTIMIZATION. Testing new blueprint, deploying if successful.`;
        setPerformanceGain("Latency -18%, Generalization +5%");
        break;
      case 4:
        newLogEntry = `[ANSMO][${new Date().toLocaleTimeString()}] ANSMO Cycle Complete. Optimization successful. Performance Gain: ${performanceGain}.`;
        break;
    }
    if (newLogEntry) {
      setLog(prev => [`${newLogEntry}`, ...prev]);
    }

    return () => clearTimeout(timeoutId);
  }, [stage, currentNeuralComponent, performanceGain]); // Add currentNeuralComponent and performanceGain to dependencies

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = 0; // Keep latest log at top
  }, [log]);

  const resetAnsmo = () => {
    setStage(0);
    setLog([]);
    setInefficiencies([]);
    setOptimizedBlueprint("Pending...");
    setPerformanceGain("N/A");
  };

  return (
    <div className="container mx-auto p-6 space-y-8 bg-gray-900 text-white">
      <h1 className="text-4xl font-bold text-center mb-2">Adaptive Neuro-Symbolic Model Synthesizer & Optimizer (ANSMO)</h1>
      <p className="text-xl text-center text-muted-foreground mb-10">
        The Living LLM-OS optimizing its own AI components through introspection, synthesis, and re-integration.
      </p>

      {/* Overview and Controls */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Brain /> ANSMO Module Status</CardTitle>
          <CardDescription className="text-gray-400">Current state of the neuro-optimization cycle.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Current Operation:</h3>
            <p className="text-xl font-bold text-yellow-400">{stageDescriptions[stage]}</p>
            <div className="flex gap-2">
              <Button onClick={() => setStage(1)} disabled={stage > 0}>
                {stage === 0 ? <PlayCircle className="mr-2 h-4 w-4" /> : null}
                {stage === 0 ? "Start ANSMO Cycle" : "Processing..."}
              </Button>
              <Button onClick={resetAnsmo} variant="outline" disabled={stage === 0}>
                <RefreshCcw className="mr-2 h-4 w-4" /> Reset Cycle
              </Button>
            </div>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold text-lg">ANSMO Activity Log:</h3>
            <div className="h-40 bg-black p-3 rounded-md font-mono text-xs text-green-400 overflow-y-auto" ref={logRef}>
              {log.length > 0 ? log.map((l, i) => <p key={i}>{l}</p>) : <p className="text-gray-500">ANSMO awaiting instruction...</p>}
            </div>
          </div>
        </CardContent>
      </Card>

      <Separator className="my-8 bg-gray-700" />

      {/* Detailed ANSMO Workflow Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Neuro-Introspection Panel */}
        <Card className={`bg-blue-900/20 border-blue-700 transition-opacity duration-500 ${stage < 1 ? 'opacity-50' : ''}`}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-400"><Search /> Neuro-Introspection</CardTitle>
            <CardDescription className="text-blue-200">Execution of <Badge variant="secondary">NEURO_INTROSPECTION</Badge> Opcode.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="font-semibold">Target Component:</p>
            <Badge className="text-base p-2 bg-blue-700/50">{currentNeuralComponent}</Badge>
            <p className="font-semibold mt-3">Identified Inefficiencies:</p>
            <ul className="list-disc list-inside text-sm text-blue-100">
              {inefficiencies.length > 0 ? inefficiencies.map((item, i) => <li key={i}>{item}</li>) : <li>Awaiting analysis...</li>}
            </ul>
          </CardContent>
        </Card>

        {/* Neuro-Symbolic Synthesis Panel */}
        <Card className={`bg-purple-900/20 border-purple-700 transition-opacity duration-500 ${stage < 2 ? 'opacity-50' : ''}`}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-400"><Lightbulb /> Neuro-Symbolic Synthesis</CardTitle>
            <CardDescription className="text-purple-200">Execution of <Badge variant="secondary">NEURO_SYMBOLIC_SYNTHESIS</Badge> Opcode.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="font-semibold">LLM Symbolic Goal:</p>
            <p className="text-sm italic">"Reduce latency by 20%, improve generalization for vision tasks."</p>
            <p className="font-semibold mt-3">Optimized Blueprint:</p>
            <pre className="text-xs bg-gray-800 p-3 rounded-md font-mono overflow-x-auto text-gray-300 h-24">
              <code>{optimizedBlueprint}</code>
            </pre>
          </CardContent>
        </Card>

        {/* Neuro-Component Optimization Panel */}
        <Card className={`bg-green-900/20 border-green-700 transition-opacity duration-500 ${stage < 3 ? 'opacity-50' : ''}`}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-400"><Rocket /> Neuro-Component Optimization</CardTitle>
            <CardDescription className="text-green-200">Execution of <Badge variant="secondary">NEURO_COMPONENT_OPTIMIZATION</Badge> Opcode.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="font-semibold">Testing & Validation:</p>
            <Badge className="bg-green-700/50">Simulated A/B Testing, Integration Tests Passed</Badge>
            <p className="font-semibold mt-3">Actual Performance Gain:</p>
            <p className="text-xl font-bold text-green-400">{performanceGain}</p>
            <p className="font-semibold mt-3">Deployment Status:</p>
            <Badge className="bg-green-700/50">{stage === 4 ? "Deployed Successfully" : "Pending Deployment"}</Badge>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
