// src/components/AILearningDashboard.tsx
import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Brain, FlaskConical, Target, Award, Rocket, Scale, Clock, CheckCircle, XCircle, Loader2 } from 'lucide-react';

// Assuming default_api is available globally or imported from a client library
declare const default_api: any;

interface LearningMetric {
  name: string;
  value: number; // 0-100% or similar scale
  description: string;
  icon: React.ElementType;
}

interface ExperimentLogEntry {
  id: string;
  timestamp: string;
  type: 'hypothesis_generated' | 'experiment_executed' | 'evaluation_completed' | 'knowledge_updated';
  description: string;
  details?: any;
  confidence?: number;
  status: 'pending' | 'success' | 'failed';
}

export default function AILearningDashboard() {
  const [learningMetrics, setLearningMetrics] = useState<LearningMetric[]>([
    { name: 'Hypothesis Success Rate', value: 75, description: 'Percentage of proposed hypotheses that led to positive experimental outcomes.', icon: Rocket },
    { name: 'Experiment Throughput (daily)', value: 12, description: 'Number of experiments the AI-VAM conducts per day.', icon: FlaskConical },
    { name: 'Knowledge Confidence', value: 88, description: 'Overall confidence in the accuracy and completeness of the AI\'s learned knowledge base.', icon: Brain },
    { name: 'Optimization Impact Score', value: 65, description: 'Average performance improvement achieved by AI-VAM\'s optimizations.', icon: Target },
    { name: 'Learning Strategy Efficacy', value: 80, description: 'Effectiveness of current learning algorithms in acquiring new truths.', icon: Award },
  ]);
  const [experimentLog, setExperimentLog] = useState<ExperimentLogEntry[]>([]);
  const [isAIVamWorking, setIsAIVamWorking] = useState(false);

  const addLogEntry = useCallback((entry: ExperimentLogEntry) => {
    setExperimentLog(prev => [{ ...entry, timestamp: new Date().toLocaleTimeString() }, ...prev].slice(0, 50)); // Keep last 50 entries
  }, []);

  // Fetch initial learning metrics when component mounts
  useEffect(() => {
    const fetchInitialMetrics = async () => {
      try {
        const token = "token_mockuser"; // Placeholder for actual authentication token
        const response = await default_api.ai_vam_get_learning_metrics_endpoint(token);
        if (response && response.status === "success" && response.details && response.details.metrics) {
          const fetchedMetrics = response.details.metrics;
          setLearningMetrics(prev => prev.map(metric => ({
            ...metric,
            value: fetchedMetrics[metric.name.toLowerCase().replace(/[^a-z0-9]/g, '')] || metric.value, // Update value if found in backend response
          })));
          addLogEntry({
            id: `log_${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            type: 'knowledge_updated',
            description: 'Fetched initial AI-VAM learning metrics from backend.',
            status: 'success',
            details: fetchedMetrics
          });
        } else {
          addLogEntry({
            id: `log_${Date.now()}`,
            timestamp: new Date().toLocaleTimeString(),
            type: 'knowledge_updated',
            description: 'Failed to fetch initial AI-VAM learning metrics.',
            status: 'failed',
            details: response
          });
        }
      } catch (error: any) {
        addLogEntry({
          id: `log_${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          type: 'knowledge_updated',
          description: `Error fetching initial metrics: ${error.message}`,
          status: 'failed',
          details: error
        });
      }
    };
    fetchInitialMetrics();
  }, [addLogEntry]);

  const simulateAIVamAction = useCallback(async (actionType: 'propose' | 'evaluate') => {
    setIsAIVamWorking(true);
    const token = "token_mockuser"; // Placeholder for actual authentication token
    const logId = `log_${Date.now()}`;

    try {
      if (actionType === 'propose') {
        addLogEntry({
          id: logId,
          timestamp: new Date().toLocaleTimeString(),
          type: 'hypothesis_generated',
          description: 'AI-VAM is generating a new hypothesis...',
          status: 'pending',
        });

        // Placeholder for actual data from system state or other sources
        const mockSystemState = { "cpu_load_vector": [0.5, 0.2], "memory_util_vector": [0.8, 0.1] };
        const mockPerfMetrics = { "boot_time_avg": 3000, "success_rate": 0.95 };
        const mockLearningGoal = "optimize boot time";

        const response = await default_api.ai_vam_propose_experiment_endpoint(
          {
            current_system_state: mockSystemState,
            performance_metrics: mockPerfMetrics,
            learning_goal: mockLearningGoal
          },
          token
        );

        if (response && response.status === "success") {
          addLogEntry({
            id: logId,
            timestamp: new Date().toLocaleTimeString(),
            type: 'hypothesis_generated',
            description: `AI-VAM proposed: ${response.details.description}`,
            details: response.details,
            confidence: response.details.confidence_in_hypothesis,
            status: 'success',
          });
        } else {
          throw new Error(response?.message || "Unknown error proposing experiment.");
        }
      } else if (actionType === 'evaluate') {
        addLogEntry({
          id: logId,
          timestamp: new Date().toLocaleTimeString(),
          type: 'evaluation_completed',
          description: 'AI-VAM is evaluating the last experiment...',
          status: 'pending',
        });

        // Placeholder for actual experiment results and metrics
        const mockExperimentId = experimentLog[0]?.details?.id || `EXP_${Date.now()}`; // Use ID of last proposed experiment
        const mockExperimentResult = { "outcome": "positive", "metrics_delta": {"boot_time_reduction": 100} };
        const mockFinalMetrics = { "boot_time_avg": 2900, "success_rate": 0.96 };

        const response = await default_api.ai_vam_evaluate_experiment_endpoint(
          {
            experiment_id: mockExperimentId,
            experiment_result: mockExperimentResult,
            final_metrics: mockFinalMetrics
          },
          token
        );

        if (response && response.status === "success") {
          addLogEntry({
            id: logId,
            timestamp: new Date().toLocaleTimeString(),
            type: 'evaluation_completed',
            description: `AI-VAM evaluated: ${response.details.evaluation_summary}`,
            details: response.details,
            confidence: response.details.new_knowledge_confidence,
            status: 'success',
          });
        } else {
          throw new Error(response?.message || "Unknown error evaluating experiment.");
        }
      }
      // Re-fetch metrics after any action to show updated values
      const responseMetrics = await default_api.ai_vam_get_learning_metrics_endpoint(token);
      if (responseMetrics && responseMetrics.status === "success" && responseMetrics.details && responseMetrics.details.metrics) {
        const fetchedMetrics = responseMetrics.details.metrics;
        setLearningMetrics(prev => prev.map(metric => ({
          ...metric,
          value: fetchedMetrics[metric.name.toLowerCase().replace(/[^a-z0-9]/g, '')] || metric.value,
        })));
      }

    } catch (error: any) {
      addLogEntry({
        id: logId,
        timestamp: new Date().toLocaleTimeString(),
        type: actionType === 'propose' ? 'hypothesis_generated' : 'evaluation_completed',
        description: `Error during ${actionType} action: ${error.message}`,
        status: 'failed',
        details: error.response?.data || { message: error.message }
      });
    } finally {
      setIsAIVamWorking(false);
    }
  }, [addLogEntry, experimentLog]);

  const renderMetric = (metric: LearningMetric) => (
    <Card key={metric.name} className="flex flex-col items-center p-4">
      <metric.icon className="h-8 w-8 text-primary mb-2" />
      <CardTitle className="text-md text-center">{metric.name}</CardTitle>
      <CardDescription className="text-sm text-center mb-2">{metric.description}</CardDescription>
      <Progress value={metric.value} className="w-full" indicatorColor={metric.value > 80 ? 'bg-green-500' : metric.value > 60 ? 'bg-yellow-500' : 'bg-red-500'} />
      <span className="text-lg font-bold mt-1">{metric.value}%</span>
    </Card>
  );

  return (
    <div className="container mx-auto p-4 max-w-7xl">
      <h1 className="text-3xl font-bold mb-6 text-center">AI-VAM: Advanced Self-Assessment Dashboard</h1>
      <p className="text-center text-gray-600 dark:text-gray-400 mb-8">
        Monitoring the AI-VAM's meta-cognitive process: Automated Goal Refinement, Learning Strategy Optimization, and Performance Metacognition.
      </p>

      {/* AI-VAM Learning Metrics */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Brain className="h-6 w-6" /> AI-VAM Learning Metrics</CardTitle>
          <CardDescription>Key performance indicators of the AI's self-assessment and learning process.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {learningMetrics.map(renderMetric)}
          </div>
        </CardContent>
      </Card>

      {/* Controls */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><FlaskConical className="h-6 w-6" /> AI-VAM Experiment Controls</CardTitle>
          <CardDescription>Initiate and manage the AI-VAM's learning experiments.</CardDescription>
        </CardHeader>
        <CardContent className="flex gap-4">
          <Button onClick={() => simulateAIVamAction('propose')} disabled={isAIVamWorking}>
            {isAIVamWorking ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Target className="mr-2 h-4 w-4" />}
            Propose New Experiment
          </Button>
          <Button onClick={() => simulateAIVamAction('evaluate')} disabled={isAIVamWorking}>
            {isAIVamWorking ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Scale className="mr-2 h-4 w-4" />}
            Evaluate Last Experiment
          </Button>
        </CardContent>
      </Card>

      {/* Hypothesis & Experiment Log */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Clock className="h-6 w-6" /> AI-VAM Learning Log</CardTitle>
          <CardDescription>A chronological record of AI-VAM's hypotheses, experiments, and knowledge updates.</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px] w-full rounded-md border p-4 bg-gray-50 dark:bg-gray-900">
            {experimentLog.length === 0 ? (
              <p className="text-gray-400">No AI-VAM learning activity yet.</p>
            ) : (
              <Accordion type="multiple" className="w-full">
                {experimentLog.map(entry => (
                  <AccordionItem key={entry.id} value={entry.id}>
                    <AccordionTrigger>
                      <div className="flex items-center gap-2">
                        {entry.status === 'success' && <CheckCircle className="h-4 w-4 text-green-500" />}
                        {entry.status === 'failed' && <XCircle className="h-4 w-4 text-red-500" />}
                        {entry.status === 'pending' && <Loader2 className="h-4 w-4 animate-spin text-gray-500" />}
                        <span className={`font-medium ${entry.status === 'failed' ? 'text-red-500' : ''}`}>
                          {entry.timestamp} - {entry.description}
                        </span>
                      </div>
                    </AccordionTrigger>
                    {entry.details && (
                      <AccordionContent>
                        <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded-md overflow-x-auto">
                          {JSON.stringify(entry.details, null, 2)}
                        </pre>
                      </AccordionContent>
                    )}
                  </AccordionItem>
                ))}
              </Accordion>
            )}
          </ScrollArea>
        </CardContent>
        <CardFooter>
          <Button variant="outline" onClick={() => setExperimentLog([])} disabled={experimentLog.length === 0}>Clear Log</Button>
        </CardFooter>
      </Card>
    </div>
  );
}
