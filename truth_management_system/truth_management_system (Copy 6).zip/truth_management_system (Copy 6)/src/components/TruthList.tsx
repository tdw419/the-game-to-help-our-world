import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { CheckSquare, Loader2, RefreshCw } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

import { TruthApiClient, Truth } from '../frontend/services/TruthApiClient';

// Assuming a way to get the current user's token (e.g., from context or localStorage)
const getToken = (): string | null => {
  return localStorage.getItem('jwtToken');
};

export default function TruthList() {
  const { toast } = useToast();
  const [truths, setTruths] = useState<Truth[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTruths = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    const token = getToken();
    if (!token) {
      setError("Authentication token is missing. Please log in.");
      setIsLoading(false);
      return;
    }

    try {
      const fetchedTruths = await TruthApiClient.listTruths();
      setTruths(fetchedTruths.filter(t => t.status === "active")); // Only show active truths
    } catch (err: any) {
      setError(err.message || "Failed to fetch truths.");
      toast({
        title: "Error",
        description: err.message || "Failed to fetch truths.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchTruths();
  }, [fetchTruths]);

  const getStatusVariant = (status: Truth['status']) => {
    switch (status) {
      case 'active':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'archived':
      case 'deprecated':
        return 'destructive';
      default':
        return 'outline';
    }
  };

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Active Truths</CardTitle>
          <CardDescription>Loading...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center items-center h-40">
          <Loader2 className="h-8 w-8 animate-spin" />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Active Truths</CardTitle>
          <CardDescription>Error loading truths.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-red-500">{error}</p>
          <Button onClick={fetchTruths} className="mt-4">
            <RefreshCw className="mr-2 h-4 w-4" /> Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-2xl font-bold flex items-center">
          <CheckSquare className="mr-2 h-6 w-6" /> Active Truths
        </CardTitle>
        <Button onClick={fetchTruths} variant="outline" size="sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Refresh
        </Button>
      </CardHeader>
      <CardContent>
        {truths.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No active truths found.</p>
        ) : (
          <ScrollArea className="h-[400px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">ID</TableHead>
                  <TableHead>Content</TableHead>
                  <TableHead>Version</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created By</TableHead>
                  <TableHead>Created At</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {truths.map((truth) => (
                  <TableRow key={truth.id}>
                    <TableCell className="font-medium">{truth.id}</TableCell>
                    <TableCell className="max-w-[400px] truncate">{truth.content}</TableCell>
                    <TableCell>{truth.version}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusVariant(truth.status)}>{truth.status}</Badge>
                    </TableCell>
                    <TableCell>{truth.created_by}</TableCell>
                    <TableCell>{new Date(truth.created_at).toLocaleString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        )}
      </CardContent>
      <CardFooter>
        <p className="text-sm text-muted-foreground">Total active truths: {truths.length}</p>
      </CardFooter>
    </Card>
  );
}