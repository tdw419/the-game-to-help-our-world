import React, { useState } from 'react';
import { Button } from ' @/components/ui/button';
import { Input } from ' @/components/ui/input';
import { Textarea } from ' @/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from ' @/components/ui/card';
import { Label } from ' @/components/ui/label';
import { Loader2, Search, XCircle, FileText } from 'lucide-react'; // Added XCircle and FileText icons
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from ' @/components/ui/dialog'; // New import
import { useToast } from ' @/components/ui/use-toast'; // Assuming you have a toast provider setup


// Define TypeScript interfaces matching backend Pydantic models for the opcode
interface FoundationalTruth {
  name: string;
  content: string;
  source: 'human' | 'ai' | 'hybrid';
  rating: number;
  is_immutable: boolean;
  is_active: boolean;
  last_updated_by: string;
  last_updated_at: string;
  content_vector: number[] | null;
}

interface FoundationalTruthSearchResult {
  truth: FoundationalTruth;
  similarity: number;
}

// Corresponds to QueryTruthsByVectorInput (already matched in previous thinking step)
// interface QueryTruthsByVectorInput {
//   query_text: string;
//   top_k: number;
// }

// Corresponds to QueryTruthsByVectorOutput (already matched in previous thinking step)
// interface QueryTruthsByVectorOutput {
//   results: FoundationalTruthSearchResult[];
//   message: string;
// }

// Corresponds to the generic ExecuteOpcodeResponse (already matched in previous thinking step)
interface ExecuteOpcodeResponse {
  opcode_name: string;
  success: boolean;
  outputs: {
    results: FoundationalTruthSearchResult[];
    message: string;
  }; // Explicitly define nested outputs structure
  error?: string;
  reasoning_blocks?: any[];
  confidence_blocks?: any;
}

/**
 * A React component to search for foundational truths using the QUERY_TRUTHS_BY_VECTOR opcode
 * via the /vector_boot_simulator/execute_opcode FastAPI endpoint.
 */
export default function TruthOpcodeVectorSearch() {
  const [queryText, setQueryText] = useState<string>('');
  const [topK, setTopK] = useState<number>(5);
  const [searchResults, setSearchResults] = useState<FoundationalTruthSearchResult[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast(); // Initialize useToast hook

  const handleSearch = async () => {
    setLoading(true);
    setError(null);
    setSearchResults([]);

    if (!queryText.trim()) {
      setError('Please enter some text to search.');
      toast({
        title: "Search Error",
        description: "Please enter some text to search.",
        variant: "destructive",
      });
      setLoading(false);
      return;
    }

    try {
      const opcodeInputs = { // Using inferred type for now, as interface is defined above
        query_text: queryText,
        top_k: topK,
      };

      const response = await fetch('http://localhost:8000/vector_boot_simulator/execute_opcode', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'token_mockuser', // Using the mock token as per backend instructions
        },
        body: JSON.stringify({
          opcode_name: 'QUERY_TRUTHS_BY_VECTOR',
          inputs: opcodeInputs,
        }),
      });

      const responseData: ExecuteOpcodeResponse = await response.json();

      if (!response.ok || !responseData.success) {
        const errorMessage = responseData.error || `HTTP error! status: ${response.status}`;
        throw new Error(errorMessage);
      }

      // The actual results are nested inside responseData.outputs.results
      setSearchResults(responseData.outputs.results || []);
      toast({
        title: "Search Successful",
        description: `${responseData.outputs.results?.length || 0} truths found.`,
        className: "bg-green-500 text-white",
      });

    } catch (err: any) {
      console.error('Error during opcode vector search:', err);
      const displayError = err.message || 'An unknown error occurred during opcode search.';
      setError(displayError);
      toast({
        title: "Search Error",
        description: displayError,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setQueryText('');
    setTopK(5);
    setSearchResults([]);
    setError(null);
    setLoading(false);
    toast({
      title: "Form Reset",
      description: "Search form has been reset.",
    });
  };

  return (
    <Card className="w-full max-w-2xl mx-auto my-8">
      <CardHeader>
        <CardTitle>Opcode Vector-Based Truth Search</CardTitle>
        <CardDescription>
          Search foundational truths by semantic similarity using the `QUERY_TRUTHS_BY_VECTOR` opcode.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div>
            <Label htmlFor="opcodeQueryText">Query Text</Label>
            <Textarea
              id="opcodeQueryText"
              placeholder="e.g., AI's ethical purpose"
              value={queryText}
              onChange={(e) => setQueryText(e.target.value)}
              rows={3}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="opcodeTopK">Number of Results (top_k)</Label>
            <Input
              id="opcodeTopK"
              type="number"
              min="1"
              value={topK}
              onChange={(e) => setTopK(Math.max(1, parseInt(e.target.value) || 1))}
              className="mt-1"
            />
          </div>
          <div className="flex gap-2">
            <Button onClick={handleSearch} disabled={loading} className="flex-1">
              {loading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Search className="mr-2 h-4 w-4" />
              )}
              Search Opcode
            </Button>
            <Button onClick={handleReset} variant="outline" className="flex-none">
              <XCircle className="mr-2 h-4 w-4" />
              Reset
            </Button>
          </div>

          {error && (
            <div className="text-red-500 text-sm mt-2 flex items-center">
              <XCircle className="h-4 w-4 mr-1" />
              Error: {error}
            </div>
          )}

          {searchResults.length > 0 && (
            <div className="mt-6 space-y-4">
              <h3 className="text-lg font-semibold">Opcode Search Results:</h3>
              {searchResults.map((result, index) => (
                <Card key={result.truth.name} className="p-4 border">
                  <p className="text-sm font-medium">
                    <span className="font-bold">Name:</span> {result.truth.name}
                  </p>
                  <p className="text-sm">
                    <span className="font-bold">Similarity:</span> {result.similarity.toFixed(4)}
                  </p>
                  <p className="text-sm mt-1">
                    <span className="font-bold">Content:</span> {result.truth.content}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Source: {result.truth.source}, Rating: {result.truth.rating}, Updated: {result.truth.last_updated_at}
                  </p>
                  {result.truth.content_vector && (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="link" className="h-auto p-0 text-xs mt-2">
                          <FileText className="h-3 w-3 mr-1" /> View Vector
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[425px] md:max-w-[700px]">
                        <DialogHeader>
                          <DialogTitle>Vector for "{result.truth.name}"</DialogTitle>
                          <DialogDescription>
                            The content vector for this foundational truth.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="max-h-[400px] overflow-y-auto text-xs break-all">
                          {JSON.stringify(result.truth.content_vector)}
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                </Card>
              ))}
            </div>
          )}

          {/* Show message if no results and not loading/error */}
          {!loading && !error && searchResults.length === 0 && queryText.trim() && (
            <p className="text-center text-gray-500 mt-4">No truths found for your query via opcode.</p>
          )}
          {!loading && !error && searchResults.length === 0 && !queryText.trim() && (
            <p className="text-center text-gray-500 mt-4">Enter a query and click "Search Opcode" to find truths.</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
