import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PlayCircle, RefreshCcw, FileText, BrainCircuit, Database, BarChartHorizontal, X, Terminal, Bot } from 'lucide-react';

// --- Placeholder App Components ---
// These are simplified versions of our previously designed dashboards to act as "applications"

const AnsmoDashboardApp = () => (
  <div className="p-4 bg-gray-800 h-full">
    <Card className="bg-purple-900/20 border-purple-700 h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-purple-400"><BrainCircuit /> ANSMO</CardTitle>
        <CardDescription className="text-purple-200">Adaptive Neuro-Symbolic Model Synthesizer & Optimizer</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm">Neuro-Introspection complete. Now synthesizing new architecture...</p>
      </CardContent>
    </Card>
  </div>
);

const KnowledgeExtractorApp = () => (
  <div className="p-4 bg-gray-800 h-full">
    <Card className="bg-blue-900/20 border-blue-700 h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-blue-400"><FileText /> Knowledge Extractor</CardTitle>
        <CardDescription className="text-blue-200">Systematic Interrogation & Capture Protocol</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm">Interrogation cycle running. 128 fragments captured...</p>
      </CardContent>
    </Card>
  </div>
);


// --- Windowing System Components ---

interface WindowProps {
  id: string;
  title: string;
  children: React.ReactNode;
  initialPosition: { x: number; y: number };
  onClose: (id: string) => void;
  onFocus: (id: string) => void;
  zIndex: number;
}

const SimulatedWindow: React.FC<WindowProps> = ({ id, title, children, initialPosition, onClose, onFocus, zIndex }) => {
  const [position, setPosition] = useState(initialPosition);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ x: number, y: number } | null>(null);

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    setIsDragging(true);
    onFocus(id);
    dragStartRef.current = {
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    };
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (isDragging && dragStartRef.current) {
      const newX = e.clientX - dragStartRef.current.x;
      const newY = e.clientY - dragStartRef.current.y;
      setPosition({ x: newX, y: newY });
    }
  }, [isDragging]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    dragStartRef.current = null;
  }, []);

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    } else {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, handleMouseMove, handleMouseUp]);

  return (
    <div
      className="absolute bg-gray-900 border-2 border-gray-600 rounded-lg shadow-2xl w-[600px] h-[400px] overflow-hidden"
      style={{ top: position.y, left: position.x, zIndex }}
      onClick={() => onFocus(id)}
    >
      <div
        className="h-8 bg-gray-700 flex items-center justify-between px-2 cursor-move"
        onMouseDown={handleMouseDown}
      >
        <span className="font-semibold text-sm flex items-center gap-1">{title}</span>
        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => onClose(id)}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <div className="h-[calc(100%-2rem)]">
        {children}
      </div>
    </div>
  );
};


// --- Main OS Shell Component ---

const APPS = {
  ansmo: { id: 'ansmo', title: 'ANSMO Dashboard', icon: BrainCircuit, component: <AnsmoDashboardApp /> },
  extractor: { id: 'extractor', title: 'Knowledge Extractor', icon: FileText, component: <KnowledgeExtractorApp /> },
};

export default function PxOsShell() {
  const [openWindows, setOpenWindows] = useState<any[]>([]);
  const [focusOrder, setFocusOrder] = useState<string[]>([]);
  
  const openApp = (appId: string) => {
    if (focusOrder.includes(appId)) {
       // If app is open, just bring to front
       setFocusOrder([appId, ...focusOrder.filter(id => id !== appId)]);
       return;
    }
    
    const app = Object.values(APPS).find(a => a.id === appId);
    if (app) {
      const newWindow = {
        ...app,
        initialPosition: { x: 150 + openWindows.length * 40, y: 100 + openWindows.length * 40 },
      };
      setOpenWindows([...openWindows, newWindow]);
      setFocusOrder([appId, ...focusOrder]);
    }
  };

  const closeApp = (id: string) => {
    setOpenWindows(openWindows.filter(w => w.id !== id));
    setFocusOrder(focusOrder.filter(focusId => focusId !== id));
  };
  
  const focusApp = (id: string) => {
    if (focusOrder[0] === id) return; // Already in focus
    setFocusOrder([id, ...focusOrder.filter(focusId => focusId !== id)]);
  };
  
  const getZIndex = (id: string) => {
      const index = focusOrder.indexOf(id);
      if (index === -1) return 10; // Default z-index for non-focused/new
      return 20 + focusOrder.length - index; // Higher z-index for more recent focus
  };

  return (
    <div className="relative w-full h-screen bg-gray-900 text-white overflow-hidden" style={{
        backgroundImage: 'radial-gradient(circle at top left, rgba(63, 94, 251, 0.2), transparent 40%), radial-gradient(circle at bottom right, rgba(252, 70, 107, 0.2), transparent 40%)'
    }}>
      <div className="absolute top-0 left-0 right-0 h-8 bg-black/30 backdrop-blur-sm flex items-center justify-between px-4">
          <div className="font-bold text-lg">pxOS</div>
          <div className="text-sm">{new Date().toLocaleString()}</div>
      </div>

      {openWindows.map((win) => (
        <SimulatedWindow
          key={win.id}
          id={win.id}
          title={win.title}
          initialPosition={win.initialPosition}
          onClose={closeApp}
          onFocus={focusApp}
          zIndex={getZIndex(win.id)}
        >
          {win.component}
        </SimulatedWindow>
      ))}
      
      {/* App Dock */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
        <div className="flex items-center gap-2 p-2 bg-black/40 backdrop-blur-md rounded-xl border border-white/10">
          {Object.values(APPS).map(app => (
             <Button key={app.id} variant="ghost" className="h-14 w-14 flex flex-col items-center gap-1" onClick={() => openApp(app.id)}>
                <app.icon className="h-6 w-6" />
                <span className="text-xs">{app.title.split(' ')[0]}</span>
             </Button>
          ))}
        </div>
      </div>
    </div>
  );
}