import React, { useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardContent, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Play, Terminal, CircleCheck, CircleX } from 'lucide-react';

// --- Frontend Models mirroring Backend Pydantic Models ---

interface PerformPOSTInput {
    system_component_vectors: { [key: string]: any };
}

interface LoadBootSectorInput {
    boot_device_vector: { [key: string]: any };
    sector_size?: number;
}

interface DecompressKernelInput {
    compressed_kernel_vector: number[];
    compression_algorithm_vector?: string;
}

interface ExecuteOpcodeRequest {
    opcode_name: string;
    inputs: { [key: string]: any };
}

interface ExecuteOpcodeResponse {
    opcode_name: string;
    outputs?: { [key: string]: any };
    success: boolean;
    message: string;
    execution_time_ms: number;
    error_details?: string;
}

// --- Opcode Definitions (Frontend representation of backend capabilities) ---
// These should ideally be fetched from a /opcodes endpoint in a real app
const opcodeDefinitions = {
    "PERFORM_POWER_ON_SELF_TEST_OPCODE": {
        inputSchema: {
            "system_component_vectors": {
                type: "json",
                description: "JSON string representing system component vectors (e.g., {'cpu': {'status': 'ok'}, 'memory': {'status': 'error'}})",
                default: JSON.stringify({ "cpu": { "status": "ok" }, "memory": { "status": "ok" }, "storage": { "status": "ok" } }, null, 2)
            }
        },
        description: "Simulates hardware power-on self-test."
    },
    "LOAD_BOOT_SECTOR_OPCODE": {
        inputSchema: {
            "boot_device_vector": {
                type: "json",
                description: "JSON string identifying the boot device (e.g., {'device_id': 'sda1', 'status': 'ok'})",
                default: JSON.stringify({ "device_id": "sda1", "status": "ok" }, null, 2)
            },
            "sector_size": {
                type: "number",
                description: "Simulated sector size in bytes (default: 512)",
                default: 512
            }
        },
        description: "Simulates loading the boot sector from a device."
    },
    "DECOMPRESS_KERNEL_OPCODE": {
        inputSchema: {
            "compressed_kernel_vector": {
                type: "json",
                description: "JSON array of numbers representing compressed kernel bytes (e.g., [31, 139, 8, 0, ...])",
                default: JSON.stringify(Array.from({ length: 100 }, (_, i) => i % 256)) // Mock compressed data
            },
            "compression_algorithm_vector": {
                type: "string",
                description: "Simulated compression algorithm (default: gzip_like)",
                default: "gzip_like"
            }
        },
        description: "Simulates decompressing a kernel image."
    },
    "BIOS_UEFI_BOOT_WORKFLOW": {
        inputSchema: {
            "system_component_vectors": {
                type: "json",
                description: "JSON string representing initial system component states for POST (e.g., {'cpu': {'status': 'ok'}, 'memory': {'status': 'ok'}, 'storage': {'status': 'ok'}})",
                default: JSON.stringify({ "cpu": { "status": "ok" }, "memory": { "status": "ok" }, "storage": { "status": "ok" } }, null, 2)
            },
            "boot_device_vector": {
                type: "json",
                description: "JSON string identifying the boot device (e.g., {'device_id': 'sda1', 'status': 'ok'})",
                default: JSON.stringify({ "device_id": "sda1", "status": "ok" }, null, 2)
            },
            "sector_size": {
                type: "number",
                description: "Simulated sector size in bytes (default: 512)",
                default: 512
            }
        },
        description: "Orchestrates BIOS/UEFI boot stages (POST, hardware init, boot sector load)."
    }
};

const API_BASE_URL = "http://localhost:8001"; // FastAPI server runs on 8001

export default function OpcodeExecutorUI() {
    const [selectedOpcode, setSelectedOpcode] = useState<string>("");
    const [inputValues, setInputValues] = useState<{ [key: string]: any }>({});
    const [executionResult, setExecutionResult] = useState<ExecuteOpcodeResponse | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    // Initialize input values with defaults when selectedOpcode changes
    useEffect(() => {
        if (selectedOpcode && opcodeDefinitions[selectedOpcode]) {
            const defaults: { [key: string]: any } = {};
            for (const key in opcodeDefinitions[selectedOpcode].inputSchema) {
                const schema = opcodeDefinitions[selectedOpcode].inputSchema[key];
                if (schema.default !== undefined) {
                    defaults[key] = schema.default;
                }
            }
            setInputValues(defaults);
        } else {
            setInputValues({});
        }
        setExecutionResult(null);
        setError(null);
    }, [selectedOpcode]);

    const handleInputChange = useCallback((key: string, value: any, type: string) => {
        setInputValues(prev => {
            const newValues = { ...prev };
            if (type === "json") {
                try {
                    newValues[key] = JSON.parse(value);
                } catch (e) {
                    // Store as string if invalid JSON for user to correct
                    newValues[key] = value; 
                }
            } else if (type === "number") {
                newValues[key] = Number(value);
            } else {
                newValues[key] = value;
            }
            return newValues;
        });
    }, []);

    const handleSubmit = useCallback(async () => {
        setError(null);
        setExecutionResult(null);
        setIsLoading(true);

        if (!selectedOpcode) {
            setError("Please select an Opcode to execute.");
            setIsLoading(false);
            return;
        }

        try {
            const requestBody: ExecuteOpcodeRequest = {
                opcode_name: selectedOpcode,
                inputs: inputValues
            };
            
            // Validate JSON inputs before sending
            for (const key in opcodeDefinitions[selectedOpcode].inputSchema) {
                if (opcodeDefinitions[selectedOpcode].inputSchema[key].type === "json") {
                    try {
                        JSON.parse(JSON.stringify(inputValues[key])); // Attempt to re-stringify to catch non-JSON objects
                    } catch {
                        throw new Error(`Invalid JSON input for field '${key}'. Please correct it.`);
                    }
                }
            }

            const response = await fetch(`${API_BASE_URL}/vector-kernel/execute-opcode`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestBody),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.detail || `Server error: ${response.status} ${response.statusText}`);
            }

            const data: ExecuteOpcodeResponse = await response.json();
            setExecutionResult(data);
        } catch (e: any) { // eslint-disable-line @typescript-eslint/no-explicit-any
            console.error("Opcode execution failed:", e);
            setError(e.message || "An unexpected error occurred during opcode execution.");
        } finally {
            setIsLoading(false);
        }
    }, [selectedOpcode, inputValues]);

    return (
        <Card className="w-full max-w-4xl mx-auto shadow-lg">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2 text-2xl">
                    <Terminal className="h-6 w-6" /> Vector Kernel Opcode Executor
                </CardTitle>
                <CardDescription className="text-blue-100">
                    Execute individual atomic Opcodes from the VectorBoot simulation and observe their direct outputs.
                </CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
                <div className="grid gap-2">
                    <Label htmlFor="opcode-select">Select Opcode</Label>
                    <Select value={selectedOpcode} onValueChange={setSelectedOpcode} disabled={isLoading}>
                        <SelectTrigger id="opcode-select" className="w-full">
                            <SelectValue placeholder="Choose an Opcode" />
                        </SelectTrigger>
                        <SelectContent>
                            {Object.keys(opcodeDefinitions).map(opcodeName => (
                                <SelectItem key={opcodeName} value={opcodeName}>
                                    {opcodeName} - {opcodeDefinitions[opcodeName].description}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>

                {selectedOpcode && opcodeDefinitions[selectedOpcode] && (
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold border-b pb-2">Opcode Inputs for "{selectedOpcode}"</h3>
                        {Object.keys(opcodeDefinitions[selectedOpcode].inputSchema).map(inputKey => {
                            const schema = opcodeDefinitions[selectedOpcode].inputSchema[inputKey];
                            const isJson = schema.type === "json";
                            const isNumber = schema.type === "number";
                            const value = inputValues[inputKey] !== undefined
                                ? (isJson ? JSON.stringify(inputValues[inputKey], null, 2) : String(inputValues[inputKey]))
                                : (isJson ? schema.default : schema.default);

                            return (
                                <div key={inputKey} className="grid gap-2">
                                    <Label htmlFor={`input-${inputKey}`} className="flex items-center gap-1">
                                        {inputKey} <span className="text-muted-foreground text-sm">({isJson ? "JSON" : isNumber ? "Number" : "String"})</span>
                                    </Label>
                                    {isJson ? (
                                        <Textarea
                                            id={`input-${inputKey}`}
                                            value={value}
                                            onChange={(e) => handleInputChange(inputKey, e.target.value, schema.type)}
                                            rows={5}
                                            className="font-mono text-sm"
                                            disabled={isLoading}
                                        />
                                    ) : (
                                        <Input
                                            id={`input-${inputKey}`}
                                            type={isNumber ? "number" : "text"}
                                            value={value}
                                            onChange={(e) => handleInputChange(inputKey, e.target.value, schema.type)}
                                            disabled={isLoading}
                                        />
                                    )}
                                    <p className="text-sm text-muted-foreground">{schema.description}</p>
                                </div>
                            );
                        })}
                    </div>
                )}
            </CardContent>
            <CardFooter className="flex justify-end p-6">
                <Button onClick={handleSubmit} disabled={!selectedOpcode || isLoading} className="w-full">
                    {isLoading ? (
                        <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Executing Opcode...
                        </>
                    ) : (
                        <>
                            <Play className="mr-2 h-4 w-4" />
                            Execute Selected Opcode
                        </>
                    )}
                </Button>
            </CardFooter>

            {executionResult && (
                <CardContent className="pt-6 border-t mt-6">
                    <h3 className="text-xl font-semibold mb-3">Execution Result</h3>
                    {executionResult.success ? (
                        <div className="bg-green-50 text-green-700 p-4 rounded-lg border border-green-200 shadow-sm mb-4 flex items-center gap-2">
                            <CircleCheck className="h-5 w-5 text-green-500" />
                            <p className="font-bold">{executionResult.message}</p>
                        </div>
                    ) : (
                        <div className="bg-red-50 text-red-700 p-4 rounded-lg border border-red-200 shadow-sm mb-4 flex items-center gap-2">
                            <CircleX className="h-5 w-5 text-red-500" />
                            <p className="font-bold">{executionResult.message}</p>
                            {executionResult.error_details && <p className="text-sm">Details: {executionResult.error_details}</p>}
                        </div>
                    )}
                    <p className="text-sm mb-4">Execution Time: {executionResult.execution_time_ms.toFixed(2)} ms</p>

                    {executionResult.outputs && (
                        <div className="grid gap-2">
                            <Label>Outputs:</Label>
                            <Textarea
                                readOnly
                                value={JSON.stringify(executionResult.outputs, null, 2)}
                                rows={10}
                                className="font-mono text-sm bg-gray-50 dark:bg-gray-800"
                            />
                        </div>
                    )}
                </CardContent>
            )}

            {error && (
                <CardContent className="pt-4 border-t mt-6">
                    <div className="bg-red-50 text-red-700 p-4 rounded-lg border border-red-200 shadow-sm mb-4 flex items-center gap-2">
                        <CircleX className="h-5 w-5 text-red-500" />
                        <p className="font-bold">Frontend Error:</p>
                        <p className="text-sm">{error}</p>
                    </div>
                </CardContent>
            )}
        </Card>
    );
}
