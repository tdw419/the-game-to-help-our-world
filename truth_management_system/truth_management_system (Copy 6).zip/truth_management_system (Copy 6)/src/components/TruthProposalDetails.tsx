import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Check, X, FileText, ArrowLeft, GitDiff } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';

import { TruthApiClient, TruthChangeProposal, UpdateProposalStatusRequest, TruthDiffRequest } from '../frontend/services/TruthApiClient';

// Assuming a way to get the current user's token (e.g., from context or localStorage)
const getToken = (): string | null => {
  return localStorage.getItem('jwtToken');
};

interface TruthProposalDetailsProps {
  proposalId: number;
  onBack: () => void;
  onProposalUpdated: () => void; // Callback when proposal status changes
}

export default function TruthProposalDetails({ proposalId, onBack, onProposalUpdated }: TruthProposalDetailsProps) {
  const { toast } = useToast();
  const [proposal, setProposal] = useState<TruthChangeProposal | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [diffContent, setDiffContent] = useState<string | null>(null);
  const [isDiffLoading, setIsDiffLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchProposalDetails = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    const token = getToken();
    if (!token) {
      setError("Authentication token is missing. Please log in.");
      setIsLoading(false);
      return;
    }

    try {
      const fetchedProposal = await TruthApiClient.getTruthChangeProposalById(proposalId);
      setProposal(fetchedProposal);
      // Trigger diff fetch if it's an update to an existing truth
      if (fetchedProposal.truth_id) {
        fetchTruthDiff(fetchedProposal.truth_id, fetchedProposal.proposed_content);
      } else {
        setDiffContent("This is a proposal for a new truth, no diff available.");
      }
    } catch (err: any) {
      setError(err.message || "Failed to fetch truth change proposal details.");
      toast({
        title: "Error",
        description: err.message || "Failed to fetch proposal.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [proposalId, toast]);

  const fetchTruthDiff = useCallback(async (truthId: number, proposedContent: string) => {
    setIsDiffLoading(true);
    setError(null);
    const token = getToken();
    if (!token) {
      setError("Authentication token is missing. Please log in.");
      setIsDiffLoading(false);
      return;
    }

    try {
      const diffRequest: TruthDiffRequest = { truth_id: truthId, proposed_content: proposedContent };
      const diffResponse = await TruthApiClient.getTruthDiff(diffRequest);
      setDiffContent(diffResponse.diff);
    } catch (err: any) {
      setDiffContent("Failed to load diff: " + (err.message || "An error occurred."));
      toast({
        title: "Error",
        description: err.message || "Failed to load diff.",
        variant: "destructive",
      });
    } finally {
      setIsDiffLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchProposalDetails();
  }, [fetchProposalDetails]);

  const handleUpdateStatus = async (status: UpdateProposalStatusRequest['status']) => {
    if (!proposal || proposal.id === undefined) return;

    setIsUpdatingStatus(true);
    const token = getToken();
    if (!token) {
      toast({
        title: "Authentication Error",
        description: "You must be logged in to update proposal status.",
        variant: "destructive",
      });
      setIsUpdatingStatus(false);
      return;
    }

    try {
      const updatedProposal = await TruthApiClient.updateTruthChangeProposalStatus(proposal.id, { status });
      setProposal(updatedProposal);
      toast({
        title: "Status Updated",
        description: `Proposal status changed to ${status}.`,
      });
      onProposalUpdated(); // Notify parent to refresh list
    } catch (err: any) {
      toast({
        title: "Update Failed",
        description: err.message || "Failed to update proposal status.",
        variant: "destructive",
      });
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const getStatusVariant = (status: TruthChangeProposal['status']) => {
    switch (status) {
      case 'approved':
        return 'default';
      case 'under_review':
        return 'secondary';
      case 'rejected':
        return 'destructive';
      default':
        return 'outline';
    }
  };

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Proposal Details</CardTitle>
          <CardDescription>Loading...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center items-center h-40">
          <Loader2 className="h-8 w-8 animate-spin" />
        </CardContent>
      </Card>
    );
  }

  if (error || !proposal) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Proposal Details</CardTitle>
          <CardDescription>Error loading details.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-red-500">{error || "Proposal not found."}</p>
          <Button onClick={onBack} className="mt-4">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Proposals
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <Button variant="outline" size="sm" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to List
          </Button>
          <CardTitle className="text-2xl font-bold flex items-center">
            <FileText className="mr-2 h-6 w-6" /> Proposal #{proposal.id}
          </CardTitle>
          <Badge variant={getStatusVariant(proposal.status)}>{proposal.status}</Badge>
        </div>
        <CardDescription>Details for truth change proposal #{proposal.id}</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4">
        <div className="grid gap-2">
          <Label>Proposed Truth ID:</Label>
          <p className="font-semibold">{proposal.truth_id || "New Truth"}</p>
        </div>
        <div className="grid gap-2">
          <Label>Rationale:</Label>
          <p className="whitespace-pre-wrap">{proposal.rationale}</p>
        </div>
        <div className="grid gap-2">
          <Label>Proposed Content:</Label>
          <ScrollArea className="h-60 rounded-md border p-4 font-mono text-sm bg-gray-50">
            <pre>{proposal.proposed_content}</pre>
          </ScrollArea>
        </div>

        {proposal.truth_id && (
            <div className="grid gap-2">
                <Label className="flex items-center"><GitDiff className="mr-2 h-4 w-4" /> Content Diff:</Label>
                {isDiffLoading ? (
                    <div className="flex justify-center items-center h-20">
                        <Loader2 className="h-6 w-6 animate-spin" />
                    </div>
                ) : diffContent ? (
                    <ScrollArea className="h-60 rounded-md border p-4 font-mono text-sm bg-gray-50">
                        <pre>
                            {diffContent.split('\n').map((line, index) => (
                                <span key={index} className={
                                    line.startsWith('+') ? 'text-green-600' :
                                    line.startsWith('-') ? 'text-red-600' :
                                    ''
                                }>
                                    {line}<br />
                                </span>
                            ))}
                        </pre>
                    </ScrollArea>
                ) : (
                    <p>No diff content available.</p>
                )}
            </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-end gap-2">
        {(proposal.status === 'draft' || proposal.status === 'under_review') && (
          <>
            <Button
              variant="destructive"
              onClick={() => handleUpdateStatus('rejected')}
              disabled={isUpdatingStatus}
            >
              {isUpdatingStatus ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <X className="mr-2 h-4 w-4" />}
              Reject
            </Button>
            <Button
              variant="default"
              onClick={() => handleUpdateStatus('approved')}
              disabled={isUpdatingStatus}
            >
              {isUpdatingStatus ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Check className="mr-2 h-4 w-4" />}
              Approve
            </Button>
          </>
        )}
        {proposal.status === 'approved' && (
          <Badge variant="default" className="text-base py-1 px-3">Approved</Badge>
        )}
        {proposal.status === 'rejected' && (
          <Badge variant="destructive" className="text-base py-1 px-3">Rejected</Badge>
        )}
      </CardFooter>
    </Card>
  );
}
