import React, { useState } from 'react';
import { Button, Input, Textarea, Label, Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui';
import { Loader2, Sparkles } from 'lucide-react';

const LLMOSBuilder: React.FC = () => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleThink = async () => {
    if (!query.trim()) {
      setError('Please enter a query.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const token = 'token_your_username'; // Replace with actual token retrieval logic
      const response = await fetch('http://localhost:8001/abstraction/think', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token,
        },
        body: JSON.stringify({ query }),
      });

      if (!response.ok) {
        throw new Error('Failed to think.');
      }

      const data = await response.json();
      setResult(data.result);
    } catch (err) {
      setError(err.message || 'An error occurred while thinking.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>LLMOS Builder</CardTitle>
        <CardDescription>Design and implement the Vector Kernel for LLMOS.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid w-full gap-4">
          <Label htmlFor="query">Query</Label>
          <Textarea
            id="query"
            placeholder="Enter your query here..."
            rows={4}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          {error && <p className="text-red-500 text-sm">{error}</p>}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          onClick={handleThink}
          disabled={loading || !query.trim()}
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Thinking...
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4 mr-2" /> Think
            </>
          )}
        </Button>
      </CardFooter>
      {result && (
        <CardContent>
          <div className="bg-gray-100 p-4 rounded">
            <p>{result}</p>
          </div>
        </CardContent>
      )}
    </Card>
  );
};

export default LLMOSBuilder;
