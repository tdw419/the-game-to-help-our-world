import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, ArrowRight, BookOpen, Target, Activity, GraduationCap, Loader2 } from 'lucide-react';

// Re-using the PedagogicalInsightProps interface
interface PedagogicalInsightProps {
  systemMaturationRoadmap: {
    currentPhase: {
      conceptValidationComplete: number;
      mockArchitectureProven: number;
      dependencyGraphEstablished: number;
    };
    nextPedagogicalPhase: {
      replaceMocksWithRealImplementations: number;
      establishObservabilityFoundations: number;
      implementHumanFeedbackLoops: number;
    };
    eventualAdvancedTopics: {
      emergentBehaviorManagement: number;
      multiAgentCoordination: number;
      metaCognitiveReflection: number;
      autonomousGoalRefinement: number;
    };
  };
  nextLessonPlan: {
    learningObjective: string;
    prerequisitesMet: number;
    coreConcepts: {
      realDataPersistence: number;
      actualAnomalyDetection: number;
      liveAiGeneration: number;
    };
    scaffoldedActivities: {
      icmBackendAsVisualFeedback: number;
      lancedbIntegrationAsDataManagement: number;
      lmStudioWiringAsCognitiveExtension: number;
    };
    assessmentCriteria: {
      systemCanDetectRealAnomalies: number;
      aiCanGenerateWorkingKernels: number;
      humanCanMonitorAndIntervene: number;
    };
  };
}

// Re-using the PedagogicalInsightDisplay component
const PedagogicalInsightDisplay: React.FC<PedagogicalInsightProps> = ({
  systemMaturationRoadmap,
  nextLessonPlan,
}) => {
  const renderConfidence = (confidence: number) => {
    const color = confidence >= 0.9 ? 'bg-green-500' : confidence >= 0.7 ? 'bg-yellow-500' : 'bg-red-500';
    return (
      <Badge className={`${color} text-white`}>
        {(confidence * 100).toFixed(0)}%
      </Badge>
    );
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <GraduationCap className="h-6 w-6 text-blue-500" /> System Maturation Roadmap
          </CardTitle>
          <CardDescription>Tracing the autonomous system's learning journey.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold text-lg flex items-center gap-1 mb-2">
              <CheckCircle className="h-5 w-5 text-green-600" /> Current Phase
            </h3>
            <ul className="space-y-1 text-sm">
              <li className="flex justify-between items-center">
                Concept Validation Complete {renderConfidence(systemMaturationRoadmap.currentPhase.conceptValidationComplete)}
              </li>
              <li className="flex justify-between items-center">
                Mock Architecture Proven {renderConfidence(systemMaturationRoadmap.currentPhase.mockArchitectureProven)}
              </li>
              <li className="flex justify-between items-center">
                Dependency Graph Established {renderConfidence(systemMaturationRoadmap.currentPhase.dependencyGraphEstablished)}
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-lg flex items-center gap-1 mb-2">
              <ArrowRight className="h-5 w-5 text-indigo-600" /> Next Pedagogical Phase
            </h3>
            <ul className="space-y-1 text-sm">
              <li className="flex justify-between items-center">
                Replace Mocks with Real Implementations {renderConfidence(systemMaturationRoadmap.nextPedagogicalPhase.replaceMocksWithRealImplementations)}
              </li>
              <li className="flex justify-between items-center">
                Establish Observability Foundations {renderConfidence(systemMaturationRoadmap.nextPedagogicalPhase.establishObservabilityFoundations)}
              </li>
              <li className="flex justify-between items-center">
                Implement Human Feedback Loops {renderConfidence(systemMaturationRoadmap.nextPedagogicalPhase.implementHumanFeedbackLoops)}
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-lg flex items-center gap-1 mb-2">
              <BookOpen className="h-5 w-5 text-purple-600" /> Eventual Advanced Topics
            </h3>
            <ul className="space-y-1 text-sm">
              <li className="flex justify-between items-center">
                Emergent Behavior Management {renderConfidence(systemMaturationRoadmap.eventualAdvancedTopics.emergentBehaviorManagement)}
              </li>
              <li className="flex justify-between items-center">
                Multi-Agent Coordination {renderConfidence(systemMaturationRoadmap.eventualAdvancedTopics.multiAgentCoordination)}
              </li>
              <li className="flex justify-between items-center">
                Meta-Cognitive Reflection {renderConfidence(systemMaturationRoadmap.eventualAdvancedTopics.metaCognitiveReflection)}
              </li>
              <li className="flex justify-between items-center">
                Autonomous Goal Refinement {renderConfidence(systemMaturationRoadmap.eventualAdvancedTopics.autonomousGoalRefinement)}
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <Target className="h-6 w-6 text-green-500" /> Next Lesson Plan: <span className="font-normal text-base text-gray-700">{nextLessonPlan.learningObjective}</span>
          </CardTitle>
          <CardDescription>A focused curriculum for immediate system development.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold text-lg flex items-center gap-1 mb-2">
              <CheckCircle className="h-5 w-5 text-green-600" /> Prerequisites Met {renderConfidence(nextLessonPlan.prerequisitesMet)}
            </h3>
          </div>
          <div>
            <h3 className="font-semibold text-lg flex items-center gap-1 mb-2">
              <BookOpen className="h-5 w-5 text-orange-600" /> Core Concepts
            </h3>
            <ul className="space-y-1 text-sm">
              <li className="flex justify-between items-center">
                Real Data Persistence {renderConfidence(nextLessonPlan.coreConcepts.realDataPersistence)}
              </li>
              <li className="flex justify-between items-center">
                Actual Anomaly Detection {renderConfidence(nextLessonPlan.coreConcepts.actualAnomalyDetection)}
              </li>
              <li className="flex justify-between items-center">
                Live AI Generation {renderConfidence(nextLessonPlan.coreConcepts.liveAiGeneration)}
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-lg flex items-center gap-1 mb-2">
              <Activity className="h-5 w-5 text-teal-600" /> Scaffolded Activities
            </h3>
            <ul className="space-y-1 text-sm">
              <li className="flex justify-between items-center">
                ICM Backend as Visual Feedback {renderConfidence(nextLessonPlan.scaffoldedActivities.icmBackendAsVisualFeedback)}
              </li>
              <li className="flex justify-between items-center">
                LanceDB Integration as Data Management {renderConfidence(nextLessonPlan.scaffoldedActivities.lancedbIntegrationAsDataManagement)}
              </li>
              <li className="flex justify-between items-center">
                LM Studio Wiring As Cognitive Extension {renderConfidence(nextLessonPlan.scaffoldedActivities.lmStudioWiringAsCognitiveExtension)}
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-lg flex items-center gap-1 mb-2">
              <BookOpen className="h-5 w-5 text-red-600" /> Assessment Criteria
            </h3>
            <ul className="space-y-1 text-sm">
              <li className="flex justify-between items-center">
                System Can Detect Real Anomalies {renderConfidence(nextLessonPlan.assessmentCriteria.systemCanDetectRealAnomalies)}
              </li>
              <li className="flex justify-between items-center">
                AI Can Generate Working Kernels {renderConfidence(nextLessonPlan.assessmentCriteria.aiCanGenerateWorkingKernels)}
              </li>
              <li className="flex justify-between items-center">
                Human Can Monitor And Intervene {renderConfidence(nextLessonPlan.assessmentCriteria.humanCanMonitorAndIntervene)}
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// --- START: Simulate pxOS API Calls for Opcodes ---
// In a real application, this would be actual API calls to your backend
// which then uses the default_api.execute_Opcode.

interface SimulatedExecutionResponse {
  content: any; // The output of the opcode
  success: boolean;
  error?: string;
}

const simulatePxOSApiCall = async (
  opcodeName: string,
  input: any
): Promise<SimulatedExecutionResponse> => {
  await new Promise(resolve => setTimeout(resolve, 750)); // Simulate network latency

  if (opcodeName === "AGGREGATE_SYSTEM_STATE") {
    const limit_executions = input.limit_executions || 10;

    // Simulate calling default_api.read_Execution here
    const mockExecutionRecordsFromDb = [
      {"opcode_name": "GENERATE_KERNELS", "success": true, "confidence": 0.92, "execution_time": 2.1},
      {"opcode_name": "GENERATE_KERNELS", "success": true, "confidence": 0.89, "execution_time": 2.3},
      {"opcode_name": "ANOMALY_DETECTION", "success": true, "confidence": 0.88, "execution_time": 0.5},
      {"opcode_name": "ANOMALY_DETECTION", "success": true, "confidence": 0.91, "execution_time": 0.6},
      {"opcode_name": "DATA_PERSISTENCE", "success": true, "confidence": 0.95, "execution_time": 0.3},
      {"opcode_name": "DATA_PERSISTENCE", "success": true, "confidence": 0.93, "execution_time": 0.4},
      {"opcode_name": "GENERATE_KERNELS", "success": false, "confidence": 0.60, "execution_time": 3.0}, // A recent failure
      {"opcode_name": "QUERY_DATA", "success": true, "confidence": 0.91, "execution_time": 1.8},
      {"opcode_name": "CODE_REVIEW", "success": true, "confidence": 0.75, "execution_time": 0.7},
      {"opcode_name": "METRIC_COLLECTION", "success": true, "confidence": 0.99, "execution_time": 0.1},
    ];

    const execution_history_processed = mockExecutionRecordsFromDb
      .slice(0, limit_executions)
      .map(record => ({
        opcode_name: record.opcode_name,
        success: record.success,
        confidence: record.confidence,
        execution_time: record.execution_time
      }));

    const system_metrics_data = input.include_metrics ? (() => {
      const successful_executions = execution_history_processed.filter(e => e.success);
      const total_executions = execution_history_processed.length;
      const avg_exec_time = total_executions > 0 ?
        execution_history_processed.reduce((sum, e) => sum + (e.execution_time || 0), 0) / total_executions : 0;
      const success_rate = total_executions > 0 ? successful_executions.length / total_executions : 0;

      return {
        success_rate: parseFloat(success_rate.toFixed(2)),
        average_execution_time: parseFloat(avg_exec_time.toFixed(2)),
        resource_utilization: {
          cpu_percent: 42,
          memory_percent: 68
        },
        anomaly_detection_score: 0.83
      };
    })() : {};

    const current_goals_data = input.include_goals ? [
      "Refine real-time data persistence",
      "Improve kernel generation efficiency",
      "Enhance human oversight mechanisms",
      "Stabilize novel kernel generation"
    ] : [];

    return {
      success: true,
      content: {
        execution_history: execution_history_processed,
        system_metrics: system_metrics_data,
        current_goals: current_goals_data
      }
    };
  } else if (opcodeName === "GENERATE_PEDAGOGICAL_INSIGHTS") {
    const { execution_history, system_metrics, current_goals } = input;

    const hasRecentKernelFailure = execution_history.some((exec: any) =>
      exec.opcode_name === "GENERATE_KERNELS" && !exec.success
    );
    const kernelGenConfidence = hasRecentKernelFailure ? 0.70 : 0.85;

    const overallSuccessInfluence = system_metrics.success_rate || 1.0; // Default to 1 if not provided

    const pedagogicalInsights: PedagogicalInsightProps = {
      systemMaturationRoadmap: {
        currentPhase: {
          conceptValidationComplete: 0.98,
          mockArchitectureProven: parseFloat((0.96 * overallSuccessInfluence + 0.04).toFixed(2)),
          dependencyGraphEstablished: 0.94,
        },
        nextPedagogicalPhase: {
          replaceMocksWithRealImplementations: 0.80,
          establishObservabilityFoundations: 0.78,
          implementHumanFeedbackLoops: 0.87,
        },
        eventualAdvancedTopics: {
          emergentBehaviorManagement: 0.68,
          multiAgentCoordination: 0.65,
          metaCognitiveReflection: 0.60,
          autonomousGoalRefinement: 0.58,
        },
      },
      nextLessonPlan: {
        learningObjective: "Transition from mock demonstrations to real autonomous capability",
        prerequisitesMet: 0.97,
        coreConcepts: {
          realDataPersistence: 0.85,
          actualAnomalyDetection: system_metrics.anomaly_detection_score || 0.0,
          liveAiGeneration: kernelGenConfidence,
        },
        scaffoldedActivities: {
          icmBackendAsVisualFeedback: 0.92,
          lancedbIntegrationAsDataManagement: 0.78,
          lmStudioWiringAsCognitiveExtension: 0.72,
        },
        assessmentCriteria: {
          systemCanDetectRealAnomalies: system_metrics.anomaly_detection_score || 0.0,
          aiCanGenerateWorkingKernels: kernelGenConfidence,
          humanCanMonitorAndIntervene: 0.93,
        },
      },
    };
    return { success: true, content: pedagogicalInsights };
  }

  return { success: false, error: `Unknown opcode: ${opcodeName}` };
};
// --- END: Simulate pxOS API Calls for Opcodes ---


export default function AutonomousSystemICM() {
  const [data, setData] = useState<PedagogicalInsightProps | null>(null);
  const [loadingMessage, setLoadingMessage] = useState("Initializing system...");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPedagogicalData = async () => {
      setError(null);
      try {
        setLoadingMessage("Aggregating system state from data sources...");
        // Simulate calling default_api.execute_Opcode for AGGREGATE_SYSTEM_STATE
        const aggregateResponse = await simulatePxOSApiCall("AGGREGATE_SYSTEM_STATE", {
          limit_executions: 10,
          time_period_minutes: 30, // Not used in simulation, but for API clarity
          include_metrics: true,
          include_goals: true,
        });

        if (!aggregateResponse.success) {
          throw new Error(aggregateResponse.error || "Failed to aggregate system state.");
        }
        const aggregatedState = aggregateResponse.content;

        setLoadingMessage("Generating pedagogical insights from aggregated data...");
        // Simulate calling default_api.execute_Opcode for GENERATE_PEDAGOGICAL_INSIGHTS
        const insightsResponse = await simulatePxOSApiCall("GENERATE_PEDAGOGICAL_INSIGHTS", aggregatedState);

        if (!insightsResponse.success) {
          throw new Error(insightsResponse.error || "Failed to generate pedagogical insights.");
        }
        const pedagogicalInsights: PedagogicalInsightProps = insightsResponse.content;

        setData(pedagogicalInsights);

      } catch (err) {
        setError(`Error: ${err instanceof Error ? err.message : String(err)}`);
        console.error(err);
      } finally {
        setLoadingMessage("");
      }
    };

    fetchPedagogicalData();
  }, []);

  return (
    <div className="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
      <header className="p-6 text-center bg-white shadow-sm mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Autonomous System: Intelligent Curriculum Monitor (ICM)</h1>
        <p className="text-gray-600 mt-2">Applying pedagogical principles to AI system development.</p>
      </header>

      {loadingMessage && (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-10 w-10 animate-spin text-blue-500" />
          <span className="ml-3 text-lg text-gray-600">{loadingMessage}</span>
        </div>
      )}
      {error && (
        <div className="text-center text-red-500 p-4">
          Error: {error}
        </div>
      )}
      {data && (
        <PedagogicalInsightDisplay
          systemMaturationRoadmap={data.systemMaturationRoadmap}
          nextLessonPlan={data.nextLessonPlan}
        />
      )}

      <footer className="p-4 text-center text-gray-500 text-sm mt-8">
        &copy; {new Date().getFullYear()} pxOS. All rights reserved.
      </footer>
    </div>
  );
}
