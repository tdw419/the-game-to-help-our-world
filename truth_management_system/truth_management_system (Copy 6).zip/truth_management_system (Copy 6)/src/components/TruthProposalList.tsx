import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ListChecks, Eye, Loader2, RefreshCw } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

import { TruthApiClient, TruthChangeProposal } from '../frontend/services/TruthApiClient';

// Assuming a way to get the current user's token (e.g., from context or localStorage)
const getToken = (): string | null => {
  return localStorage.getItem('jwtToken');
};

interface TruthProposalListProps {
  onSelectProposal: (proposalId: number) => void;
}

export default function TruthProposalList({ onSelectProposal }: TruthProposalListProps) {
  const { toast } = useToast();
  const [proposals, setProposals] = useState<TruthChangeProposal[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProposals = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    const token = getToken();
    if (!token) {
      setError("Authentication token is missing. Please log in.");
      setIsLoading(false);
      return;
    }

    try {
      const fetchedProposals = await TruthApiClient.listTruthChangeProposals();
      setProposals(fetchedProposals);
    } catch (err: any) {
      setError(err.message || "Failed to fetch truth change proposals.");
      toast({
        title: "Error",
        description: err.message || "Failed to fetch truth change proposals.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchProposals();
  }, [fetchProposals]);

  const getStatusVariant = (status: TruthChangeProposal['status']) => {
    switch (status) {
      case 'approved':
        return 'default'; // Green-ish
      case 'under_review':
        return 'secondary'; // Grey-ish
      case 'rejected':
        return 'destructive'; // Red-ish
      default':
        return 'outline'; // Default or blue-ish
    }
  };

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Truth Change Proposals</CardTitle>
          <CardDescription>Loading...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center items-center h-40">
          <Loader2 className="h-8 w-8 animate-spin" />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Truth Change Proposals</CardTitle>
          <CardDescription>Error loading proposals.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-red-500">{error}</p>
          <Button onClick={fetchProposals} className="mt-4">
            <RefreshCw className="mr-2 h-4 w-4" /> Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-2xl font-bold flex items-center">
          <ListChecks className="mr-2 h-6 w-6" /> Truth Change Proposals
        </CardTitle>
        <Button onClick={fetchProposals} variant="outline" size="sm">
          <RefreshCw className="mr-2 h-4 w-4" /> Refresh
        </Button>
      </CardHeader>
      <CardContent>
        {proposals.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No truth change proposals found.</p>
        ) : (
          <ScrollArea className="h-[400px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">ID</TableHead>
                  <TableHead>Proposed Truth ID</TableHead>
                  <TableHead>Rationale</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created At</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {proposals.map((proposal) => (
                  <TableRow key={proposal.id}>
                    <TableCell className="font-medium">{proposal.id}</TableCell>
                    <TableCell>{proposal.truth_id || 'New Truth'}</TableCell>
                    <TableCell className="max-w-[300px] truncate">{proposal.rationale}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusVariant(proposal.status)}>{proposal.status}</Badge>
                    </TableCell>
                    <TableCell>{new Date(proposal.created_at).toLocaleString()}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" onClick={() => proposal.id && onSelectProposal(proposal.id)}>
                        <Eye className="mr-2 h-4 w-4" /> View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        )}
      </CardContent>
      <CardFooter>
        <p className="text-sm text-muted-foreground">Total proposals: {proposals.length}</p>
      </CardFooter>
    </Card>
  );
}