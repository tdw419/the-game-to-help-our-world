import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Play, CheckCircle, XCircle, Loader2, Database, Cpu, Layers, Brain, HardDrive, Zap, Info, ChevronRight
} from 'lucide-react';

// Assuming default_api is available globally or imported from a client library
declare const default_api: any;

// Conceptual helper to simulate retrieving detailed vector metadata from the backend
// In a real scenario, this would be an API call to an endpoint that wraps backend.vector_db_client.retrieve_vector
const retrieveVectorDetails = async (vectorId: string): Promise<any> => {
  await new Promise(resolve => setTimeout(resolve, 200)); // Simulate async fetch

  // Mock data based on the conceptual schemas
  if (vectorId.startsWith("cpu_state_")) {
    const pcMatch = vectorId.match(/cpu_state_([0-9a-fA-F]+)_/);
    const mockPC = pcMatch ? parseInt(pcMatch[1], 16) : Math.floor(Math.random() * 0xFFFFFFFF);
    return {
      vector_id: vectorId,
      vector_type: "CPU_STATE_VEC_SCHEMA",
      metadata: {
        registers: {
          EAX: Math.floor(Math.random() * 100),
          EBX: Math.floor(Math.random() * 100),
          ECX: Math.floor(Math.random() * 100),
          EDX: Math.floor(Math.random() * 100),
          EIP: mockPC,
          ESP: 0x7FFFFFFF - Math.floor(Math.random() * 1000),
        },
        flags: { CF: false, PF: true, AF: false, ZF: (mockPC % 2 === 0), SF: true, OF: false },
        program_counter: mockPC,
        last_executed_instruction_id: `instr_hash_${Math.random().toString(16).substring(2,10)}`,
        active_memory_pages: [`page_vec_${Math.random().toString(16).substring(2,6)}`],
      }
    };
  } else if (vectorId.startsWith("sys_instr_vec_")) {
     const rawBytes = vectorId.includes("e9c3e9c3") ? [0x90] : (vectorId.includes("d2d4c0b4") ? [0xb8, 0x01, 0x00, 0x00, 0x00] : [0x8b, 0xc0]);
    const disassembly = vectorId.includes("e9c3e9c3") ? "NOP" : (vectorId.includes("d2d4c0b4") ? "MOV EAX, 0x1" : "MOV EAX, EAX");
    return {
      vector_id: vectorId,
      vector_type: "X86_INSTR_VEC_SCHEMA",
      metadata: {
        hash: vectorId.split('_').pop(),
        disassembly: disassembly,
        raw_bytes: rawBytes,
        opcode_type: disassembly.split(' ')[0],
      }
    };
  } else if (vectorId.startsWith("mem_page_")) {
    return {
      vector_id: vectorId,
      vector_type: "MEMORY_PAGE_VEC_SCHEMA",
      metadata: {
        base_address: Math.floor(Math.random() * 0x100000) * 0x1000,
        size: 4096,
        entropy: Math.random(),
        accessed: true,
        modified: (Math.random() > 0.5),
      }
    };
  }
  return { vector_id: vectorId, metadata: {}, vector_type: "UNKNOWN" };
};
// Define the structure for a boot step
interface BootStep {
  id: string;
  name: string;
  description: string;
  conceptualOpcodeName: string; // The conceptual opcode name for this step
  input: Record<string, any>; // Conceptual input for the simulation opcode
  status: 'idle' | 'running' | 'success' | 'failed';
  result?: string;
  rawResponse?: any; // To store the full API response from the backend
  currentCpuState?: Record<string, any>; // To store parsed CPU state metadata from xIVE execution
  updatedMemoryPages?: Record<string, any>[]; // To store info about updated memory pages (conceptual IDs and details)
  executedInstructions?: Record<string, any>[]; // To store details of instructions executed in this step (IDs and metadata)
  icon: React.ElementType; // Lucide icon component
}

export default function VectorOSBootOrchestrator() {
  const [bootSequence, setBootSequence] = useState<BootStep[]>([
    {
      id: 'step0',
      name: 'VOSK Initialization & Vector DB Setup',
      description: 'The Vector OS Kernel (VOSK) initializes the Vector Compute Engine and core Vector DB. Base system vectors are loaded.',
      conceptualOpcodeName: 'VECTOR_OS_INIT',
      input: {
        environment_type: 'VectorUniverse',
        vector_db_config: 'vectorized_schema_v1',
        initial_system_vectors: ['vosk_core', 'x86_state_template'],
      },
      status: 'idle',
      icon: Database,
    },
    {
      id: 'step1',
      name: 'BIOS Vector Load (via xIVE)',
      description: 'The x86 Instruction Vectorizer & Executor (xIVE) queries the Vector DB for the "BIOS ROM vector." This vector contains the initial instruction vectors for the emulated BIOS.',
      conceptualOpcodeName: 'XIVE_BIOS_LOAD',
      input: {
        boot_device: 'vector_db://bios_rom_vector_id',
      },
      status: 'idle',
      icon: Cpu,
    },
    {
      id: 'step2',
      name: 'Bootloader Vector Execution',
      description: 'The emulated BIOS executes bootloader sectors (represented as disk data vectors from the Vector DB), updating CPU state vectors in the DB. This would include finding and loading the kernel\'s initial image.',
      conceptualOpcodeName: 'XIVE_BOOTLOADER_EXECUTE',
      input: {
        boot_device: 'vector_db://bootloader_sector_vectors',
        kernel_image: 'vector_db://linux_kernel_vector_stub',
        initrd: 'vector_db://initial_ramdisk_vector_stub',
      },
      status: 'idle',
      icon: ChevronRight,
    },
    {
      id: 'step3',
      name: 'Linux Kernel as Code Vectors',
      description: 'The bootloader loads the Linux kernel binary (now represented as code vectors) into emulated memory pages (data vectors in the Vector DB). This involves dynamic allocation and linking of vector segments.',
      conceptualOpcodeName: 'KERNEL_LOAD_VECTORIZED',
      input: {
        kernel_vector_location: 'vector_db://linux_kernel_vector_stub',
        initial_cpu_state_vector: 'vector_db://cpu_state_after_bootloader',
      },
      status: 'idle',
      icon: Layers,
    },
    {
      id: 'step4',
      name: 'Kernel Initialization (via xIVE & V-Syscall/Int)',
      description: 'The xIVE begins executing Linux kernel instruction vectors from the kernel entry point. System calls and interrupts are handled by a "Vector-Native Syscall/Interrupt layer" (V-Syscall/Int), which translates traditional kernel calls into vector operations.',
      conceptualOpcodeName: 'KERNEL_INIT_VECTORIZED',
      input: {
        kernel_entry_point_vector: 'vector_db://kernel_entry_point',
        kernel_memory_vectors_allocated: 'vector_db://allocated_kernel_memory',
      },
      status: 'idle',
      icon: HardDrive,
    },
    {
      id: 'step5',
      name: 'Userspace & Applications (AI-VAM Managed)',
      description: 'User applications run, their code and data residing as vectors in the Vector DB, managed by xIVE and the AI-VAM. This transitions to the state represented by the original VectorOSSimulator.',
      conceptualOpcodeName: 'USERSPACE_INIT_VECTORIZED',
      input: {
        initial_kernel_services_online: 'vector_db://kernel_services_active',
        userspace_config_vectors: 'vector_db://userspace_config',
      },
      status: 'idle',
      icon: Brain,
    },
  ]);

  const [simulationSuccessRate, setSimulationSuccessRate] = useState<number>(90); // Overall success rate for conceptual steps
  const [log, setLog] = useState<string[]>([]);

  const addLog = useCallback((message: string, isError: boolean = false) => {
    setLog(prev => [...prev, `${new Date().toLocaleTimeString()} ${isError ? '[ERROR]' : ''}: ${message}`].slice(-20)); // Keep last 20 logs
  }, []);

  const resetSequence = useCallback(() => {
    setBootSequence(prev => prev.map(step => ({ ...step, status: 'idle', result: undefined, rawResponse: undefined })));
    setLog([]);
    setSimulationSuccessRate(90);
  }, []);

  const runSimulationStep = useCallback(async (stepId: string) => {
    setBootSequence(prev =>
      prev.map(step => (step.id === stepId ? { ...step, status: 'running', result: undefined, rawResponse: undefined } : step))
    );
    addLog(`Initiating step: ${stepId}`);

    const stepToRun = bootSequence.find(s => s.id === stepId);
    if (!stepToRun) {
      addLog(`Error: Step with ID ${stepId} not found.`, true);
      return;
    }

    try {
      // Assuming default_api is configured and available (e.g., via a client generator like OpenAPI Generator)
      // and it has a method matching our FastAPI endpoint: /vector_boot_simulator/execute_opcode
      // This call needs to pass a "token" for authorization, which is not handled here currently.
      // For now, we will assume a mock token or adjust the backend if needed for testing.
      const mockToken = "token_mockuser"; // Placeholder

      const response = await default_api.execute_vector_boot_opcode(
        {
          opcode_name: stepToRun.conceptualOpcodeName,
          input_params: stepToRun.input,
        },
        mockToken // Pass token here
      );

      // Check the response structure from the backend
      if (response && response.status === 'success') {
        addLog(`Step '${stepToRun.name}' (${stepToRun.conceptualOpcodeName}) completed successfully.`);
        
        // --- Extract and process details for visualization ---
        let currentCpuStateData: Record<string, any> | undefined;
        let updatedMemoryPagesData: Record<string, any>[] = [];
        let executedInstructionsData: Record<string, any>[] = [];

        // Common for xIVE-based steps (BIOS Load, Bootloader Execute, Kernel Init)
        if (response.details && response.details.current_cpu_state_vector_id_after_bios) {
          const cpuStateDetails = await retrieveVectorDetails(response.details.current_cpu_state_vector_id_after_bios);
          if (cpuStateDetails.metadata) {
            currentCpuStateData = cpuStateDetails.metadata;
          }
        }
        if (response.details && response.details.initial_cpu_state_vector) { // For bootloader
          const cpuStateDetails = await retrieveVectorDetails(response.details.initial_cpu_state_vector);
          if (cpuStateDetails.metadata) {
            currentCpuStateData = cpuStateDetails.metadata;
          }
        }
        if (response.details && response.details.current_cpu_state_vector_id_after_kernel_init) { // For kernel init
            const cpuStateDetails = await retrieveVectorDetails(response.details.current_cpu_state_vector_id_after_kernel_init);
            if (cpuStateDetails.metadata) {
                currentCpuStateData = cpuStateDetails.metadata;
            }
        }

        // Handle specific instruction execution details
        if (response.details && response.details.executed_instruction_vector_ids) {
            for (const instrId of response.details.executed_instruction_vector_ids) {
                const instrDetails = await retrieveVectorDetails(instrId);
                if (instrDetails.metadata) {
                    executedInstructionsData.push(instrDetails.metadata);
                }
            }
        }

        setBootSequence(prev =>
          prev.map(step =>
            step.id === stepId
              ? {
                  ...step,
                  status: 'success',
                  result: response.message,
                  rawResponse: response,
                  currentCpuState: currentCpuStateData,
                  updatedMemoryPages: updatedMemoryPagesData, // Populate later if backend provides
                  executedInstructions: executedInstructionsData, // Populate later if backend provides
                }
              : step
          )
        );
      } else {
        addLog(`Step '${stepToRun.name}' (${stepToRun.conceptualOpcodeName}) failed. Backend message: ${response?.message || 'Unknown error'}`, true);
        setBootSequence(prev =>
          prev.map(step =>
            step.id === stepId
              ? { ...step, status: 'failed', result: response?.message || 'Backend reported failure.', rawResponse: response }
              : step
          )
        );
      }
    } catch (error: any) {
      const errorMessage = error.response?.data?.detail || error.message || 'Unknown API error.';
      addLog(`Step '${stepToRun.name}' (${stepToRun.conceptualOpcodeName}) API call failed: ${errorMessage}`, true);
      setBootSequence(prev =>
        prev.map(step =>
          step.id === stepId
            ? { ...step, status: 'failed', result: `API Error: ${errorMessage}`, rawResponse: error.response?.data || error }
            : step
        )
      );
    }
  }, [addLog, bootSequence]); // Depend on bootSequence to get current stepToRun state, although it's mostly static config here.

  const runAllSteps = useCallback(async () => {
    resetSequence();
    addLog("Starting full VectorOS boot sequence simulation...");
    for (const step of bootSequence) {
      await runSimulationStep(step.id);
      // Find the updated status of the step after execution
      const updatedStep = bootSequence.find(s => s.id === step.id);
      if (updatedStep?.status === 'failed') { // Check updated status to halt on failure
        addLog(`Full boot sequence halted due to failure in step '${updatedStep.name}'.`, true);
        break;
      }
    }
    addLog("Full VectorOS boot sequence simulation finished.");
  }, [bootSequence, runSimulationStep, resetSequence, addLog]);

  const getStatusBadge = (status: BootStep['status']) => {
    switch (status) {
      case 'running':
        return <Badge className="bg-yellow-500 text-yellow-900 animate-pulse">Running...</Badge>;
      case 'success':
        return <Badge className="bg-green-500 text-green-900">Success</Badge>;
      case 'failed':
        return <Badge className="bg-red-500 text-red-900">Failed</Badge>;
      default:
        return <Badge variant="secondary">Idle</Badge>;
    }
  };

  const getStatusIcon = (status: BootStep['status']) => {
    switch (status) {
      case 'running':
        return <Loader2 className="h-4 w-4 animate-spin text-yellow-500" />;
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      <h1 className="text-4xl font-bold text-center text-primary flex items-center justify-center gap-3">
        <Zap className="h-8 w-8 text-indigo-500" /> Vector-Based OS Boot Orchestrator
      </h1>
      <p className="text-center text-muted-foreground max-w-3xl mx-auto">
        This component orchestrates and visualizes the simulated boot sequence for a Vector-Based LLM OS,
        as outlined in the architectural plan. Each step interacts with the `pxOS` backend via
        `create_Execution` calls, demonstrating the conceptual flow.
      </p>

      <div className="flex flex-col md:flex-row justify-center items-center gap-4 mb-8">
        <Button onClick={runAllSteps} disabled={bootSequence.some(step => step.status === 'running')}>
          <Play className="mr-2 h-4 w-4" /> Run All Steps
        </Button>
        <Button onClick={resetSequence} variant="outline" disabled={bootSequence.some(step => step.status === 'running')}>
          Reset Simulation
        </Button>
        <div className="flex items-center gap-2 w-full md:w-auto max-width-xs">
          <span className="text-sm text-muted-foreground whitespace-nowrap">Success Rate: {simulationSuccessRate}%</span>
          {/* Note: Slider component needs to be imported or defined */}
          {/* <Slider
            defaultValue={[90]}
            max={100}
            step={5}
            onValueChange={(val) => setSimulationSuccessRate(val[0])}
            className="w-[150px]"
            disabled={bootSequence.some(step => step.status === 'running')}
          /> */}
          <input
            type="range"
            min="0"
            max="100"
            step="5"
            value={simulationSuccessRate}
            onChange={(e) => setSimulationSuccessRate(Number(e.target.value))}
            className="w-[150px] accent-indigo-500"
            disabled={bootSequence.some(step => step.status === 'running')}
            aria-label="Simulation success rate"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {bootSequence.map((step, index) => (
          <Card key={step.id} className="relative overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xl font-medium flex items-center gap-2">
                <step.icon className="h-6 w-6 text-indigo-400" /> {index + 1}. {step.name}
              </CardTitle>
              <div className="flex items-center gap-2">
                {getStatusIcon(step.status)}
                {getStatusBadge(step.status)}
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-sm text-gray-500 mb-2">{step.description}</CardDescription>
              {step.status !== 'idle' && step.result && (
                <p className={`text-xs mt-2 p-2 rounded-md ${step.status === 'failed' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                  <strong>Result:</strong> {step.result}
                </p>
              )}
              {step.status !== 'idle' && step.rawResponse && (
                <div className="mt-2">
                  <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-200">Raw API Response:</h4>
                  <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded-md overflow-x-auto">
                    {JSON.stringify(step.rawResponse, null, 2)}
                  </pre>
                </div>
              )}
              <div className="mt-4">
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-200">Conceptual Input:</h4>
                <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded-md overflow-x-auto">
                  {JSON.stringify(step.input, null, 2)}
                </pre>
              </div>

              {step.currentCpuState && (
                <div className="mt-4 p-2 bg-blue-50 dark:bg-blue-950 rounded-md border border-blue-200 dark:border-blue-700">
                  <h4 className="text-sm font-semibold text-blue-700 dark:text-blue-200 flex items-center gap-1">
                    <Cpu className="h-4 w-4" /> Current CPU State:
                  </h4>
                  <pre className="text-xs font-mono text-blue-800 dark:text-blue-100 p-1 rounded-md overflow-x-auto">
                    {JSON.stringify(step.currentCpuState, null, 2)}
                  </pre>
                </div>
              )}

              {step.executedInstructions && step.executedInstructions.length > 0 && (
                <div className="mt-4 p-2 bg-purple-50 dark:bg-purple-950 rounded-md border border-purple-200 dark:border-purple-700">
                  <h4 className="text-sm font-semibold text-purple-700 dark:text-purple-200 flex items-center gap-1">
                    <Zap className="h-4 w-4" /> Executed Instructions:
                  </h4>
                  <ul className="text-xs font-mono text-purple-800 dark:text-purple-100 p-1">
                    {step.executedInstructions.map((instr, instrIdx) => (
                      <li key={instrIdx} className="mb-1">
                        <pre>{JSON.stringify(instr, null, 2)}</pre>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {step.updatedMemoryPages && step.updatedMemoryPages.length > 0 && (
                <div className="mt-4 p-2 bg-green-50 dark:bg-green-950 rounded-md border border-green-200 dark:border-green-700">
                  <h4 className="text-sm font-semibold text-green-700 dark:text-green-200 flex items-center gap-1">
                    <Layers className="h-4 w-4" /> Updated Memory Pages:
                  </h4>
                  <ul className="text-xs font-mono text-green-800 dark:text-green-100 p-1">
                    {step.updatedMemoryPages.map((mem, memIdx) => (
                      <li key={memIdx} className="mb-1">
                        <pre>{JSON.stringify(mem, null, 2)}</pre>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {step.status === 'idle' && (
                <Button variant="outline" size="sm" onClick={() => runSimulationStep(step.id)} className="mt-3" disabled={bootSequence.some(s => s.status === 'running')}>
                  Run Step
                </Button>
              )}
              {step.status === 'running' && (
                <Button variant="outline" size="sm" disabled className="mt-3">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Running...
                </Button>
              )}
            </CardContent>
            {/* Visual separator line connecting steps */}
            {index < bootSequence.length - 1 && (
              <Separator orientation="vertical" className="absolute left-6 top-full h-8 w-px bg-gray-300 -translate-x-1/2" />
            )}
          </Card>
        ))}
      </div>

      <Card className="mt-8 shadow-lg border-none">
        <CardHeader className="bg-gray-700 text-white rounded-t-lg">
          <CardTitle className="text-lg flex items-center gap-2"><Info className="h-5 w-5" />Simulation Log</CardTitle>
        </CardHeader>
        <CardContent className="h-60 overflow-y-auto bg-gray-100 dark:bg-gray-800 p-4 rounded-b-md text-sm font-mono text-gray-800 dark:text-gray-200">
          {log.length === 0 ? (
            <p className="text-gray-400">No events logged yet. Start the simulation!</p>
          ) : (
            log.map((entry, index) => (
              <p key={index} className="mb-1 last:mb-0 border-b border-gray-300 dark:border-gray-700 last:border-0 pb-1">
                {entry}
              </p>
            ))
          )}
        </CardContent>
        <CardFooter className="p-4 pt-0">
          <Button onClick={() => setLog([])} variant="ghost" className="w-full text-red-500 hover:text-red-700 dark:hover:text-red-300">Clear Log</Button>
        </CardFooter>
      </Card>
    </div>
  );
}