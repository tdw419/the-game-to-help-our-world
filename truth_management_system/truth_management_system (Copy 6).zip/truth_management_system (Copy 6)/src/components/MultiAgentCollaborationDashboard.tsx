import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Brain, MessageSquareText, Share2, CornerDownRight, Loader2, UserRound, Sparkles } from 'lucide-react';

// Assuming default_api is available globally or imported from a client library
declare const default_api: any;

interface Agent {
  id: string;
  name: string;
  knowledgeBase: {
    hypotheses_shared: number;
    knowledge_processed: number;
    current_focus: string;
  };
  isProcessing: boolean;
  incomingMessagesCount?: number; // New field to store count fetched from backend
}

interface MessageLogEntry {
  id: string;
  timestamp: string;
  senderId: string;
  recipientIds: string[];
  type: 'knowledge_share' | 'message';
  payload: any;
  status: 'sent' | 'received' | 'processed';
}

interface TruthScoreData {
  code_unit_identifier: string;
  truth_score: number;
  last_calculated_at: string;
  usage_count: number;
}

export default function MultiAgentCollaborationDashboard() {
  const [agents, setAgents] = useState<Agent[]>([
    // Initial agents will be created via API in useEffect
  ]);
  const [messageLog, setMessageLog] = useState<MessageLogEntry[]>([]);
  const [truthScores, setTruthScores] = useState<TruthScoreData[]>([]); // New state for truth scores
  // Removed simulatedMessages state, as it will be managed via backend API calls

  const addLogEntry = useCallback((entry: Omit<MessageLogEntry, 'timestamp' | 'id'>) => {
    setMessageLog(prev => [{ ...entry, id: `msg_${Date.now()}_${Math.random()}`, timestamp: new Date().toLocaleTimeString() }, ...prev].slice(0, 100));
  }, []);

  // Initialize agents via backend API calls
  useEffect(() => {
    const initializeAgents = async () => {
      const token = "token_mockuser"; // Placeholder token
      const initialAgentConfigs = [
        { name: 'Agent A (Hypothesis Generator)', initial_focus: 'VectorOS Boot' },
        { name: 'Agent B (Experiment Evaluator)', initial_focus: 'Performance Metrics' },
        { name: 'Agent C (Strategy Adaptor)', initial_focus: 'Learning Algorithms' },
      ];

      const createdAgents: Agent[] = [];

      for (const config of initialAgentConfigs) {
        try {
          const createResponse = await default_api.agent_create_endpoint(
            { name: config.name, initial_focus: config.initial_focus },
            token
          );
          if (createResponse.status === "success" && createResponse.details && createResponse.details.agent) {
            const agentId = createResponse.details.agent.id;
            const agentStateResponse = await default_api.agent_get_state_endpoint(agentId, token);
            if (agentStateResponse.status === "success" && agentStateResponse.details && agentStateResponse.details.agent) {
              const agentData = agentStateResponse.details.agent;
              createdAgents.push({
                id: agentData.id,
                name: agentData.name,
                knowledgeBase: {
                  hypotheses_shared: agentData.knowledge_base.hypotheses_shared || 0,
                  knowledge_processed: agentData.knowledge_base.knowledge_processed || 0,
                  current_focus: agentData.knowledge_base.current_focus || 'N/A',
                },
                isProcessing: false,
              });
              addLogEntry({
                senderId: 'System',
                recipientIds: [agentId],
                type: 'message',
                payload: { message: `Agent ${agentData.name} created.` },
                status: 'sent',
              });
            } else {
              addLogEntry({ senderId: 'System', recipientIds: [], type: 'message', payload: { error: `Failed to get state for agent ${config.name}.` }, status: 'failed' });
            }
          } else {
            addLogEntry({ senderId: 'System', recipientIds: [], type: 'message', payload: { error: `Failed to create agent ${config.name}.` }, status: 'failed' });
          }
        } catch (error: any) {
          addLogEntry({ senderId: 'System', recipientIds: [], type: 'message', payload: { error: `Error creating agent ${config.name}: ${error.message}` }, status: 'failed' });
        }
      }
      setAgents(createdAgents);
    };

    initializeAgents();
  }, [addLogEntry]);

  // Fetch truth scores periodically
  useEffect(() => {
    const fetchTruthScores = async () => {
      try {
        const response = await fetch('/usage/truth_scores'); // Endpoint to fetch from
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        // Assuming data.truth_scores is an object, convert to array and sort
        const truthScoresArray = Object.entries(data.truth_scores || {}).map(([identifier, score]) => ({
          code_unit_identifier: identifier,
          truth_score: score,
          last_calculated_at: '', // Placeholder, as current endpoint only returns score
          usage_count: 0, // Placeholder
        }));

        // Sort by truth_score in descending order
        const sortedScores = (truthScoresArray || []).sort((a: TruthScoreData, b: TruthScoreData) => b.truth_score - a.truth_score);
        setTruthScores(sortedScores);
      } catch (error) {
        console.error("Failed to fetch truth scores:", error);
      }
    };

    fetchTruthScores(); // Fetch immediately on mount
    const interval = setInterval(fetchTruthScores, 10000); // Refresh every 10 seconds
    return () => clearInterval(interval); // Cleanup on unmount
  }, []);

  const fetchAgentInboxCount = useCallback(async (agentId: string) => {
    const token = "token_mockuser";
    try {
        const response = await default_api.agent_receive_messages_endpoint(agentId, undefined, 'unread', token);
        if (response.status === 'success' && response.details && response.details.messages) {
            return response.details.messages.length;
        }
    } catch (error) {
        console.error(`Failed to fetch inbox count for ${agentId}:`, error);
    }
    return 0;
  }, []);

  useEffect(() => {
    const updateInboxes = async () => {
      // Only update if agents have been initialized
      if (agents.length === 0) return;

      const updatedAgents = await Promise.all(agents.map(async agent => {
        const inboxCount = await fetchAgentInboxCount(agent.id);
        return { ...agent, incomingMessagesCount: inboxCount };
      }));
      setAgents(updatedAgents);
    };

    const interval = setInterval(updateInboxes, 5000); // Poll every 5 seconds for new messages
    updateInboxes(); // Initial fetch
    return () => clearInterval(interval);
  }, [agents, fetchAgentInboxCount]); // Dependency on agents is important to ensure all agents are eventually updated

  // Fetch truth scores periodically
  useEffect(() => {
    const fetchTruthScores = async () => {
      try {
        const response = await fetch('/usage/truth_scores'); // Endpoint to fetch from
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        
        // Assuming data.truth_scores is an object, convert to array and sort
        const truthScoresArray = Object.entries(data.truth_scores || {}).map(([identifier, score]) => ({
          code_unit_identifier: identifier,
          truth_score: score,
          last_calculated_at: '', // Placeholder, as current endpoint only returns score
          usage_count: 0, // Placeholder
        }));

        // Sort by truth_score in descending order
        const sortedScores = (truthScoresArray || []).sort((a: TruthScoreData, b: TruthScoreData) => b.truth_score - a.truth_score);
        setTruthScores(sortedScores);
      } catch (error) {
        console.error("Failed to fetch truth scores:", error);
      }
    };

    fetchTruthScores(); // Fetch immediately on mount
    const interval = setInterval(fetchTruthScores, 10000); // Refresh every 10 seconds
    return () => clearInterval(interval); // Cleanup on unmount
  }, []);


  const simulateAgentAction = useCallback(async (agentId: string, actionType: 'share' | 'process' | 'query_truth_scores') => {
    setAgents(prev => prev.map(agent => agent.id === agentId ? { ...agent, isProcessing: true } : agent));
    const token = "token_mockuser"; // Placeholder for actual authentication token

    try {
      if (actionType === 'share') {
        const sender = agents.find(a => a.id === agentId);
        if (!sender) {
          addLogEntry({ senderId: 'System', recipientIds: [], type: 'message', payload: { error: `Sender agent ${agentId} not found.` }, status: 'failed' });
          return;
        }

        const knowledgePayload = {
          hypothesis: `Hypothesis from ${sender.name}: Optimize ${sender.knowledgeBase.current_focus} by modifying parameter ${Math.floor(Math.random() * 100)}.`, 
          confidence: parseFloat((Math.random() * 0.3 + 0.6).toFixed(2)), // 0.6-0.9
          sourceAgent: sender.id,
        };
        const knowledgeType = 'hypothesis_proposal';
        const recipientIds = agents.filter(a => a.id !== agentId).map(a => a.id);

        const shareResponse = await default_api.agent_share_knowledge_endpoint(
          {
            sender_id: agentId,
            knowledge_payload: knowledgePayload,
            recipient_ids: recipientIds,
            knowledge_type: knowledgeType,
          },
          token
        );

        if (shareResponse.status === 'success') {
          addLogEntry({
            senderId: agentId,
            recipientIds: recipientIds,
            type: 'knowledge_share',
            payload: knowledgePayload,
            status: 'sent',
          });

          // After sharing, update the sender's state to reflect the shared knowledge count
          const updatedSenderState = await default_api.agent_get_state_endpoint(agentId, token);
          if (updatedSenderState.status === "success" && updatedSenderState.details && updatedSenderState.details.agent) {
              setAgents(prev => prev.map(agent =>
                agent.id === agentId ? { ...agent, knowledgeBase: { ...agent.knowledgeBase, ...updatedSenderState.details.agent.knowledge_base } } : agent
              ));
          }

        } else {
          throw new Error(shareResponse.message || 'Failed to share knowledge.');
        }

      } else if (actionType === 'process') {
        addLogEntry({ senderId: agentId, recipientIds: [agentId], type: 'message', payload: { action: 'checking_inbox' }, status: 'pending' });

        const receiveResponse = await default_api.agent_receive_messages_endpoint(agentId, undefined, 'unread', token);
        
        if (receiveResponse.status === 'success' && receiveResponse.details && receiveResponse.details.messages && receiveResponse.details.messages.length > 0) {
          const messagesToProcess = receiveResponse.details.messages;
          for (const message of messagesToProcess) {
            addLogEntry({ senderId: agentId, recipientIds: [agentId], type: 'message', payload: { action: 'processing_message', message_id: message.message_id, from: message.sender_id }, status: 'pending' });

            const processResponse = await default_api.agent_process_shared_knowledge_endpoint(
              {
                agent_id: agentId,
                message_payload: message.payload, // Pass the full payload including confidence etc.
              },
              token
            );

            if (processResponse.status === 'success') {
              addLogEntry({
                senderId: agentId,
                recipientIds: [agentId],
                type: 'message',
                payload: {
                  action: 'processed_knowledge',
                  message_id: message.message_id,
                  from: message.sender_id,
                  summary: processResponse.message,
                  details: processResponse.details,
                },
                status: 'processed',
              });
              // Fetch updated agent state to reflect knowledge base changes
              const agentStateResponse = await default_api.agent_get_state_endpoint(agentId, token);
              if (agentStateResponse.status === "success" && agentStateResponse.details && agentStateResponse.details.agent) {
                const updatedAgentData = agentStateResponse.details.agent;
                setAgents(prev => prev.map(agent =>
                  agent.id === agentId ? {
                    ...agent,
                    knowledgeBase: {
                      hypotheses_shared: updatedAgentData.knowledge_base.hypotheses_shared || 0,
                      knowledge_processed: updatedAgentData.knowledge_base.knowledge_processed || 0,
                      current_focus: updatedAgentData.knowledge_base.current_focus || 'N/A',
                    }
                  } : agent
                ));
              }
            } else {
              addLogEntry({ senderId: agentId, recipientIds: [agentId], type: 'message', payload: { error: `Failed to process message ${message.message_id}: ${processResponse.message}` }, status: 'failed' });
              throw new Error(processResponse.message || 'Failed to process shared knowledge.');
            }
          }
        } else {
          addLogEntry({
            senderId: agentId,
            recipientIds: [agentId],
            type: 'message',
            payload: { action: 'no_incoming_knowledge', message: 'No new messages to process.' },
            status: 'sent',
          });
        }

      } else if (actionType === 'query_truth_scores') {
        addLogEntry({ senderId: agentId, recipientIds: [agentId], type: 'message', payload: { action: 'querying_truth_scores' }, status: 'pending' });
        
        // Example query: get top 5 scores above 0.5
        const queryInputs = {
          limit: 5,
          min_truth_score: 0.5,
          code_unit_identifier_contains: 'frontend' // Example filter
        };

        const opcodeExecutionResponse = await default_api.execute_opcode_endpoint(
          {
            opcode_name: 'QUERY_TRUTH_SCORES',
            inputs: queryInputs,
          },
          token
        );

        if (opcodeExecutionResponse.success) {
          addLogEntry({
            senderId: agentId,
            recipientIds: [agentId],
            type: 'message',
            payload: {
              action: 'truth_scores_queried',
              query: queryInputs,
              results: opcodeExecutionResponse.outputs?.truth_scores,
            },
            status: 'processed',
          });
        } else {
          addLogEntry({ senderId: agentId, recipientIds: [agentId], type: 'message', payload: { error: `Failed to query truth scores: ${opcodeExecutionResponse.message}` }, status: 'failed' });
        }
      }
    } catch (error: any) {
      console.error(`Agent ${agentId} ${actionType} failed:`, error);
      addLogEntry({
        senderId: agentId,
        recipientIds: [],
        type: 'message',
        payload: { error: `Action failed: ${error.message}` },
        status: 'failed',
      });
    } finally {
      setAgents(prev => prev.map(agent => agent.id === agentId ? { ...agent, isProcessing: false } : agent));
    }
  }, [agents, addLogEntry]);

  const renderAgentCard = (agent: Agent) => (
    <Card key={agent.id} className="flex flex-col items-center p-4">
      <UserRound className="h-10 w-10 text-primary mb-2" />
      <CardTitle className="text-xl text-center">{agent.name}</CardTitle>
      <CardDescription className="text-sm text-center mb-4">{agent.id}</CardDescription>
      <div className="text-left w-full space-y-1 mb-4">
        <p className="text-sm font-medium">Knowledge Base:</p>
        <p className="text-xs">Hypotheses Shared: <Badge variant="secondary">{agent.knowledgeBase.hypotheses_shared}</Badge></p>
        <p className="text-xs">Knowledge Processed: <Badge variant="secondary">{agent.knowledgeBase.knowledge_processed}</Badge></p>
        <p className="text-xs">Current Focus: <Badge variant="outline">{agent.knowledgeBase.current_focus}</Badge></p>
        <p className="text-xs">Incoming Messages: <Badge variant="destructive">{agent.incomingMessagesCount || 0}</Badge></p>
      </div>
      <div className="flex flex-col gap-2 w-full">
        <Button onClick={() => simulateAgentAction(agent.id, 'share')} disabled={agent.isProcessing}>
          {agent.isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Share2 className="mr-2 h-4 w-4" />}
          Share Knowledge
        </Button>
        <Button variant="secondary" onClick={() => simulateAgentAction(agent.id, 'process')} disabled={agent.isProcessing || (agent.incomingMessagesCount || 0) === 0}>
          {agent.isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Brain className="mr-2 h-4 w-4" />}
          Process Incoming Knowledge ({agent.incomingMessagesCount || 0})
        </Button>
        <Button variant="outline" onClick={() => simulateAgentAction(agent.id, 'query_truth_scores')} disabled={agent.isProcessing}>
          {agent.isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
          Query Truth Scores
        </Button>
      </div>
    </Card>
  );

  return (
    <TooltipProvider>
      <div className="container mx-auto p-4 max-w-7xl">
        <h1 className="text-3xl font-bold mb-6 text-center">Multi-Agent Collaboration Dashboard</h1>
        <p className="text-center text-gray-600 dark:text-gray-400 mb-8">
          Simulating knowledge sharing and processing among AI agents to foster collaborative learning.
        </p>

        {/* Agents Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><UserRound className="h-6 w-6" /> Collaborative Agents</CardTitle>
            <CardDescription>Observe and interact with individual AI agents.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {agents.map(renderAgentCard)}
            </div>
          </CardContent>
        </Card>

        {/* Code Truth Scores Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Sparkles className="h-6 w-6" /> Code Truth Scores (Usage-based)</CardTitle>
            <CardDescription>
              Identifies the most frequently used code units (endpoints, components) in the system.
              Higher score (closer to 1.0) indicates higher usage.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {truthScores.length === 0 ? (
              <p className="text-gray-400">No truth scores available yet. Interact with the system to generate usage data.</p>
            ) : (
              <ScrollArea className="h-[300px] w-full rounded-md border p-4 bg-gray-50 dark:bg-gray-900">
                <div className="space-y-2">
                  {truthScores.map((score, index) => (
                    <div key={score.code_unit_identifier} className="flex justify-between items-center text-sm">
                      <span className="font-medium truncate">{index + 1}. {score.code_unit_identifier}</span>
                      <Badge variant="secondary" className="min-w-[60px] text-right">
                        {(score.truth_score * 100).toFixed(2)}%
                      </Badge>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Communication Log */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><MessageSquareText className="h-6 w-6" /> Communication Log</CardTitle>
            <CardDescription>A chronological record of messages and knowledge exchanged.</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[500px] w-full rounded-md border p-4 bg-gray-50 dark:bg-gray-900">
              {messageLog.length === 0 ? (
                <p className="text-gray-400">No agent communication yet.</p>
              ) : (
                <div className="space-y-4">
                  {messageLog.map(entry => (
                    <div key={entry.id} className="relative pl-8">
                      <div className="absolute left-0 top-0 h-full flex items-start justify-center">
                        <span className="h-2 w-2 rounded-full bg-gray-400 mt-2" />
                        <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-px bg-gray-200" />
                      </div>
                      <div className="flex flex-col">
                        <p className="text-xs text-gray-500 dark:text-gray-400">{entry.timestamp}</p>
                        <div className="flex items-center gap-2 text-sm font-medium">
                          {entry.status === 'processed' ? (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <CornerDownRight className="h-4 w-4 text-green-500" />
                              </TooltipTrigger>
                              <TooltipContent>Knowledge Processed</TooltipContent>
                            </Tooltip>
                          ) : (
                            <Share2 className="h-4 w-4 text-blue-500" />
                          )}
                          <span className="font-semibold text-primary">{entry.senderId}</span>
                          {entry.recipientIds.length > 0 && (
                            <>
                              <span className="text-gray-600 dark:text-gray-300">{'->'}</span>
                              <span className="font-semibold text-primary">{entry.recipientIds.join(', ')}</span>
                            </>
                          )}
                          <Badge variant="outline">{entry.type}</Badge>
                          <Badge variant={entry.status === 'sent' ? 'default' : entry.status === 'processed' ? 'success' : 'secondary'}>{entry.status}</Badge>
                        </div>
                        <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded-md overflow-x-auto mt-1">
                          {JSON.stringify(entry.payload, null, 2)}
                        </pre>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
          <CardFooter>
            <Button variant="outline" onClick={() => setMessageLog([])} disabled={messageLog.length === 0}>Clear Log</Button>
          </CardFooter>
        </Card>
      </div>
    </TooltipProvider>
  );
}
