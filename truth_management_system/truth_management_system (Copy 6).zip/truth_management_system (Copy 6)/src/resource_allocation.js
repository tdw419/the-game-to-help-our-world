class ResourceAllocation {
  constructor() {
    this.resourcesDb = {};
  }

  async allocateResource(resourceType, allocatedTo) {
    const resourceId = Object.keys(this.resourcesDb).length + 1;
    this.resourcesDb[resourceId] = { resourceType, allocatedTo };
    return `Resource ${resourceId} allocated successfully`;
  }

  async listResources() {
    return Object.values(this.resourcesDb);
  }
}

module.exports = ResourceAllocation;
