import { TruthAgent } from '../index';
import axios from 'axios';

// Mock axios post to prevent actual API calls during tests
jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe('TruthAgent', () => {
  let agent: TruthAgent;

  beforeEach(() => {
    // Reset mocks before each test
    jest.clearAllMocks();
    // Re-initialize agent for each test to ensure isolated config
    agent = new TruthAgent();
    process.env.OPENAI_API_KEY = 'test_api_key'; // Ensure API key is set for tests
  });

  it('should initialize with default configuration', () => {
    const config = agent.getConfig();
    expect(config.llmModel).toBe('gpt-4o-mini');
    expect(config.temperature).toBe(0.7);
    expect(config.maxTokens).toBe(500);
    expect(config.prompt).toContain('truth discovery');
  });

  it('should update configuration correctly', () => {
    agent.updateConfig({ temperature: 0.9, llmModel: 'gpt-3.5-turbo' });
    const config = agent.getConfig();
    expect(config.temperature).toBe(0.9);
    expect(config.llmModel).toBe('gpt-3.5-turbo');
    expect(config.maxTokens).toBe(500); // Should remain default
  });

  it('should throw an error if OPENAI_API_KEY is not set', async () => {
    delete process.env.OPENAI_API_KEY; // Unset API key for this test
    const task = { input: 'test input' };

    await expect(agent.execute(task)).rejects.toThrow('OPENAI_API_KEY is not set in environment variables.');
  });

  it('should successfully execute a task and return a successful result', async () => {
    mockedAxios.post.mockResolvedValueOnce({
      data: {
        choices: [{ message: { content: 'Fact: Earth is round. Confidence: 1.0.' } }],
      },
    });

    const task = { input: 'Is the Earth round?' };
    const result = await agent.execute(task);

    expect(result.success).toBe(true);
    expect(result.output).toContain('Fact: Earth is round.');
    expect(result.timestamp).toBeDefined();
    expect(result.agentVersion).toBe('1.0.0');
    expect(result.processingTimeMs).toBeGreaterThan(0);
    expect(mockedAxios.post).toHaveBeenCalledTimes(1);
    expect(mockedAxios.post).toHaveBeenCalledWith(
      "https://api.openai.com/v1/chat/completions",
      expect.objectContaining({
        model: 'gpt-4o-mini',
        messages: expect.arrayContaining([{ role: 'user', content: expect.stringContaining('Is the Earth round?') }]),
      }),
      expect.objectContaining({
        headers: expect.objectContaining({
          Authorization: 'Bearer test_api_key',
        }),
      })
    );
  });

  it('should return a failed result if LLM call fails', async () => {
    mockedAxios.post.mockRejectedValueOnce(new Error('API rate limit exceeded'));

    const task = { input: 'some input' };
    const result = await agent.execute(task);

    expect(result.success).toBe(false);
    expect(result.output).toContain('Error during agent execution: API rate limit exceeded');
    expect(result.timestamp).toBeDefined();
    expect(result.agentVersion).toBe('1.0.0');
    expect(result.processingTimeMs).toBeGreaterThan(0);
  });

  it('should use task-specific config if provided', async () => {
    mockedAxios.post.mockResolvedValueOnce({
      data: {
        choices: [{ message: { content: 'Task-specific config test.' } }],
      },
    });

    const task = {
      input: 'test',
      config: { temperature: 0.1, maxTokens: 100, llmModel: 'custom-model' },
    };
    const result = await agent.execute(task);

    expect(result.success).toBe(true);
    expect(mockedAxios.post).toHaveBeenCalledTimes(1);
    expect(mockedAxios.post).toHaveBeenCalledWith(
      "https://api.openai.com/v1/chat/completions",
      expect.objectContaining({
        model: 'custom-model',
        temperature: 0.1,
        max_tokens: 100,
      }),
      expect.any(Object)
    );
  });
});