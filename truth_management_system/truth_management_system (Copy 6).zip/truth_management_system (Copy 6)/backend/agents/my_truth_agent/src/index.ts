import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

interface AgentConfig {
  llmModel: string;
  temperature: number;
  maxTokens: number;
  prompt: string;
}

interface AgentTask {
  input: string;
  config?: Partial<AgentConfig>;
}

interface AgentResult {
  output: string;
  success: boolean;
  timestamp: string;
  agentVersion: string;
  processingTimeMs: number;
}

const DEFAULT_AGENT_CONFIG: AgentConfig = {
  llmModel: "gpt-4o-mini", // Default LLM model
  temperature: 0.7,
  maxTokens: 500,
  prompt: `You are an AI agent specialized in truth discovery. Your task is to analyze the provided input and extract factual statements, verify them if possible against common knowledge, and identify any inconsistencies or biases.

Input: {input}

Instructions:
1. Identify key factual claims.
2. State whether each claim is supported, contradicted, or unverifiable.
3. Provide a confidence score for your assessment (0-1).
4. Summarize your findings concisely.
`,
};

export class TruthAgent {
  private config: AgentConfig;

  constructor(initialConfig?: Partial<AgentConfig>) {
    this.config = { ...DEFAULT_AGENT_CONFIG, ...initialConfig };
    console.log("TruthAgent initialized with config:", this.config);
  }

  public updateConfig(newConfig: Partial<AgentConfig>): void {
    this.config = { ...this.config, ...newConfig };
    console.log("TruthAgent config updated:", this.config);
  }

  public getConfig(): AgentConfig {
    return { ...this.config };
  }

  private async callLlm(fullPrompt: string): Promise<string> {
    const openaiApiKey = process.env.OPENAI_API_KEY;
    if (!openaiApiKey) {
      throw new Error("OPENAI_API_KEY is not set in environment variables.");
    }

    try {
      const response = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        {
          model: this.config.llmModel,
          messages: [{ role: "user", content: fullPrompt }],
          temperature: this.config.temperature,
          max_tokens: this.config.maxTokens,
        },
        {
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${openaiApiKey}`,
          },
        }
      );
      return response.data.choices[0].message.content.trim();
    } catch (error: any) {
      console.error("Error calling LLM:", error.response ? error.response.data : error.message);
      throw new Error(`LLM call failed: ${error.response ? JSON.stringify(error.response.data) : error.message}`);
    }
  }

  public async execute(task: AgentTask): Promise<AgentResult> {
    const startTime = process.hrtime.bigint();
    let output = "";
    let success = false;
    let errorMessage: string | undefined;

    try {
      const effectiveConfig = task.config ? { ...this.config, ...task.config } : this.config;
      const fullPrompt = effectiveConfig.prompt.replace("{input}", task.input);

      // Simulate a delay for LLM call or actual processing
      // await new Promise(resolve => setTimeout(resolve, 1500));

      output = await this.callLlm(fullPrompt);
      success = true;
    } catch (error: any) {
      errorMessage = error.message;
      output = `Error during agent execution: ${errorMessage}`;
      success = false;
    } finally {
      const endTime = process.hrtime.bigint();
      const processingTimeMs = Number(endTime - startTime) / 1_000_000;

      if (!success) {
        console.error("Agent execution failed:", errorMessage);
      }

      return {
        output,
        success,
        timestamp: new Date().toISOString(),
        agentVersion: "1.0.0", // This should ideally come from package.json or a build process
        processingTimeMs,
      };
    }
  }
}

// Example usage if run directly
if (require.main === module) {
  (async () => {
    try {
      const agentInput = process.env.AGENT_TASK_INPUT;
      const agentConfigJson = process.env.AGENT_TASK_CONFIG_JSON;

      if (!agentInput) {
        throw new Error("AGENT_TASK_INPUT environment variable is required.");
      }

      let initialConfig: Partial<AgentConfig> | undefined;
      if (agentConfigJson) {
        try {
          initialConfig = JSON.parse(agentConfigJson);
        } catch (parseError) {
          throw new Error(`Failed to parse AGENT_TASK_CONFIG_JSON: ${parseError}`);
        }
      }

      const agent = new TruthAgent(initialConfig);
      const result = await agent.execute({ input: agentInput });

      // Output the result as JSON to stdout for the parent process to capture
      console.log(JSON.stringify(result));
    } catch (error: any) {
      // If an error occurs before or during agent execution, report it as a failed result
      const errorResult: AgentResult = {
        output: `Agent execution failed due to an unhandled error: ${error.message}`,
        success: false,
        timestamp: new Date().toISOString(),
        agentVersion: "1.0.0", // Fallback version
        processingTimeMs: 0,
      };
      console.error(JSON.stringify(errorResult)); // Use console.error for actual errors
      process.exit(1); // Indicate failure
    }
  })();
}
