from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional, Literal
import time
import random
from datetime import datetime # NEW: Import datetime for setting last_updated_at

from backend.database import get_all_truth_scores, save_foundational_truth, get_all_foundational_truths, get_foundational_truth_by_name, query_foundational_truths_by_vector # NEW: Import foundational truth DB functions and vector query
from backend.main import FoundationalTruth, FoundationalTruthSearchResult, TruthVectorQuery, text_vectorizer # NEW: Import FoundationalTruth model, search result/query models, and text_vectorizer

# Initialize APIRouter for this module
router = APIRouter()

# --- Pydantic Models for Opcode Input/Output Schemas (mirroring conceptual definitions) ---

# PERFORM_POWER_ON_SELF_TEST_OPCODE
class PerformPOSTInput(BaseModel):
    system_component_vectors: Dict[str, Any] = Field(..., description="Vectors representing system components (e.g., CPU, Memory, Storage).")

class PerformPOSTOutput(BaseModel):
    hardware_status_vector: Dict[str, Any]
    post_successful: bool
    diagnostics_log: List[str]

# LOAD_BOOT_SECTOR_OPCODE
class LoadBootSectorInput(BaseModel):
    boot_device_vector: Dict[str, Any] = Field(..., description="Vector identifying the boot device.")
    sector_size: int = Field(512, description="Simulated sector size in bytes.")

class LoadBootSectorOutput(BaseModel):
    boot_sector_code_vector: List[int] # A list of integers representing bytes
    boot_sector_checksum: str
    load_successful: bool

# DECOMPRESS_KERNEL_OPCODE
class DecompressKernelInput(BaseModel):
    compressed_kernel_vector: List[int] = Field(..., description="List of integers representing compressed kernel bytes.")
    compression_algorithm_vector: Optional[str] = Field("gzip_like", description="Simulated compression algorithm.")

class DecompressKernelOutput(BaseModel):
    uncompressed_kernel_vector: List[int]
    decompression_ratio: float
    decompression_successful: bool

# BIOS_UEFI_BOOT_WORKFLOW
class BIOSUEFIBootWorkflowInput(BaseModel):
    system_component_vectors: Dict[str, Any] = Field(..., description="Initial system component states for POST.")
    boot_device_vector: Dict[str, Any] = Field(..., description="Vector identifying the boot device.")
    sector_size: int = Field(512, description="Simulated sector size in bytes.")

class BIOSUEFIBootWorkflowOutput(BaseModel):
    post_result: PerformPOSTOutput
    boot_sector_load_result: LoadBootSectorOutput
    boot_workflow_successful: bool
    message: str

# SOLUTION_EVALUATION
class SolutionEvaluationInput(BaseModel):
    problem_statement: str
    confirmed_hypothesis: str
    proposed_solution: str
    solution_type: str
    estimated_impact: str
    resources_needed: List[str]
    confidence: float
    justification: str

class SolutionEvaluationOutput(BaseModel):
    evaluation_status: Literal["approved", "rejected", "requires_refinement"]
    evaluation_score: float
    risks_identified: List[str]
    estimated_cost: str
    recommendations: str
    evaluation_justification: str

# NEW: QUERY_TRUTH_SCORES Opcode
class QueryTruthScoresInput(BaseModel):
    min_truth_score: Optional[float] = Field(None, ge=0.0, le=1.0, description="Minimum truth score to filter by.")
    max_truth_score: Optional[float] = Field(None, ge=0.0, le=1.0, description="Maximum truth score to filter by.")
    code_unit_identifier_contains: Optional[str] = Field(None, description="Substring to filter code unit identifiers.")
    limit: Optional[int] = Field(None, gt=0, description="Maximum number of results to return.")

class TruthScoreEntry(BaseModel):
    code_unit_identifier: str
    truth_score: float
    last_calculated_at: str
    usage_count: int

class QueryTruthScoresOutput(BaseModel):
    truth_scores: List[TruthScoreEntry]
    message: str = "Truth scores queried successfully."

# NEW: DEFINE_FOUNDATIONAL_TRUTH Opcode
class DefineFoundationalTruthInput(BaseModel):
    name: str = Field(..., description="Unique name of the foundational truth")
    content: str = Field(..., description="The content of the foundational truth")
    source: Literal["human", "ai", "hybrid", "system"] = Field(..., description="Origin of the foundational truth")
    rating: float = Field(1.0, ge=0.0, le=1.0, description="The inherent rating of this truth")
    is_immutable: bool = Field(True, description="If this truth can be changed")
    is_active: bool = Field(True, description="If this truth is currently active")
    last_updated_by: Optional[str] = Field(None, description="Who last updated this truth (defaults to 'system')")
    last_updated_at: Optional[str] = Field(None, description="ISO formatted datetime of last update (defaults to now)")

async def define_foundational_truth_logic(inputs: DefineFoundationalTruthInput) -> FoundationalTruth:
    now = datetime.now().isoformat()
    # Create FoundationalTruth object, enforcing immutability rules
    truth = FoundationalTruth(
        name=inputs.name,
        content=inputs.content,
        source=inputs.source,
        rating=inputs.rating if not inputs.is_immutable else 1.0, # Enforce 1.0 rating for immutable truths
        is_immutable=inputs.is_immutable,
        is_active=inputs.is_active if not inputs.is_immutable else True, # Enforce active for immutable truths
        last_updated_by=inputs.last_updated_by if inputs.last_updated_by else "system",
        last_updated_at=inputs.last_updated_at if inputs.last_updated_at else now,
    )
    await asyncio.to_thread(save_foundational_truth, truth) # Save to DB in a thread pool
    return truth

# NEW: QUERY_FOUNDATIONAL_TRUTHS Opcode
class QueryFoundationalTruthsInput(BaseModel):
    name: Optional[str] = Field(None, description="Filter by name of the foundational truth.")
    source: Optional[Literal["human", "ai", "hybrid", "system"]] = Field(None, description="Filter by origin of the foundational truth.")
    is_immutable: Optional[bool] = Field(None, description="Filter by immutability status.")
    is_active: Optional[bool] = Field(None, description="Filter by active status.")
    min_rating: Optional[float] = Field(None, ge=0.0, le=1.0, description="Minimum rating to filter by.")
    max_rating: Optional[float] = Field(None, ge=0.0, le=1.0, description="Maximum rating to filter by.")
    limit: Optional[int] = Field(None, gt=0, description="Maximum number of results to return.")

class QueryFoundationalTruthsOutput(BaseModel):
    truths: List[FoundationalTruth]
    message: str = "Foundational truths queried successfully."

# NEW: QUERY_TRUTHS_BY_VECTOR Opcode
class QueryTruthsByVectorInput(BaseModel):
    query_text: str = Field(..., description="The text query to find similar foundational truths.")
    top_k: int = Field(5, gt=0, description="The number of top similar truths to return.")

class QueryTruthsByVectorOutput(BaseModel):
    results: List[FoundationalTruthSearchResult]
    message: str = "Truths queried by vector similarity successfully."

async def query_truths_by_vector_logic(inputs: QueryTruthsByVectorInput) -> QueryTruthsByVectorOutput:
    if not text_vectorizer.vocabulary:
        raise HTTPException(status_code=500, detail="TextVectorizer vocabulary not built. Please ensure application has started up correctly.")

    query_vector = text_vectorizer.vectorize_text(inputs.query_text).tolist()
    
    if not query_vector:
        raise HTTPException(status_code=400, detail="Could not vectorize query text. Query might contain unknown words or the vocabulary is too small.")

    found_truths_with_scores = await asyncio.to_thread(query_foundational_truths_by_vector, query_vector, inputs.top_k)
    
    results = [
        FoundationalTruthSearchResult(truth=ft, similarity=sim)
        for ft, sim in found_truths_with_scores
    ]
    return QueryTruthsByVectorOutput(results=results)

async def query_foundational_truths_logic(inputs: QueryFoundationalTruthsInput) -> QueryFoundationalTruthsOutput:
    all_truths = await asyncio.to_thread(get_all_foundational_truths)
    
    filtered_truths: List[FoundationalTruth] = []
    for truth in all_truths:
        # Apply filters
        if inputs.name and inputs.name.lower() not in truth.name.lower():
            continue
        if inputs.source and inputs.source != truth.source:
            continue
        if inputs.is_immutable is not None and inputs.is_immutable != truth.is_immutable:
            continue
        if inputs.is_active is not None and inputs.is_active != truth.is_active:
            continue
        if inputs.min_rating is not None and truth.rating < inputs.min_rating:
            continue
        if inputs.max_rating is not None and truth.rating > inputs.max_rating:
            continue
        
        filtered_truths.append(truth)
    
    # Apply limit
    if inputs.limit is not None:
        filtered_truths = filtered_truths[:inputs.limit]

    return QueryFoundationalTruthsOutput(truths=filtered_truths)

# --- Opcode Dispatcher ---
OPCODE_FUNCTIONS = {
    "PERFORM_POWER_ON_SELF_TEST_OPCODE": {
        "logic": perform_power_on_self_test_logic,
        "input_model": PerformPOSTInput,
        "output_model": PerformPOSTOutput
    },
    "LOAD_BOOT_SECTOR_OPCODE": {
        "logic": load_boot_sector_logic,
        "input_model": LoadBootSectorInput,
        "output_model": LoadBootSectorOutput
    },
    "DECOMPRESS_KERNEL_OPCODE": {
        "logic": decompress_kernel_logic,
        "input_model": DecompressKernelInput,
        "output_model": DecompressKernelOutput
    },
    "BIOS_UEFI_BOOT_WORKFLOW": {
        "logic": bios_uefi_boot_workflow_logic,
        "input_model": BIOSUEFIBootWorkflowInput,
        "output_model": BIOSUEFIBootWorkflowOutput
    },
    "SOLUTION_EVALUATION": {
        "logic": solution_evaluation_logic,
        "input_model": SolutionEvaluationInput,
        "output_model": SolutionEvaluationOutput,
    },
    "QUERY_TRUTH_SCORES": { # NEW: Register the new opcode
        "logic": query_truth_scores_logic,
        "input_model": QueryTruthScoresInput,
        "output_model": QueryTruthScoresOutput,
    },
    "DEFINE_FOUNDATIONAL_TRUTH": { # NEW: Register new opcode for foundational truths
        "logic": define_foundational_truth_logic,
        "input_model": DefineFoundationalTruthInput,
        "output_model": FoundationalTruth,
    },
    "QUERY_FOUNDATIONAL_TRUTHS": { # NEW: Register new opcode for querying foundational truths
        "logic": query_foundational_truths_logic,
        "input_model": QueryFoundationalTruthsInput,
        "output_model": QueryFoundationalTruthsOutput,
    },
    "QUERY_TRUTHS_BY_VECTOR": { # NEW: Register opcode for vector-based truth search
        "logic": query_truths_by_vector_logic,
        "input_model": QueryTruthsByVectorInput,
        "output_model": QueryTruthsByVectorOutput,
    },
}

# --- FastAPI Endpoint for Opcode Execution ---
@router.post("/execute-opcode", response_model=ExecuteOpcodeResponse, summary="Execute a Vector Kernel Opcode")
async def execute_opcode_endpoint(request: ExecuteOpcodeRequest):
    start_total_time = time.perf_counter()
    
    opcode_info = OPCODE_FUNCTIONS.get(request.opcode_name)
    if not opcode_info:
        raise HTTPException(status_code=404, detail=f"Opcode '{request.opcode_name}' not found.")

    try:
        # Validate inputs using the specific Pydantic model for the opcode
        validated_inputs = opcode_info["input_model"](**request.inputs)
        
        # Execute the opcode logic
        outputs_pydantic_model = await opcode_info["logic"](validated_inputs)
        
        end_total_time = time.perf_counter()
        return ExecuteOpcodeResponse(
            opcode_name=request.opcode_name,
            outputs=outputs_pydantic_model.model_dump(), # Use .model_dump() for Pydantic v2
            success=True,
            message=f"Opcode '{request.opcode_name}' executed successfully.",
            execution_time_ms=(end_total_time - start_total_time) * 1000
        )
    except HTTPException as e:
        end_total_time = time.perf_counter()
        return ExecuteOpcodeResponse(
            opcode_name=request.opcode_name,
            success=False,
            message=f"Opcode '{request.opcode_name}' failed: {e.detail}",
            execution_time_ms=(end_total_time - start_total_time) * 1000,
            error_details=e.detail
        )
    except Exception as e:
        end_total_time = time.perf_counter()
        return ExecuteOpcodeResponse(
            opcode_name=request.opcode_name,
            success=False,
            message=f"Opcode '{request.opcode_name}' failed unexpectedly.",
            execution_time_ms=(end_total_time - start_total_time) * 1000,
            error_details=str(e)
        )