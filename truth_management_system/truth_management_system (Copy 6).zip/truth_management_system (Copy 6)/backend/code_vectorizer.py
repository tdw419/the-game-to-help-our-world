# backend/code_vectorizer.py

import os
import hashlib
from sentence_transformers import SentenceTransformer
from backend.vector_db_client import store_vector
import glob

# Load a pre-trained model
# Using a model that is good for semantic search
model = SentenceTransformer('all-MiniLM-L6-v2')

# Define file types to include and directories to exclude
# This can be customized as needed
FILES_TO_INCLUDE = [
    "**/*.py",
    "**/*.ts",
    "**/*.tsx",
    "**/*.js",
    "**/*.md",
]
DIRS_TO_EXCLUDE = [
    "**/node_modules/**",
    "**/.git/**",
    "**/__pycache__/**",
    "**/dist/**",
    "**/build/**",
    "**/chroma_db/**", # Exclude the DB itself
]

CHUNK_SIZE = 1024  # Size of text chunks in characters
CHUNK_OVERLAP = 200 # Overlap between chunks

def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, chunk_overlap: int = CHUNK_OVERLAP) -> List[str]:
    """Splits a long text into smaller overlapping chunks."""
    if len(text) <= chunk_size:
        return [text]
    
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])
        start += chunk_size - chunk_overlap
    return chunks

def vectorize_codebase(root_dir: str):
    """
    Scans the codebase, chunks the files, creates embeddings, and stores them.
    """
    print("Starting codebase vectorization...")

    # Use glob to find all files matching the patterns
    all_files = []
    for pattern in FILES_TO_INCLUDE:
        all_files.extend(glob.glob(os.path.join(root_dir, pattern), recursive=True))

    # Filter out excluded directories
    files_to_process = []
    for file_path in all_files:
        is_excluded = False
        for exclude_pattern in DIRS_TO_EXCLUDE:
            if glob.fnmatch.fnmatch(file_path, os.path.join(root_dir, exclude_pattern)):
                is_excluded = True
                break
        if not is_excluded:
            files_to_process.append(file_path)

    print(f"Found {len(files_to_process)} files to process.")

    for file_path in files_to_process:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            chunks = chunk_text(content)
            
            for i, chunk in enumerate(chunks):
                # Create an embedding for the chunk
                vector_data = model.encode(chunk).tolist()
                
                # Create a unique ID for the vector
                # Using a hash of file path and chunk index
                vector_id = hashlib.sha256(f"{file_path}_{i}".encode()).hexdigest()
                
                # Define metadata for the vector
                metadata = {
                    "file_path": file_path,
                    "chunk_index": i,
                    "content_preview": chunk[:256] # Store a short preview
                }
                
                # Store the vector in the database
                result = store_vector(vector_id, vector_data, metadata)
                if result["status"] == "failed":
                    print(f"Failed to store vector for {file_path}, chunk {i}: {result['message']}")

        except Exception as e:
            print(f"Error processing file {file_path}: {e}")

    print("Codebase vectorization complete.")

if __name__ == "__main__":
    # When run as a script, vectorize the current project directory
    # Assumes the script is run from the project root
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    vectorize_codebase(project_root)
