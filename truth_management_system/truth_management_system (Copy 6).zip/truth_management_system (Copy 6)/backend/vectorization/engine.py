# backend/vectorization/engine.py

import json
from typing import Dict, List, Any
import hashlib
import random # For simulating vector data

def _generate_mock_vector(dimensions: int) -> List[float]:
    """Generates a mock vector of specified dimensions."""
    return [round(random.uniform(0.0, 1.0), 4) for _ in range(dimensions)]

def vectorize_x86_instruction(raw_instruction_bytes: bytes) -> Dict[str, Any]:
    """
    Simulates the vectorization of raw x86 instruction bytes into a vector
    and associated metadata, based on X86_INSTR_VEC_SCHEMA.
    """
    print(f"Simulating vectorize_x86_instruction for: {raw_instruction_bytes.hex()}")

    # Conceptual disassembly (for mock metadata)
    mock_disassembly = f"MOCK_INSTR_{raw_instruction_bytes.hex()}"
    if raw_instruction_bytes == b'\x90': # NOP
        mock_disassembly = "NOP"
    elif raw_instruction_bytes.startswith(b'\xb8'): # MOV EAX, imm32
        mock_disassembly = f"MOV EAX, 0x{raw_instruction_bytes[1:].hex()}"

    # Mock vector data based on schema (simplified)
    vector_data = _generate_mock_vector(64) # 64-dimensional mock vector

    metadata = {
        "hash": f"sha256:{hashlib.sha256(raw_instruction_bytes).hexdigest()}",
        "disassembly": mock_disassembly,
        "raw_bytes": list(raw_instruction_bytes),
        "opcode_type_embedding": _generate_mock_vector(8), # Example sub-embedding
        "operand_types_embedding": _generate_mock_vector(16) # Example sub-embedding
    }

    return {
        "vector_data": vector_data,
        "metadata": metadata
    }

def vectorize_memory_page(raw_memory_bytes: bytes, address: int) -> Dict[str, Any]:
    """
    Simulates the vectorization of raw memory page bytes into a vector
    and associated metadata, based on MEMORY_PAGE_VEC_SCHEMA.
    """
    print(f"Simulating vectorize_memory_page for address: 0x{address:x}, size: {len(raw_memory_bytes)} bytes")

    # Mock vector data based on schema (simplified)
    vector_data = _generate_mock_vector(256) # 256-dimensional mock vector

    # Simple entropy approximation for mock
    byte_counts = [raw_memory_bytes.count(b.to_bytes(1, 'big')) for b in range(256)]
    total_bytes = len(raw_memory_bytes)
    mock_entropy = -sum((count / total_bytes) * (0 if count == 0 else (count / total_bytes)) for count in byte_counts) if total_bytes > 0 else 0.0
    mock_entropy = round(mock_entropy, 4)

    metadata = {
        "base_address": address,
        "size": len(raw_memory_bytes),
        "entropy": mock_entropy,
        "executability_likelihood": round(random.uniform(0.0, 1.0), 4),
        "accessed": False, # Initial state
        "modified": False, # Initial state
        "containing_instruction_ids": [], # To be populated by xIVE
    }

    return {
        "vector_data": vector_data,
        "metadata": metadata
    }

def vectorize_cpu_state(registers: Dict[str, Any], flags: Dict[str, bool], program_counter: int) -> Dict[str, Any]:
    """
    Simulates the vectorization of CPU state (registers, flags, program counter)
    into a vector and associated metadata, based on CPU_STATE_VEC_SCHEMA.
    """
    print(f"Simulating vectorize_cpu_state for PC: 0x{program_counter:x}")

    # Mock vector data based on schema (simplified)
    # Combine register values, flags, and PC into a single flattened list for vector
    vector_components = []
    # Example: normalize register values
    for reg_name in sorted(registers.keys()): # Consistent order
        vector_components.append(registers[reg_name] / 0xFFFFFFFF) # Assuming 32-bit registers

    # Example: add flags as binary
    for flag_name in sorted(flags.keys()): # Consistent order
        vector_components.append(1.0 if flags[flag_name] else 0.0)

    vector_components.append(program_counter / 0xFFFFFFFF) # Normalize PC

    vector_data = _generate_mock_vector(len(vector_components)) # Dynamically sized mock vector

    metadata = {
        "registers": registers,
        "flags": flags,
        "program_counter": program_counter,
        "last_executed_instruction_id": None, # To be populated by xIVE
        "active_memory_pages": [], # To be populated by xIVE
    }

    return {
        "vector_data": vector_data,
        "metadata": metadata
    }

