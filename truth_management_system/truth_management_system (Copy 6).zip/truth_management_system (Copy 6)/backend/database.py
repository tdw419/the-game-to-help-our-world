import sqlite3
from typing import Dict, Tuple, List, Optional
from datetime import datetime
import json
import numpy as np
from scipy.spatial.distance import cosine

from backend.main import FoundationalTruth # NEW: Import FoundationalTruth model

DATABASE_URL = "truth_management.db"

def get_db_connection():
    conn = sqlite3.connect(DATABASE_URL)
    conn.row_factory = sqlite3.Row # This allows accessing columns by name
    return conn

def create_db_tables():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS code_truth_scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code_unit_identifier TEXT UNIQUE NOT NULL,
            truth_score REAL NOT NULL,
            last_calculated_at TEXT NOT NULL,
            usage_count INTEGER NOT NULL
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS foundational_truths (
            name TEXT PRIMARY KEY UNIQUE NOT NULL,
            content TEXT NOT NULL,
            source TEXT NOT NULL,
            rating REAL NOT NULL,
            is_immutable INTEGER NOT NULL,
            is_active INTEGER NOT NULL,
            last_updated_by TEXT NOT NULL,
            last_updated_at TEXT NOT NULL,
            content_vector TEXT
        )
    """)
    conn.commit()
    conn.close()

def save_truth_scores(scores: Dict[str, float], raw_usage_counts: Dict[str, int]):
    conn = get_db_connection()
    cursor = conn.cursor()
    now = datetime.now().isoformat()

    for identifier, score in scores.items():
        usage = raw_usage_counts.get(identifier, 0)
        cursor.execute(
            """
            INSERT INTO code_truth_scores (code_unit_identifier, truth_score, last_calculated_at, usage_count)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(code_unit_identifier) DO UPDATE SET
                truth_score = EXCLUDED.truth_score,
                last_calculated_at = EXCLUDED.last_calculated_at,
                usage_count = EXCLUDED.usage_count
            """,
            (identifier, score, now, usage)
        )
    conn.commit()
    conn.close()

def get_all_truth_scores() -> Dict[str, Tuple[float, int, str]]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT code_unit_identifier, truth_score, usage_count, last_calculated_at FROM code_truth_scores")
    scores_data = cursor.fetchall()
    conn.close()
    return {
        row['code_unit_identifier']: (row['truth_score'], row['usage_count'], row['last_calculated_at'])
        for row in scores_data
    }

def get_truth_score_by_identifier(identifier: str) -> Optional[Tuple[float, int, str]]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT truth_score, usage_count, last_calculated_at FROM code_truth_scores WHERE code_unit_identifier = ?",
        (identifier,)
    )
    row = cursor.fetchone()
    conn.close()
    if row:
        return (row['truth_score'], row['usage_count'], row['last_calculated_at'])
    return None

def clear_truth_scores_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM code_truth_scores")
    conn.commit()
    conn.close()

# NEW: Functions for Foundational Truths
def save_foundational_truth(truth: FoundationalTruth):
    conn = get_db_connection()
    cursor = conn.cursor()
    # Serialize content_vector to JSON string if it exists
    content_vector_json = json.dumps(truth.content_vector) if truth.content_vector is not None else None
    cursor.execute(
        """
        INSERT OR REPLACE INTO foundational_truths (name, content, source, rating, is_immutable, is_active, last_updated_by, last_updated_at, content_vector)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            truth.name,
            truth.content,
            truth.source,
            truth.rating,
            int(truth.is_immutable), # Convert bool to int for SQLite
            int(truth.is_active),   # Convert bool to int for SQLite
            truth.last_updated_by,
            truth.last_updated_at,
            content_vector_json, # Add the serialized vector
        )
    )
    conn.commit()
    conn.close()

def get_foundational_truth_by_name(name: str) -> Optional[FoundationalTruth]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT name, content, source, rating, is_immutable, is_active, last_updated_by, last_updated_at, content_vector FROM foundational_truths WHERE name = ?",
        (name,)
    )
    row = cursor.fetchone()
    conn.close()
    if row:
        content_vector_list = json.loads(row['content_vector']) if row['content_vector'] else None
        return FoundationalTruth(
            name=row['name'],
            content=row['content'],
            source=row['source'],
            rating=row['rating'],
            is_immutable=bool(row['is_immutable']), # Convert int to bool
            is_active=bool(row['is_active']),     # Convert int to bool
            last_updated_by=row['last_updated_by'],
            last_updated_at=row['last_updated_at'],
            content_vector=content_vector_list, # Add the deserialized vector
        )
    return None

def get_all_foundational_truths() -> List[FoundationalTruth]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT name, content, source, rating, is_immutable, is_active, last_updated_by, last_updated_at, content_vector FROM foundational_truths")
    rows = cursor.fetchall()
    conn.close()
    return [
        FoundationalTruth(
            name=row['name'],
            content=row['content'],
            source=row['source'],
            rating=row['rating'],
            is_immutable=bool(row['is_immutable']),
            is_active=bool(row['is_active']),
            last_updated_by=row['last_updated_by'],
            last_updated_at=row['last_updated_at'],
            content_vector=json.loads(row['content_vector']) if row['content_vector'] else None,
        )
        for row in rows
    ]

def clear_foundational_truths_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM foundational_truths")
    conn.commit()
    conn.close()

def query_foundational_truths_by_vector(query_vector: List[float], top_k: int = 5) -> List[Tuple[FoundationalTruth, float]]:
    all_truths = get_all_foundational_truths()
    if not all_truths:
        return []

    query_np_vector = np.array(query_vector)
    
    scored_truths = []
    for truth in all_truths:
        if truth.content_vector:
            truth_np_vector = np.array(truth.content_vector)
            # Cosine distance returns 0 for identical vectors, so 1 - distance is similarity
            similarity = 1 - cosine(query_np_vector, truth_np_vector)
            scored_truths.append((truth, similarity))

    # Sort by similarity in descending order
    scored_truths.sort(key=lambda x: x[1], reverse=True)

    return scored_truths[:top_k]

if __name__ == "__main__":
    create_db_tables()
    print("Database tables checked/created.")
