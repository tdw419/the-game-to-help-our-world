
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import datetime
import time
import sqlite3
import asyncio
from contextlib import closing
from jose import JWTError, jwt
import bcrypt
import chromadb
from sentence_transformers import SentenceTransformer

# --- Main App and Configuration ---
app = FastAPI(
    title="pxOS Semantic Backend",
    description="Service for opcode execution and semantic intent routing.",
    version="1.0.0",
)

# --- Security and Auth Config ---
SECRET_KEY = "a_very_secret_key_that_should_be_in_an_env_file"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# --- Semantic Router Config ---
CHROMA_DB_PATH = "./chroma_db"
OPCODE_COLLECTION_NAME = "opcode_codebook"
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"

# --- Database Config ---
DB_FILE = "system_states.db"

# --- In-Memory Stores ---
# These will be populated on startup
fake_users_db = {}
opcode_definitions_db = {} # Simple key-value store for opcode details

# --- Pydantic Models ---
class Token(BaseModel):
    access_token: str
    token_type: str

class User(BaseModel):
    username: str

class UserInDB(User):
    hashed_password: str

class ExecuteOpcodeRequest(BaseModel):
    opcode_name: str
    input_params: Dict[str, Any] = {}
    
class ExecuteIntentRequest(BaseModel):
    command: str
    parameters: Optional[Dict[str, Any]] = None

class ExecuteIntentResponse(BaseModel):
    executed_opcode_name: str
    result: Any
    confidence: float
    message: str

# --- Startup Event ---
@app.on_event("startup")
def on_startup():
    """Initialize all services on application startup."""
    print("Application starting up...")
    
    # 1. Initialize SQLite DB
    init_db()
    print("SQLite database initialized.")
    
    # 2. Initialize Auth User
    if "testuser" not in fake_users_db:
        password = "testpassword"
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        fake_users_db["testuser"] = {
            "username": "testuser",
            "hashed_password": hashed_password.decode('utf-8'),
        }
    print("Initial user configured.")

    # 3. Initialize Semantic Router
    print(f"Loading embedding model '{EMBEDDING_MODEL_NAME}'...")
    app.state.embedding_model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    print("Embedding model loaded.")
    
    print("Initializing ChromaDB vector store...")
    app.state.chroma_client = chromadb.PersistentClient(path=CHROMA_DB_PATH)
    app.state.opcode_collection = app.state.chroma_client.get_or_create_collection(name=OPCODE_COLLECTION_NAME)
    print("ChromaDB client and collection are ready.")
    
    # 4. Populate Vector Codebook
    initialize_vector_codebook()
    print("Startup complete.")

def init_db():
    # ... (init_db function remains the same)
    with closing(sqlite3.connect(DB_FILE)) as db:
        db.execute("PRAGMA foreign_keys = ON;")
        cursor = db.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_health_states (id INTEGER PRIMARY KEY, state_value REAL NOT NULL, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS anomaly_feedback (id INTEGER PRIMARY KEY, anomaly_id TEXT NOT NULL, is_correct BOOLEAN NOT NULL, user_comment TEXT, feedback_by TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)
        """)
        db.commit()

def initialize_vector_codebook(force_reindex: bool = False):
    """Loads opcodes, generates embeddings, and stores them in ChromaDB."""
    print("Initializing vector codebook...")
    
    # In a real system, this would load from a file registry or another service
    known_opcodes = [
        {"id": "ANALYZE_SYSTEM_STATE_TRENDS", "description": "Analyze recent system logs and performance metrics to identify any emerging trends or anomalies that might indicate future problems."},
        {"id": "SEND_ALERT", "description": "Send a critical alert or notification to an operator or system channel about an important event."},
        {"id": "SUBMIT_FEEDBACK", "description": "Submit user feedback about a detected anomaly, labeling it as correct or incorrect to improve future analysis."},
        {"id": "GET_USER_SETTINGS", "description": "Retrieve the current settings and preferences for a given user ID."},
        {"id": "DEPLOY_MICROSERVICE", "description": "Initiate the deployment process for a specified microservice to the staging or production environment."},
        # ANSMO Opcodes
        {"id": "NEURO_INTROSPECTION", "description": "Perform neuro-introspection on a neural component. Analyze its structure, weights, and performance data to identify inefficiencies and architectural insights."},
        {"id": "NEURO_SYMBOLIC_SYNTHESIS", "description": "Synthesize an optimized neural network architecture based on symbolic requirements and architectural insights."},
        {"id": "NEURO_COMPONENT_OPTIMIZATION", "description": "Optimize and deploy a neural component using a new architecture blueprint, including validation and integration."}
    ]
    
    for opcode in known_opcodes:
        opcode_definitions_db[opcode["id"]] = opcode

    collection = app.state.opcode_collection
    
    if not force_reindex:
        existing_ids = collection.get(ids=[op['id'] for op in known_opcodes])['ids']
        opcodes_to_add = [op for op in known_opcodes if op['id'] not in existing_ids]
    else:
        opcodes_to_add = known_opcodes

    if not opcodes_to_add:
        print("Vector codebook is already up-to-date.")
        return

    print(f"Vectorizing {len(opcodes_to_add)} opcodes...")
    embeddings = app.state.embedding_model.encode([op['description'] for op in opcodes_to_add])
    
    collection.add(
        embeddings=embeddings,
        documents=[op['description'] for op in opcodes_to_add],
        metadatas=[{"name": op['id']} for op in opcodes_to_add],
        ids=[op['id'] for op in opcodes_to_add]
    )
    print(f"Successfully added {len(opcodes_to_add)} opcodes to the vector codebook.")

# --- Auth Endpoints and Dependencies ---
# ... (Authentication functions like get_user, create_access_token, get_current_active_user remain the same)
@app.post("/login", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    # ... (Login logic remains the same)
    user = fake_users_db.get(form_data.username)
    if not user or not bcrypt.checkpw(form_data.password.encode('utf-8'), user["hashed_password"].encode('utf-8')):
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    access_token = create_access_token(data={"sub": user["username"]})
    return {"access_token": access_token, "token_type": "bearer"}

# --- Semantic Router Endpoint ---
@app.post("/execute_intent", response_model=ExecuteIntentResponse)
async def execute_intent(request: ExecuteIntentRequest, current_user: User = Depends(get_current_active_user)):
    """
    Receives a natural language command, finds the most semantically similar opcode,
    and mocks its execution.
    """
    print(f"Received intent: '{request.command}'")
    command_embedding = app.state.embedding_model.encode(request.command)
    
    results = app.state.opcode_collection.query(
        query_embeddings=[command_embedding.tolist()],
        n_results=1
    )
    
    if not results['ids'][0]:
        raise HTTPException(status_code=404, detail="No suitable opcode found for the given intent.")

    matched_opcode_id = results['ids'][0][0]
    # Chroma's L2 distance is not a direct confidence score. Lower is better.
    # We'll invent a simple conversion for demonstration.
    confidence = max(0, 1 - (results['distances'][0][0] / 2))

    print(f"Semantically routed to opcode '{matched_opcode_id}' with confidence {confidence:.2f}")

    # --- MOCK EXECUTION ---
    # In a real system, you would now call the actual function for this opcode
    mock_result = {
        "status": "mock_success",
        "details": f"Successfully routed to {matched_opcode_id}. Actual execution would happen here.",
        "received_params": request.parameters
    }
    
    return ExecuteIntentResponse(
        executed_opcode_name=matched_opcode_id,
        result=mock_result,
        confidence=confidence,
        message=f"Intent '{request.command}' was routed to opcode '{matched_opcode_id}'."
    )

# --- Opcode Execution Logic ---

async def handle_neuro_introspection(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handler for the NEURO_INTROSPECTION opcode.
    Simulates analyzing a neural component and returns identified inefficiencies.
    """
    component_id = params.get("component_id", "Unknown Component")
    print(f"Executing NEURO_INTROSPECTION for component: {component_id}")
    await asyncio.sleep(1.5) # Simulate the time taken for analysis
    
    # This is the same simulated data that was in the frontend.
    inefficiencies = [
        "High parameter count (1.2M)",
        "Minor overfitting detected in edge cases",
        "Suboptimal activation function for current task"
    ]
    
    return {
        "status": "success",
        "component_id": component_id,
        "identified_inefficiencies": inefficiencies,
        "message": f"Introspection complete for {component_id}."
    }

async def handle_neuro_synthesis(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handler for the NEURO_SYMBOLIC_SYNTHESIS opcode.
    Simulates generating a new architecture blueprint.
    """
    inefficiencies = params.get("inefficiencies", [])
    print(f"Executing NEURO_SYMBOLIC_SYNTHESIS based on {len(inefficiencies)} inefficiencies.")
    await asyncio.sleep(2) # Simulate synthesis time
    
    blueprint = f"Optimized v{time.time() % 100:.2f} - Latency-optimized, diversified ensemble."
    
    return {
        "status": "success",
        "new_architecture_blueprint": blueprint,
        "message": "Synthesis of new architecture blueprint complete."
    }

async def handle_neuro_optimization(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handler for the NEURO_COMPONENT_OPTIMIZATION opcode.
    Simulates testing and deploying the new component.
    """
    blueprint = params.get("new_architecture_blueprint", "N/A")
    print(f"Executing NEURO_COMPONENT_OPTIMIZATION for blueprint: {blueprint}")
    await asyncio.sleep(2.5) # Simulate testing and deployment
    
    return {
        "status": "success",
        "optimization_success": True,
        "deployment_status": "deployed_successfully",
        "actual_performance_gain": "Latency -22%, Generalization +7%",
        "message": "Optimization, validation, and deployment cycle finished."
    }

# Map of opcode names to their handler functions
OPCODE_HANDLERS = {
    "NEURO_INTROSPECTION": handle_neuro_introspection,
    "NEURO_SYMBOLIC_SYNTHESIS": handle_neuro_synthesis,
    "NEURO_COMPONENT_OPTIMIZATION": handle_neuro_optimization,
}


# --- Standard Opcode Execution Endpoint ---
@app.post("/execute_opcode")
async def execute_opcode(req: ExecuteOpcodeRequest, current_user: User = Depends(get_current_active_user)):
    """
    Executes a specific opcode by name, looking up its handler from the map.
    """
    handler = OPCODE_HANDLERS.get(req.opcode_name)
    
    if not handler:
        raise HTTPException(
            status_code=404,
            detail=f"Opcode '{req.opcode_name}' not found or not implemented."
        )
        
    print(f"Executing opcode '{req.opcode_name}' with params: {req.input_params}")
    try:
        result = await handler(req.input_params)
        return result
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while executing opcode '{req.opcode_name}': {str(e)}"
        )