# AI-VAM (AI-Driven Adaptive Manager) Agent

This project implements the AI-Driven Adaptive Manager (AI-VAM) agent within the `Better Agents` framework, designed to interact with the VectorOS boot simulation. The AI-VAM's primary role is to learn, experiment, and propose optimizations for the VectorOS boot process, leveraging its expertise in vector computations and truth management.

## Overview

The AI-VAM agent functions as the intelligent core of the AI learning experimentation loop. It observes the state of the VectorOS boot simulation, formulates hypotheses for optimization, designs experiments by proposing changes to simulation parameters, triggers simulation runs via pxOS `create_Execution` calls, evaluates outcomes, and conceptually updates its internal model.

This project is structured to be compatible with the `Better Agents` CLI tool and best practices, ensuring a robust and testable AI agent.

## Getting Started

To set up and run the AI-VAM agent locally:

1. **Navigate to the project directory:**
   ```bash
   cd backend/ai_agents/ai_vam/
   ```

2. **Install Dependencies:**
   ```bash
   pnpm install
   ```
   This will install `better-agents`, TypeScript, Vitest, and other necessary development dependencies.

3. **Build the Agent:**
   ```bash
   pnpm run build
   ```
   This compiles the TypeScript source code (`src/app/ai_vam_agent.ts`) into JavaScript in the `dist/` directory.

## Project Structure

This project follows the recommended `Better Agents` structure:

* **`app/` (or `src/app/`)**: Contains the core logic of the AI-VAM agent.
  * `ai_vam_agent.ts`: The main implementation of the `AiVamAgent` class, defining its observation, proposal, and evaluation methods.
* **`prompts/`**: Stores versioned prompt templates used by the AI-VAM for LLM interactions.
  * `hypothesis_generation.yaml`: A conceptual prompt for the AI to generate optimization hypotheses.
* **`tests/scenarios/`**: End-to-end scenario tests to validate the AI-VAM's behavior.
  * `ai_vam_experiment.test.ts`: A conceptual test to verify the agent's experimentation loop.
* **`package.json`**: Project metadata and scripts.
* **`tsconfig.json`**: TypeScript compiler configuration.
* **`AGENTS.md`**: Detailed development guidelines (this file you're reading).

## Running the Agent (Conceptual)

The `AiVamAgent` is designed to be instantiated and run by a backend service that orchestrates AI experiments.

To conceptually run the agent from the command line (after building):
