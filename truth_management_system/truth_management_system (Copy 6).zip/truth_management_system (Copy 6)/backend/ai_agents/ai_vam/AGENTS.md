# AI-VAM (AI-Driven Adaptive Manager) Agent Development Guidelines

This document outlines the development guidelines for the AI-VAM agent, which is responsible for learning and experimenting within the VectorOS boot simulation.

## Overview

The AI-VAM agent leverages LLMs, vector databases, and pxOS execution capabilities to propose and evaluate changes to the VectorOS boot sequence. Its primary goal is to optimize boot time, stability, and resource efficiency through autonomous experimentation.

## Key Responsibilities

*   **Hypothesis Generation**: Formulate hypotheses for improving boot performance based on observed simulation data.
*   **Experiment Design**: Translate hypotheses into concrete changes to `bootSequence` parameters and `simulationSuccessRate`.
*   **Execution Orchestration**: Trigger simulation runs via the `VectorOSBootOrchestrator`'s API.
*   **Observation & Evaluation**: Analyze simulation results (success/failure, metrics) and provide feedback.
*   **Knowledge Update**: Store learned rules and optimal configurations in the Vector DB.

## Project Structure

*   `./app/`: Core agent code (TypeScript).
    *   `./app/ai_vam_agent.ts`: Main logic for the AI-VAM agent.
    *   `./app/observation_space.ts`: Defines how simulation data is vectorized for the AI.
    *   `./app/action_space.ts`: Defines how AI proposals translate to simulation parameter changes.
*   `./prompts/`: Versioned prompt templates for LLM interactions.
    *   `./prompts/hypothesis_generation.yaml`
    *   `./prompts/experiment_design.yaml`
    *   `./prompts/evaluation_feedback.yaml`
*   `./tests/`: Tests for the agent.
    *   `./tests/scenarios/`: End-to-end tests for AI-VAM behavior.
    *   `./tests/evaluations/`: Notebooks for evaluating AI-VAM's performance.

## Getting Started

1.  Ensure Node.js and pnpm are installed.
2.  Run `pnpm install` in this directory to install dependencies.
3.  Implement agent logic in `./app/`.
4.  Define and version prompts in `./prompts/`.
5.  Write tests and evaluation notebooks.

## Contributing

Follow the established project conventions and testing methodologies. All AI-VAM proposals and evaluations should be transparent and traceable via pxOS `Execution` records.
