# backend/agent_orchestration/core.py

import json
import random
import uuid
from datetime import datetime
from typing import Dict, List, Any, Literal, Optional

# --- Mock In-Memory Data Stores ---
# Stores agent registration and their knowledge base summaries
_registered_agents: Dict[str, Dict[str, Any]] = {}

# Stores messages for each agent, acting as their "inbox"
_agent_message_inboxes: Dict[str, List[Dict[str, Any]]] = {}

# --- Helper Functions (Internal to this module) ---
def _generate_agent_id() -> str:
    return f"agent_{uuid.uuid4().hex[:8]}"

def _get_current_timestamp() -> str:
    return datetime.now().isoformat()

# --- AGENT_* Opcode Implementations (Conceptual) ---

def agent_create(name: str, initial_focus: str, initial_knowledge: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Simulates the creation of a new AI agent.
    """
    agent_id = _generate_agent_id()
    print(f"Agent Orchestration: Creating agent '{name}' with ID '{agent_id}'")

    if initial_knowledge is None:
        initial_knowledge = {
            "hypotheses_shared": 0,
            "knowledge_processed": 0,
            "current_focus": initial_focus,
            "last_update": _get_current_timestamp(),
        }

    _registered_agents[agent_id] = {
        "id": agent_id,
        "name": name,
        "knowledge_base": initial_knowledge,
        "created_at": _get_current_timestamp(),
    }
    _agent_message_inboxes[agent_id] = [] # Initialize inbox

    return {
        "status": "success",
        "message": f"Agent '{name}' created successfully.",
        "details": {"agent_id": agent_id, "name": name, "initial_knowledge": initial_knowledge}
    }

def agent_get_state(agent_id: str) -> Dict[str, Any]:
    """
    Simulates retrieving the current state and knowledge summary of an agent.
    """
    print(f"Agent Orchestration: Getting state for agent '{agent_id}'")
    agent_data = _registered_agents.get(agent_id)
    if not agent_data:
        return {"status": "failed", "message": f"Agent '{agent_id}' not found.", "details": {}}
    
    return {
        "status": "success",
        "message": f"State for agent '{agent_id}' retrieved.",
        "details": {"agent": agent_data}
    }

def agent_send_message(
    sender_id: str,
    recipient_ids: List[str],
    message_type: str,
    payload: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Simulates an agent sending a message to one or more recipients.
    """
    print(f"Agent Orchestration: Agent '{sender_id}' sending '{message_type}' to {recipient_ids}")

    successful_recipients = []
    failed_recipients = []
    message_id = f"msg_{uuid.uuid4().hex[:12]}"
    timestamp = _get_current_timestamp()

    message_content = {
        "message_id": message_id,
        "sender_id": sender_id,
        "message_type": message_type,
        "payload": payload,
        "timestamp": timestamp,
        "read_status": "unread"
    }

    for rec_id in recipient_ids:
        if rec_id in _registered_agents:
            _agent_message_inboxes[rec_id].append(message_content)
            successful_recipients.append(rec_id)
        else:
            failed_recipients.append(rec_id)

    return {
        "status": "success",
        "message": f"Message '{message_id}' sent.",
        "details": {
            "message_id": message_id,
            "sender_id": sender_id,
            "message_type": message_type,
            "successful_recipients": successful_recipients,
            "failed_recipients": failed_recipients,
            "timestamp": timestamp,
        }
    }

def agent_receive_messages(
    agent_id: str,
    message_types_filter: Optional[List[str]] = None,
    read_status_filter: Optional[Literal["read", "unread"]] = "unread"
) -> Dict[str, Any]:
    """
    Simulates an agent receiving messages from its inbox.
    """
    print(f"Agent Orchestration: Agent '{agent_id}' receiving messages (filter: {message_types_filter}, status: {read_status_filter})")

    if agent_id not in _registered_agents:
        return {"status": "failed", "message": f"Agent '{agent_id}' not found.", "details": {}}

    inbox = _agent_message_inboxes.get(agent_id, [])
    filtered_messages = []

    for msg in inbox:
        if read_status_filter == "unread" and msg["read_status"] == "read":
            continue
        if message_types_filter and msg["message_type"] not in message_types_filter:
            continue
        filtered_messages.append(msg)
    
    # Mark as read (simulate side effect)
    for msg in filtered_messages:
        msg["read_status"] = "read"
    
    return {
        "status": "success",
        "message": f"Agent '{agent_id}' retrieved {len(filtered_messages)} messages.",
        "details": {"messages": filtered_messages}
    }

def agent_share_knowledge(
    sender_id: str,
    knowledge_payload: Dict[str, Any],
    recipient_ids: Optional[List[str]] = None, # If None, broadcast to all other agents
    knowledge_type: str = "general_knowledge"
) -> Dict[str, Any]:
    """
    Simulates an agent sharing a piece of knowledge. This uses AGENT_SEND_MESSAGE internally.
    """
    print(f"Agent Orchestration: Agent '{sender_id}' sharing knowledge of type '{knowledge_type}'")

    if sender_id not in _registered_agents:
        return {"status": "failed", "message": f"Sender agent '{sender_id}' not found.", "details": {}}

    actual_recipient_ids = []
    if recipient_ids:
        actual_recipient_ids = [rid for rid in recipient_ids if rid in _registered_agents]
    else: # Broadcast
        actual_recipient_ids = [aid for aid in _registered_agents if aid != sender_id]
    
    if not actual_recipient_ids:
        return {"status": "failed", "message": "No valid recipients found for knowledge sharing.", "details": {}}

    message_type = "knowledge_share"
    payload = {
        "knowledge_type": knowledge_type,
        "content": knowledge_payload,
        "source_agent_id": sender_id,
        "confidence": knowledge_payload.get("confidence", 0.8) # Example confidence for shared knowledge
    }

    send_result = agent_send_message(sender_id, actual_recipient_ids, message_type, payload)
    
    if send_result["status"] == "success":
        # Update sender's knowledge base summary (conceptual)
        sender_agent_data = _registered_agents[sender_id]
        sender_agent_data["knowledge_base"]["hypotheses_shared"] = sender_agent_data["knowledge_base"].get("hypotheses_shared", 0) + 1
        _registered_agents[sender_id] = sender_agent_data # Update in mock DB

        return {
            "status": "success",
            "message": "Knowledge shared successfully.",
            "details": send_result["details"]
        }
    else:
        return {"status": "failed", "message": "Failed to send knowledge message.", "details": send_result["details"]}


def agent_process_shared_knowledge(agent_id: str, message_payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Simulates an agent processing a received knowledge message.
    """
    print(f"Agent Orchestration: Agent '{agent_id}' processing shared knowledge.")

    if agent_id not in _registered_agents:
        return {"status": "failed", "message": f"Agent '{agent_id}' not found.", "details": {}}

    knowledge_type = message_payload.get("knowledge_type")
    content = message_payload.get("content")
    source_agent_id = message_payload.get("source_agent_id")
    confidence = message_payload.get("confidence")

    # Simulate processing and integration into the agent's knowledge base
    # This is where an agent would update its internal model, evaluate the knowledge, etc.
    knowledge_integrated = random.random() > 0.2 # 80% chance of successful integration

    agent_data = _registered_agents[agent_id]
    agent_data["knowledge_base"]["knowledge_processed"] = agent_data["knowledge_base"].get("knowledge_processed", 0) + 1
    # Update current focus if the new knowledge is highly relevant (conceptual)
    if "current_focus" in content.get("hypothesis", ""):
        agent_data["knowledge_base"]["current_focus"] = content["hypothesis"].split('by')[0].strip()
    agent_data["knowledge_base"]["last_update"] = _get_current_timestamp()
    _registered_agents[agent_id] = agent_data # Update in mock DB


    if knowledge_integrated:
        return {
            "status": "success",
            "message": f"Agent '{agent_id}' successfully processed shared knowledge.",
            "details": {
                "knowledge_type": knowledge_type,
                "integrated_content_preview": content.get("hypothesis", content),
                "source_agent": source_agent_id,
                "confidence_score": confidence,
                "knowledge_base_updated": True
            }
        }
    else:
        return {
            "status": "failed",
            "message": f"Agent '{agent_id}' failed to integrate shared knowledge (simulated).",
            "details": {
                "knowledge_type": knowledge_type,
                "content_preview": content.get("hypothesis", content),
                "reason": "simulated_integration_failure"
            }
        }
