import chromadb
from typing import Dict, List, Any
import json

# Initialize ChromaDB client
# Using a persistent client that saves to disk
client = chromadb.PersistentClient(path="./chroma_db")

# Get or create the collection for code embeddings
collection = client.get_or_create_collection("code_embeddings")

def store_vector(vector_id: str, vector_data: List[float], metadata: Dict[str, Any]) -> Dict[str, Any]:
    """
    Stores a vector and its associated metadata in the ChromaDB collection.
    """
    print(f"Storing vector: id={vector_id}")
    try:
        collection.add(
            embeddings=[vector_data],
            metadatas=[metadata],
            ids=[vector_id]
        )
        return {
            "status": "success",
            "message": f"Vector '{vector_id}' stored successfully.",
        }
    except Exception as e:
        return {
            "status": "failed",
            "message": str(e),
        }

def retrieve_vector(vector_id: str) -> Dict[str, Any]:
    """
    Retrieves a vector and its metadata by ID from the ChromaDB collection.
    """
    print(f"Retrieving vector: id={vector_id}")
    try:
        result = collection.get(ids=[vector_id], include=["embeddings", "metadatas"])
        if result['ids']:
            return {
                "status": "success",
                "message": f"Vector '{vector_id}' retrieved.",
                "details": {
                    "vector_id": result['ids'][0],
                    "vector_data": result['embeddings'][0],
                    "metadata": result['metadatas'][0]
                }
            }
        else:
            return {
                "status": "failed",
                "message": f"Vector '{vector_id}' not found.",
            }
    except Exception as e:
        return {
            "status": "failed",
            "message": str(e),
        }

def query_similar_vectors(query_vector: List[float], top_k: int = 5, where_clause: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Queries for similar vectors in the ChromaDB collection.
    """
    print(f"Querying for {top_k} similar vectors.")
    try:
        query_args = {
            "query_embeddings": [query_vector],
            "n_results": top_k,
            "include": ["metadatas", "distances"]
        }
        if where_clause:
            query_args["where"] = where_clause

        results = collection.query(**query_args)
        
        return {
            "status": "success",
            "message": f"Query completed for {top_k} similar vectors.",
            "details": {
                "results": [
                    {
                        "vector_id": res_id,
                        "distance": dist,
                        "metadata": meta
                    }
                    for res_id, dist, meta in zip(results['ids'][0], results['distances'][0], results['metadatas'][0])
                ]
            }
        }
    except Exception as e:
        return {
            "status": "failed",
            "message": str(e),
        }

