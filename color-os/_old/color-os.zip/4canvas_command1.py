from typing import List, Optional, Iterator, Set
from collections import deque
from dataclasses import dataclass
from enum import Enum
import re
from datetime import datetime


class HistoryMode(Enum):
    """History navigation modes."""
    SEQUENTIAL = "sequential"  # Navigate through all commands in order
    FILTERED = "filtered"      # Navigate through filtered/searched commands only


@dataclass
class HistoryEntry:
    """Represents a single command history entry."""
    command: str
    timestamp: datetime
    execution_count: int = 1
    
    def __str__(self) -> str:
        return self.command
    
    def __eq__(self, other) -> bool:
        if isinstance(other, HistoryEntry):
            return self.command == other.command
        elif isinstance(other, str):
            return self.command == other
        return False


class CommandHistory:
    """
    Advanced command history manager with search, filtering, and persistence capabilities.
    
    Features:
    - Configurable history size limits
    - Duplicate handling with execution counting
    - Command search and filtering
    - History navigation with different modes
    - Statistics and analytics
    - Import/export capabilities
    """
    
    def __init__(
        self, 
        max_size: int = 1000,
        allow_duplicates: bool = False,
        case_sensitive: bool = True,
        trim_whitespace: bool = True
    ) -> None:
        """
        Initialize command history.
        
        Args:
            max_size: Maximum number of commands to store
            allow_duplicates: Whether to allow consecutive duplicate commands
            case_sensitive: Whether command comparison is case sensitive
            trim_whitespace: Whether to trim whitespace from commands
        """
        if max_size <= 0:
            raise ValueError("max_size must be positive")
            
        self._max_size = max_size
        self._allow_duplicates = allow_duplicates
        self._case_sensitive = case_sensitive
        self._trim_whitespace = trim_whitespace
        
        # Use deque for efficient operations at both ends
        self._history: deque[HistoryEntry] = deque(maxlen=max_size)
        
        # Navigation state
        self._current_index = -1  # -1 means "after" the last command
        self._navigation_mode = HistoryMode.SEQUENTIAL
        self._filtered_indices: List[int] = []
        self._filter_pattern: Optional[str] = None
        
        # Temporary command for navigation
        self._temp_command: Optional[str] = None
        
        # Statistics
        self._total_commands_added = 0
        self._navigation_sessions = 0
    
    def add_command(self, command: str) -> bool:
        """
        Adds a command to history.
        
        Args:
            command: Command string to add
            
        Returns:
            True if command was added, False if skipped (empty/duplicate)
        """
        if not command:
            return False
            
        # Process command based on settings
        processed_cmd = command
        if self._trim_whitespace:
            processed_cmd = processed_cmd.strip()
            
        if not processed_cmd:
            return False
        
        # Check for duplicates
        if not self._allow_duplicates and self._history:
            last_entry = self._history[-1]
            if self._commands_equal(processed_cmd, last_entry.command):
                # Increment execution count instead of adding duplicate
                last_entry.execution_count += 1
                last_entry.timestamp = datetime.now()
                self._reset_navigation()
                return False
        
        # Add new entry
        entry = HistoryEntry(
            command=processed_cmd,
            timestamp=datetime.now()
        )
        
        self._history.append(entry)
        self._total_commands_added += 1
        self._reset_navigation()
        
        return True
    
    def get_previous(self, temp_command: Optional[str] = None) -> Optional[str]:
        """
        Gets the previous command in history.
        
        Args:
            temp_command: Current command being typed (saved for navigation)
            
        Returns:
            Previous command or None if at beginning
        """
        if not self._history:
            return None
            
        # Save temporary command on first navigation
        if self._current_index == -1 and temp_command is not None:
            self._temp_command = temp_command
            self._navigation_sessions += 1
        
        if self._navigation_mode == HistoryMode.FILTERED:
            return self._get_previous_filtered()
        
        # Sequential mode
        if self._current_index == -1:
            self._current_index = len(self._history) - 1
        elif self._current_index > 0:
            self._current_index -= 1
        else:
            return None  # Already at beginning
        
        return self._history[self._current_index].command
    
    def get_next(self) -> Optional[str]:
        """
        Gets the next command in history.
        
        Returns:
            Next command, temp command, or None
        """
        if not self._history or self._current_index == -1:
            return None
            
        if self._navigation_mode == HistoryMode.FILTERED:
            return self._get_next_filtered()
        
        # Sequential mode
        if self._current_index < len(self._history) - 1:
            self._current_index += 1
            return self._history[self._current_index].command
        else:
            # Return to "after history" state and return temp command
            self._current_index = -1
            temp = self._temp_command
            self._temp_command = None
            return temp
    
    def search(self, pattern: str, use_regex: bool = False) -> List[HistoryEntry]:
        """
        Searches command history for matching commands.
        
        Args:
            pattern: Search pattern
            use_regex: Whether to treat pattern as regex
            
        Returns:
            List of matching history entries
        """
        if not pattern:
            return list(self._history)
        
        matches = []
        
        for entry in self._history:
            command = entry.command
            if not self._case_sensitive:
                command = command.lower()
                pattern = pattern.lower()
            
            if use_regex:
                try:
                    if re.search(pattern, command):
                        matches.append(entry)
                except re.error:
                    # Fall back to substring search on regex error
                    if pattern in command:
                        matches.append(entry)
            else:
                if pattern in command:
                    matches.append(entry)
        
        return matches
    
    def start_filtered_navigation(self, pattern: str, use_regex: bool = False) -> int:
        """
        Starts filtered navigation mode.
        
        Args:
            pattern: Filter pattern
            use_regex: Whether to use regex matching
            
        Returns:
            Number of matching commands found
        """
        matches = self.search(pattern, use_regex)
        self._filtered_indices = [
            i for i, entry in enumerate(self._history)
            if entry in matches
        ]
        
        self._filter_pattern = pattern
        self._navigation_mode = HistoryMode.FILTERED
        self._current_index = -1
        
        return len(self._filtered_indices)
    
    def end_filtered_navigation(self) -> None:
        """Ends filtered navigation and returns to sequential mode."""
        self._navigation_mode = HistoryMode.SEQUENTIAL
        self._filtered_indices.clear()
        self._filter_pattern = None
        self._reset_navigation()
    
    def get_recent(self, count: int = 10) -> List[HistoryEntry]:
        """
        Gets the most recent commands.
        
        Args:
            count: Number of recent commands to return
            
        Returns:
            List of recent history entries
        """
        if count <= 0:
            return []
        
        start_idx = max(0, len(self._history) - count)
        return list(self._history)[start_idx:]
    
    def get_most_frequent(self, count: int = 10) -> List[HistoryEntry]:
        """
        Gets the most frequently executed commands.
        
        Args:
            count: Number of commands to return
            
        Returns:
            List of most frequent commands sorted by execution count
        """
        if count <= 0:
            return []
        
        # Sort by execution count (descending) then by timestamp (descending)
        sorted_entries = sorted(
            self._history,
            key=lambda x: (x.execution_count, x.timestamp),
            reverse=True
        )
        
        return sorted_entries[:count]
    
    def remove_command(self, command: str) -> bool:
        """
        Removes all instances of a command from history.
        
        Args:
            command: Command to remove
            
        Returns:
            True if any commands were removed
        """
        initial_length = len(self._history)
        
        # Convert to list, filter, then recreate deque
        filtered_entries = [
            entry for entry in self._history
            if not self._commands_equal(entry.command, command)
        ]
        
        self._history.clear()
        self._history.extend(filtered_entries)
        
        removed = initial_length != len(self._history)
        if removed:
            self._reset_navigation()
        
        return removed
    
    def clear(self) -> None:
        """Clears all command history."""
        self._history.clear()
        self._reset_navigation()
    
    def get_all_commands(self) -> List[str]:
        """Returns list of all commands in history order."""
        return [entry.command for entry in self._history]
    
    def get_all_entries(self) -> List[HistoryEntry]:
        """Returns list of all history entries."""
        return list(self._history)
    
    def export_history(self, include_metadata: bool = False) -> List[dict]:
        """
        Exports history in a structured format.
        
        Args:
            include_metadata: Whether to include timestamps and execution counts
            
        Returns:
            List of command data dictionaries
        """
        if include_metadata:
            return [
                {
                    'command': entry.command,
                    'timestamp': entry.timestamp.isoformat(),
                    'execution_count': entry.execution_count
                }
                for entry in self._history
            ]
        else:
            return [{'command': entry.command} for entry in self._history]
    
    def import_history(self, commands: List[str], clear_existing: bool = False) -> int:
        """
        Imports commands into history.
        
        Args:
            commands: List of commands to import
            clear_existing: Whether to clear existing history first
            
        Returns:
            Number of commands successfully imported
        """
        if clear_existing:
            self.clear()
        
        imported_count = 0
        for command in commands:
            if self.add_command(command):
                imported_count += 1
        
        return imported_count
    
    def get_navigation_context(self) -> dict:
        """Returns current navigation state information."""
        return {
            'current_index': self._current_index,
            'navigation_mode': self._navigation_mode.value,
            'filter_pattern': self._filter_pattern,
            'filtered_count': len(self._filtered_indices) if self._filtered_indices else 0,
            'has_temp_command': self._temp_command is not None,
            'total_entries': len(self._history)
        }
    
    def get_stats(self) -> dict:
        """Returns comprehensive history statistics."""
        if not self._history:
            return {
                'total_entries': 0,
                'total_commands_added': self._total_commands_added,
                'navigation_sessions': self._navigation_sessions,
                'unique_commands': 0,
                'average_execution_count': 0,
                'most_frequent_command': None,
                'oldest_command': None,
                'newest_command': None
            }
        
        # Calculate statistics
        unique_commands = len(set(entry.command for entry in self._history))
        avg_execution = sum(entry.execution_count for entry in self._history) / len(self._history)
        most_frequent = max(self._history, key=lambda x: x.execution_count)
        oldest = min(self._history, key=lambda x: x.timestamp)
        newest = max(self._history, key=lambda x: x.timestamp)
        
        return {
            'total_entries': len(self._history),
            'total_commands_added': self._total_commands_added,
            'navigation_sessions': self._navigation_sessions,
            'unique_commands': unique_commands,
            'average_execution_count': round(avg_execution, 2),
            'most_frequent_command': {
                'command': most_frequent.command,
                'count': most_frequent.execution_count
            },
            'oldest_command': {
                'command': oldest.command,
                'timestamp': oldest.timestamp.isoformat()
            },
            'newest_command': {
                'command': newest.command,
                'timestamp': newest.timestamp.isoformat()
            }
        }
    
    def configure(
        self,
        allow_duplicates: Optional[bool] = None,
        case_sensitive: Optional[bool] = None,
        trim_whitespace: Optional[bool] = None
    ) -> None:
        """Updates configuration settings."""
        if allow_duplicates is not None:
            self._allow_duplicates = allow_duplicates
        if case_sensitive is not None:
            self._case_sensitive = case_sensitive
        if trim_whitespace is not None:
            self._trim_whitespace = trim_whitespace
    
    def _get_previous_filtered(self) -> Optional[str]:
        """Gets previous command in filtered mode."""
        if not self._filtered_indices:
            return None
        
        if self._current_index == -1:
            # Start from the last filtered command
            filtered_pos = len(self._filtered_indices) - 1
        else:
            # Find current position in filtered list
            try:
                filtered_pos = self._filtered_indices.index(self._current_index)
                if filtered_pos > 0:
                    filtered_pos -= 1
                else:
                    return None  # Already at beginning of filtered results
            except ValueError:
                # Current index not in filtered results, start from end
                filtered_pos = len(self._filtered_indices) - 1
        
        self._current_index = self._filtered_indices[filtered_pos]
        return self._history[self._current_index].command
    
    def _get_next_filtered(self) -> Optional[str]:
        """Gets next command in filtered mode."""
        if not self._filtered_indices or self._current_index == -1:
            return None
        
        try:
            filtered_pos = self._filtered_indices.index(self._current_index)
            if filtered_pos < len(self._filtered_indices) - 1:
                filtered_pos += 1
                self._current_index = self._filtered_indices[filtered_pos]
                return self._history[self._current_index].command
            else:
                # End of filtered results
                self._current_index = -1
                temp = self._temp_command
                self._temp_command = None
                return temp
        except ValueError:
            return None
    
    def _commands_equal(self, cmd1: str, cmd2: str) -> bool:
        """Compares two commands based on case sensitivity setting."""
        if not self._case_sensitive:
            return cmd1.lower() == cmd2.lower()
        return cmd1 == cmd2
    
    def _reset_navigation(self) -> None:
        """Resets navigation state."""
        self._current_index = -1
        self._temp_command = None
    
    def __len__(self) -> int:
        """Returns the number of commands in history."""
        return len(self._history)
    
    def __bool__(self) -> bool:
        """Returns True if history contains commands."""
        return len(self._history) > 0
    
    def __iter__(self) -> Iterator[HistoryEntry]:
        """Allows iteration over history entries."""
        return iter(self._history)
    
    def __getitem__(self, index: int) -> HistoryEntry:
        """Allows indexing into history."""
        if isinstance(index, slice):
            return list(self._history)[index]
        return self._history[index]