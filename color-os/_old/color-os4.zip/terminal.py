import tkinter as tk
import threading
from typing import Tuple, Optional, Dict, List
import time

# --- Global Constants and Settings ---
SETTINGS = {
    "canvas_width": 800,
    "canvas_height": 600,
    "char_size": 20,
    "font": ("Courier", 14),
    "cursor_start_x": 10,
    "cursor_start_y": 10,
    "max_undo_redo": 1000,  # Limit memory size for performance
    "blink_rate": 500,  # Cursor blink rate in ms
    "color_cache_size": 256  # Cache for color calculations
}

# --- 1. Enhanced TerminalCanvas Class ---
class TerminalCanvas:
    """Manages all drawing operations and visual state on the Tkinter canvas."""
    
    def __init__(self, master: tk.Tk, canvas_width: int, canvas_height: int, 
                 char_size: int, font: Tuple[str, int]) -> None:
        # Canvas setup
        self.canvas = tk.Canvas(master, width=canvas_width, height=canvas_height, 
                               bg='black', highlightthickness=0)
        self.canvas.pack()
        
        # Configuration
        self.char_size = char_size
        self.font = font
        self.canvas_width = canvas_width
        self.canvas_height = canvas_height
        
        # Status label with better styling
        self.status_label = tk.Label(master, text="Welcome to Canvas Terminal!", 
                                   fg="white", bg="black", font=("Arial", 10))
        self.status_label.pack(fill=tk.X)
        
        # Cursor management
        self.blink_id: Optional[str] = None
        self.cursor_visible = True
        self.cursor_x = 0
        self.cursor_y = 0
        
        # Performance optimizations
        self.color_cache: Dict[int, str] = {}
        self.char_objects: Dict[Tuple[int, int], List[int]] = {}  # Track canvas objects
        
        # Threading lock for safe operations
        self.lock = threading.Lock()
        
        # Initialize canvas optimizations
        self._setup_canvas_optimizations()

    def run(self) -> None:
        """Run the canvas."""
        self.canvas.winfo_toplevel().mainloop()

    def _setup_canvas_optimizations(self) -> None:
        """Configure canvas for better performance."""
        # Disable automatic redraw for batch operations
        self.canvas.configure(scrollregion=(0, 0, self.canvas_width, self.canvas_height))

    # ... rest of the code remains the same ...