import os
from PIL import Image

# --- Conceptual PixelMemory class (for demonstration and context) ---
# This class is crucial for PixelDisk to function.
# It stores data as pixels and handles conversion to/from bytes.
class PixelMemory:
    def __init__(self, size: int):
        """
        Initializes PixelMemory with a given size in bytes.
        Each byte will be represented by 1/3 of a pixel (R, G, or B component).
        Therefore, we need enough pixels to store 'size' bytes.
        """
        self.size = size
        # Calculate pixels needed: each pixel holds 3 bytes (R, G, B)
        self.num_pixels = (size + 2) // 3 # +2 for ceiling division
        # Internal storage for pixels, initialized to black (0,0,0)
        self._pixels = [(0, 0, 0)] * self.num_pixels

    def _bytes_to_pixels(self, data: bytes) -> list[tuple[int, int, int]]:
        """Converts bytes data into a list of (R, G, B) pixel tuples."""
        pixels = []
        for i in range(0, len(data), 3):
            r = data[i] if i < len(data) else 0
            g = data[i+1] if i+1 < len(data) else 0
            b = data[i+2] if i+2 < len(data) else 0
            pixels.append((r, g, b))
        return pixels

    def _pixels_to_bytes(self, pixels: list[tuple[int, int, int]]) -> bytes:
        """Converts a list of (R, G, B) pixel tuples back into bytes."""
        data = bytearray()
        for r, g, b in pixels:
            data.extend([r, g, b])
        return bytes(data)

    def read(self, start_byte: int, end_byte: int) -> bytes:
        """
        Reads a range of bytes from memory.

        Args:
            start_byte (int): The starting byte index (inclusive).
            end_byte (int): The ending byte index (exclusive).

        Returns:
            bytes: The data read from the specified range.

        Raises:
            IndexError: If the read range is out of bounds.
        """
        if not (0 <= start_byte < self.size and 0 < end_byte <= self.size and start_byte < end_byte):
            raise IndexError(f"Memory read out of bounds: [{start_byte}, {end_byte}) for size {self.size}")

        # Determine which pixels are involved
        start_pixel_idx = start_byte // 3
        end_pixel_idx = (end_byte - 1) // 3 + 1 # +1 to include the last partial pixel

        relevant_pixels = self._pixels[start_pixel_idx:end_pixel_idx]
        all_bytes_from_pixels = self._pixels_to_bytes(relevant_pixels)

        # Calculate the offset within the first relevant pixel
        offset_in_first_pixel = start_byte % 3
        # Calculate the exact number of bytes to extract
        num_bytes_to_extract = end_byte - start_byte

        return all_bytes_from_pixels[offset_in_first_pixel : offset_in_first_pixel + num_bytes_to_extract]

    def write(self, start_byte: int, data: bytes) -> None:
        """
        Writes data (bytes) to memory starting at start_byte.

        Args:
            start_byte (int): The starting byte index.
            data (bytes): The data to write.

        Raises:
            IndexError: If the write operation goes out of bounds.
        """
        end_byte = start_byte + len(data)
        if not (0 <= start_byte < self.size and 0 < end_byte <= self.size):
            raise IndexError(f"Memory write out of bounds: [{start_byte}, {end_byte}) for size {self.size}")

        # Determine which pixels are affected by the write
        start_pixel_idx = start_byte // 3
        end_pixel_idx = (end_byte - 1) // 3 + 1

        # Get the original bytes covering the affected pixel range
        original_bytes_start = start_pixel_idx * 3
        original_bytes_end = end_pixel_idx * 3
        original_segment_bytes = self._pixels_to_bytes(self._pixels[start_pixel_idx:end_pixel_idx])

        # Create a mutable bytearray to modify
        modified_segment = bytearray(original_segment_bytes)

        # Calculate where to insert the new data within this segment
        offset_in_segment = start_byte - original_bytes_start
        modified_segment[offset_in_segment : offset_in_segment + len(data)] = data

        # Convert the modified segment back to pixels and update _pixels
        updated_pixels_segment = self._bytes_to_pixels(bytes(modified_segment))
        self._pixels[start_pixel_idx:end_pixel_idx] = updated_pixels_segment[:len(updated_pixels_segment)]


    def clear(self) -> None:
        """Clears all data in memory (sets all pixels to black)."""
        self._pixels = [(0, 0, 0)] * self.num_pixels

    def save(self, filename: str = "memory_dump.png") -> None:
        """
        Saves the current memory state to a PNG image.
        The image dimensions will be chosen to be roughly square.
        """
        if not self._pixels:
            raise ValueError("No data to save to image.")

        # Determine suitable image dimensions
        width = int(self.num_pixels**0.5)
        height = (self.num_pixels + width - 1) // width # Ceiling division

        # Pad pixels if necessary to fill the image grid
        padded_pixels = self._pixels + [(0,0,0)] * (width * height - self.num_pixels)

        img = Image.new('RGB', (width, height))
        img.putdata(padded_pixels)
        img.save(filename)
        print(f"Memory saved to {filename}")

    def load(self, filename: str = "memory_dump.png") -> None:
        """
        Loads memory state from a PNG image.
        The loaded data will overwrite current memory content.
        """
        if not os.path.exists(filename):
            raise FileNotFoundError(f"Image file not found: {filename}")

        img = Image.open(filename)
        img = img.convert('RGB')
        loaded_pixels = list(img.getdata())

        if len(loaded_pixels) < self.num_pixels:
            raise ValueError(f"Loaded image contains less data ({len(loaded_pixels)} pixels) than memory size ({self.num_pixels} pixels).")

        self._pixels = loaded_pixels[:self.num_pixels]
        print(f"Memory loaded from {filename}")


# --- PixelDisk Class ---
class PixelDisk:
    def __init__(self, blocks: int = 1024, block_size: int = 512) -> None:
        """
        Initialize the PixelDisk class.

        Args:
            blocks (int): The number of blocks on the disk. Defaults to 1024.
            block_size (int): The size of each block in bytes. Defaults to 512.
        """
        if not isinstance(blocks, int) or blocks <= 0:
            raise ValueError("Number of blocks must be a positive integer.")
        if not isinstance(block_size, int) or block_size <= 0:
            raise ValueError("Block size must be a positive integer.")

        self.blocks = blocks
        self.block_size = block_size
        self.total_size_bytes = blocks * block_size
        self.memory = PixelMemory(size=self.total_size_bytes)
        print(f"PixelDisk initialized with {blocks} blocks, {block_size} bytes/block. Total size: {self.total_size_bytes} bytes.")

    def _validate_block_index(self, index: int) -> None:
        """Helper to validate block index."""
        if not isinstance(index, int):
            raise TypeError("Block index must be an integer.")
        if index < 0 or index >= self.blocks:
            raise IndexError(f"Block index {index} is out of bounds. Valid range: [0, {self.blocks - 1}]")

    def read_block(self, index: int) -> bytes:
        """
        Read a block from the disk.

        Args:
            index (int): The index of the block to read.

        Returns:
            bytes: The data in the block.

        Raises:
            IndexError: If the block index is invalid.
        """
        self._validate_block_index(index)
        start_byte = index * self.block_size
        end_byte = start_byte + self.block_size
        return self.memory.read(start_byte, end_byte)

    def write_block(self, index: int, data: bytes) -> None:
        """
        Write data to a block on the disk.

        Args:
            index (int): The index of the block to write.
            data (bytes): The data to write to the block.

        Raises:
            IndexError: If the block index is invalid.
            ValueError: If the data is not the correct size.
        """
        self._validate_block_index(index)
        if not isinstance(data, bytes):
            raise TypeError("Data must be of type 'bytes'.")
        if len(data) != self.block_size:
            raise ValueError(f"Data length ({len(data)} bytes) must match block size ({self.block_size} bytes).")

        start_byte = index * self.block_size
        self.memory.write(start_byte, data)

    def format_disk(self) -> None:
        """Clears all data from the disk (sets all bytes to zero)."""
        self.memory.clear()
        print("PixelDisk formatted (all data cleared).")

    def save_to_image(self, filename: str = "pixel_disk.png") -> None:
        """
        Save the disk data to an image file.

        Args:
            filename (str): The name of the image file to save to. Defaults to "pixel_disk.png".
        """
        self.memory.save(filename)
        print(f"PixelDisk data saved to image: {filename}")

    def load_from_image(self, filename: str = "pixel_disk.png") -> None:
        """
        Load disk data from an image file.

        Args:
            filename (str): The name of the image file to load from. Defaults to "pixel_disk.png".

        Raises:
            FileNotFoundError: If the image file does not exist.
            ValueError: If the loaded image's content is too small for the disk.
        """
        self.memory.load(filename)
        # Verify that the loaded memory size matches what the disk expects
        if self.memory.size != self.total_size_bytes:
            print(f"Warning: Loaded image had a different underlying memory size ({self.memory.size} bytes) "
                  f"than the disk's configured total size ({self.total_size_bytes} bytes). "
                  f"Disk will operate on the configured size, potentially truncating or padding loaded data.")
        print(f"PixelDisk data loaded from image: {filename}")