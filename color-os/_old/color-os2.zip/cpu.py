from enum import Enum

# --- Define Opcodes using an Enum for clarity ---
class OpCode(Enum):
    HALT = (255, 0, 0)      # Red pixel
    INC_R0 = (0, 255, 0)    # Green pixel
    PRINT_R0 = (0, 0, 255)  # Blue pixel
    # --- New Instructions ---
    DEC_R0 = (255, 255, 0)  # Yellow pixel = Decrement R0
    LOAD_R0 = (0, 255, 255) # Cyan pixel = Load immediate value into R0 (next memory address)


# --- Conceptual PixelMemory class (for demonstration) ---
class PixelMemory:
    def __init__(self, program: list[tuple[int, int, int]]):
        self.program = program

    def read(self, address: int) -> tuple[int, int, int]:
        if 0 <= address < len(self.program):
            return self.program[address]
        else:
            raise IndexError(f"Memory address out of bounds: {address}")

    def write(self, address: int, value: tuple[int, int, int]):
        if 0 <= address < len(self.program):
            self.program[address] = value
        else:
            raise IndexError(f"Memory address out of bounds: {address}")


# --- PixelCPU Class ---
class PixelCPU:
    # Define register constants for better readability
    R0 = 0
    NUM_REGISTERS = 8
    REGISTER_MAX_VALUE = 255 # 8-bit register (0-255)

    def __init__(self, memory: 'PixelMemory') -> None:
        """Initialize the PixelCPU class."""
        self.memory = memory  # Link to PixelMemory object
        self.pc = 0           # Program Counter
        self.registers = [0] * self.NUM_REGISTERS  # 8 general-purpose registers (R0-R7)
        self.running = True   # CPU running flag

        # Map opcodes to their respective execution methods
        self.instruction_set = {
            OpCode.HALT.value: self._execute_halt,
            OpCode.INC_R0.value: self._execute_inc_r0,
            OpCode.PRINT_R0.value: self._execute_print_r0,
            OpCode.DEC_R0.value: self._execute_dec_r0,
            OpCode.LOAD_R0.value: self._execute_load_r0,
        }

    def _execute_halt(self) -> None:
        """Executes the HALT instruction."""
        print("HALT: CPU shutting down.")
        self.running = False

    def _execute_inc_r0(self) -> None:
        """Executes the INC R0 instruction."""
        self.registers[self.R0] = (self.registers[self.R0] + 1) % (self.REGISTER_MAX_VALUE + 1)
        print(f"INC R0: R0 incremented to {self.registers[self.R0]}")

    def _execute_dec_r0(self) -> None:
        """Executes the DEC R0 instruction."""
        # Handle decrement with wrapping (e.g., 0 decrements to 255)
        self.registers[self.R0] = (self.registers[self.R0] - 1) % (self.REGISTER_MAX_VALUE + 1)
        print(f"DEC R0: R0 decremented to {self.registers[self.R0]}")

    def _execute_print_r0(self) -> None:
        """Executes the PRINT R0 instruction."""
        print(f"PRINT R0: Current value of R0 is {self.registers[self.R0]}")

    def _execute_load_r0(self) -> None:
        """Executes the LOAD R0 instruction, loading next memory value into R0."""
        self.pc += 1 # Advance PC to read the operand
        try:
            operand_pixel = self.memory.read(self.pc)
            # For simplicity, let's assume the value is the R component of the pixel
            # You could define a more complex encoding if needed.
            value_to_load = operand_pixel[0]
            if not (0 <= value_to_load <= self.REGISTER_MAX_VALUE):
                print(f"Warning: Value {value_to_load} for LOAD_R0 is out of 0-255 range. Clamping.")
                value_to_load = max(0, min(value_to_load, self.REGISTER_MAX_VALUE))

            self.registers[self.R0] = value_to_load
            print(f"LOAD R0: R0 loaded with value {self.registers[self.R0]} (from {operand_pixel})")
        except IndexError as e:
            print(f"Error: LOAD R0 instruction missing operand at PC {self.pc}. {e}")
            self.running = False # Critical error, halt CPU

    def fetch(self) -> tuple[int, int, int]:
        """Fetch the next opcode from memory."""
        try:
            return self.memory.read(self.pc)
        except IndexError as e:
            print(f"Error: Program Counter out of memory bounds at address {self.pc}. {e}")
            self.running = False # Halt if we try to read past end of memory
            return OpCode.HALT.value # Return HALT to gracefully stop

    def decode_execute(self, opcode: tuple[int, int, int]) -> None:
        """Decode and execute the opcode."""
        try:
            action = self.instruction_set.get(opcode)
            if action:
                action()
            else:
                print(f"Unknown opcode: {opcode}. Skipping.")
        except Exception as e:
            print(f"Error executing opcode {opcode}: {str(e)}")
            self.running = False # Consider halting on execution error

    def step(self) -> None:
        """Execute the next opcode."""
        if not self.running:
            return

        opcode = self.fetch()
        if not self.running: # Check if fetch caused a halt
            return

        # self.pc is incremented AFTER fetch/decode_execute,
        # unless an instruction like LOAD_R0 explicitly increments it.
        # This keeps the PC pointing to the 'current' instruction being processed.
        original_pc = self.pc
        self.decode_execute(opcode)

        if self.pc == original_pc: # Only increment if the instruction didn't change PC
            self.pc += 1

    def run(self, max_cycles: int = 100) -> None:
        """Run the CPU for a maximum number of cycles."""
        print(f"--- Starting CPU run (max {max_cycles} cycles) ---")
        cycle = 0
        try:
            while self.running and cycle < max_cycles:
                print(f"\nCycle {cycle}: PC={self.pc}")
                self.step()
                cycle += 1
            if cycle >= max_cycles and self.running:
                print(f"\n--- CPU halted: Maximum cycles ({max_cycles}) reached. ---")
            else:
                print(f"\n--- CPU halted successfully after {cycle} cycles. ---")
        except Exception as e:
            print(f"\nFatal error during CPU run: {str(e)}")
        print(f"Final R0 value: {self.registers[self.R0]}")