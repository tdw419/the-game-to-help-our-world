from typing import Tuple, NamedTuple, Optional
from dataclasses import dataclass
from enum import Enum


class CursorMovement(Enum):
    """Enumeration of cursor movement types."""
    ADVANCE = "advance"
    MANUAL = "manual"
    BACKSPACE = "backspace"
    NEWLINE = "newline"


@dataclass(frozen=True)
class Position:
    """Immutable position representation."""
    x: int
    y: int
    
    def offset(self, dx: int, dy: int) -> 'Position':
        """Returns a new position offset by dx, dy."""
        return Position(self.x + dx, self.y + dy)
    
    def clamp(self, min_x: int, max_x: int, min_y: int, max_y: int) -> 'Position':
        """Returns a clamped position within bounds."""
        return Position(
            max(min_x, min(self.x, max_x)),
            max(min_y, min(self.y, max_y))
        )


@dataclass(frozen=True)
class CursorMovementResult:
    """Result of a cursor movement operation."""
    new_position: Position
    wrapped_line: bool = False
    scrolled: bool = False
    hit_boundary: bool = False
    lines_scrolled: int = 0


@dataclass(frozen=True)
class CanvasBounds:
    """Canvas boundary definition."""
    left: int
    top: int
    right: int
    bottom: int
    char_width: int
    char_height: int
    
    @property
    def width(self) -> int:
        return self.right - self.left + 1
    
    @property
    def height(self) -> int:
        return self.bottom - self.top + 1
    
    @property
    def max_chars_per_line(self) -> int:
        """Maximum characters that fit on one line."""
        return (self.width) // self.char_width
    
    @property
    def max_lines(self) -> int:
        """Maximum lines that fit in canvas."""
        return (self.height) // self.char_height


class CursorState:
    """
    Manages cursor position and movement logic with support for text wrapping,
    scrolling, and various movement modes.
    """
    
    def __init__(
        self,
        char_width: int,
        char_height: int,
        canvas_bounds: CanvasBounds,
        wrap_enabled: bool = True,
        scroll_enabled: bool = True
    ) -> None:
        """
        Initialize cursor state.
        
        Args:
            char_width: Width of a single character
            char_height: Height of a single character
            canvas_bounds: Canvas boundary definitions
            wrap_enabled: Whether text should wrap to next line
            scroll_enabled: Whether canvas should scroll when cursor moves off-screen
        """
        if char_width <= 0 or char_height <= 0:
            raise ValueError("Character dimensions must be positive")
        
        self._char_width = char_width
        self._char_height = char_height
        self._bounds = canvas_bounds
        self._wrap_enabled = wrap_enabled
        self._scroll_enabled = scroll_enabled
        
        # Starting position (top-left of text area)
        self._start_position = Position(canvas_bounds.left, canvas_bounds.top)
        self._current_position = self._start_position
        
        # Line tracking for wrapping logic
        self._current_line = 0
        self._current_column = 0
    
    @property
    def position(self) -> Position:
        """Current cursor position."""
        return self._current_position
    
    @property
    def x(self) -> int:
        """Current X coordinate."""
        return self._current_position.x
    
    @property
    def y(self) -> int:
        """Current Y coordinate."""
        return self._current_position.y
    
    @property
    def line(self) -> int:
        """Current line number (0-based)."""
        return self._current_line
    
    @property
    def column(self) -> int:
        """Current column number (0-based)."""
        return self._current_column
    
    @property
    def char_dimensions(self) -> Tuple[int, int]:
        """Returns (char_width, char_height)."""
        return self._char_width, self._char_height
    
    @property
    def canvas_bounds(self) -> CanvasBounds:
        """Canvas boundary information."""
        return self._bounds
    
    def set_position(self, x: int, y: int) -> CursorMovementResult:
        """
        Sets cursor to absolute position with validation.
        
        Args:
            x: Target X coordinate
            y: Target Y coordinate
            
        Returns:
            Movement result with new position and any boundary effects
        """
        target = Position(x, y)
        
        # Calculate line and column from absolute position
        line = max(0, (y - self._start_position.y) // self._char_height)
        column = max(0, (x - self._start_position.x) // self._char_width)
        
        # Clamp to valid bounds
        max_x = self._bounds.right - self._char_width
        max_y = self._bounds.bottom - self._char_height
        
        clamped_pos = target.clamp(
            self._bounds.left, max_x,
            self._bounds.top, max_y
        )
        
        hit_boundary = clamped_pos != target
        
        self._current_position = clamped_pos
        self._current_line = line
        self._current_column = column
        
        return CursorMovementResult(
            new_position=clamped_pos,
            hit_boundary=hit_boundary
        )
    
    def advance(self) -> CursorMovementResult:
        """
        Advances cursor to next character position with wrapping and scrolling.
        
        Returns:
            Movement result indicating if wrapping or scrolling occurred
        """
        new_column = self._current_column + 1
        new_x = self._start_position.x + (new_column * self._char_width)
        
        wrapped = False
        scrolled = False
        lines_scrolled = 0
        
        # Check if we need to wrap to next line
        if new_x + self._char_width > self._bounds.right:
            if self._wrap_enabled:
                # Wrap to next line
                new_column = 0
                new_x = self._start_position.x
                new_line = self._current_line + 1
                new_y = self._start_position.y + (new_line * self._char_height)
                wrapped = True
                
                # Check if we need to scroll
                if new_y + self._char_height > self._bounds.bottom:
                    if self._scroll_enabled:
                        scrolled = True
                        lines_scrolled = 1
                        # Keep cursor at same visual position after scroll
                        new_y = self._bounds.bottom - self._char_height
                        new_line = (new_y - self._start_position.y) // self._char_height
                    else:
                        # Clamp to bottom
                        new_y = self._bounds.bottom - self._char_height
                        new_line = (new_y - self._start_position.y) // self._char_height
            else:
                # No wrapping - clamp to end of line
                new_column = self._bounds.max_chars_per_line - 1
                new_x = self._bounds.right - self._char_width
                new_line = self._current_line
                new_y = self._current_position.y
        else:
            new_line = self._current_line
            new_y = self._current_position.y
        
        self._current_position = Position(new_x, new_y)
        self._current_line = new_line
        self._current_column = new_column
        
        return CursorMovementResult(
            new_position=self._current_position,
            wrapped_line=wrapped,
            scrolled=scrolled,
            lines_scrolled=lines_scrolled
        )
    
    def move_by(self, dx: int, dy: int) -> CursorMovementResult:
        """
        Moves cursor by relative offset.
        
        Args:
            dx: X offset in pixels
            dy: Y offset in pixels
            
        Returns:
            Movement result
        """
        target_x = self._current_position.x + dx
        target_y = self._current_position.y + dy
        
        return self.set_position(target_x, target_y)
    
    def move_by_chars(self, char_dx: int, char_dy: int) -> CursorMovementResult:
        """
        Moves cursor by character units.
        
        Args:
            char_dx: Number of characters to move horizontally
            char_dy: Number of lines to move vertically
            
        Returns:
            Movement result
        """
        pixel_dx = char_dx * self._char_width
        pixel_dy = char_dy * self._char_height
        
        return self.move_by(pixel_dx, pixel_dy)
    
    def newline(self) -> CursorMovementResult:
        """
        Moves cursor to beginning of next line.
        
        Returns:
            Movement result
        """
        new_line = self._current_line + 1
        new_y = self._start_position.y + (new_line * self._char_height)
        
        scrolled = False
        lines_scrolled = 0
        
        # Check if we need to scroll
        if new_y + self._char_height > self._bounds.bottom:
            if self._scroll_enabled:
                scrolled = True
                lines_scrolled = 1
                new_y = self._bounds.bottom - self._char_height
                new_line = (new_y - self._start_position.y) // self._char_height
            else:
                new_y = self._bounds.bottom - self._char_height
                new_line = (new_y - self._start_position.y) // self._char_height
        
        self._current_position = Position(self._start_position.x, new_y)
        self._current_line = new_line
        self._current_column = 0
        
        return CursorMovementResult(
            new_position=self._current_position,
            scrolled=scrolled,
            lines_scrolled=lines_scrolled
        )
    
    def backspace(self) -> CursorMovementResult:
        """
        Moves cursor backward one character position.
        
        Returns:
            Movement result
        """
        if self._current_column > 0:
            # Move back one character on same line
            new_column = self._current_column - 1
            new_x = self._start_position.x + (new_column * self._char_width)
            
            self._current_position = Position(new_x, self._current_position.y)
            self._current_column = new_column
            
        elif self._current_line > 0 and self._wrap_enabled:
            # Move to end of previous line
            new_line = self._current_line - 1
            new_y = self._start_position.y + (new_line * self._char_height)
            new_column = self._bounds.max_chars_per_line - 1
            new_x = self._start_position.x + (new_column * self._char_width)
            
            self._current_position = Position(new_x, new_y)
            self._current_line = new_line
            self._current_column = new_column
        
        return CursorMovementResult(new_position=self._current_position)
    
    def home(self) -> CursorMovementResult:
        """Moves cursor to beginning of current line."""
        new_x = self._start_position.x
        self._current_position = Position(new_x, self._current_position.y)
        self._current_column = 0
        
        return CursorMovementResult(new_position=self._current_position)
    
    def end(self) -> CursorMovementResult:
        """Moves cursor to end of current line."""
        new_column = self._bounds.max_chars_per_line - 1
        new_x = self._start_position.x + (new_column * self._char_width)
        
        self._current_position = Position(new_x, self._current_position.y)
        self._current_column = new_column
        
        return CursorMovementResult(new_position=self._current_position)
    
    def reset(self) -> CursorMovementResult:
        """Resets cursor to initial position."""
        self._current_position = self._start_position
        self._current_line = 0
        self._current_column = 0
        
        return CursorMovementResult(new_position=self._current_position)
    
    def is_at_line_start(self) -> bool:
        """Returns True if cursor is at the beginning of a line."""
        return self._current_column == 0
    
    def is_at_line_end(self) -> bool:
        """Returns True if cursor is at the end of a line."""
        return self._current_column >= self._bounds.max_chars_per_line - 1
    
    def is_at_canvas_bottom(self) -> bool:
        """Returns True if cursor is at the bottom of the canvas."""
        return self._current_position.y >= self._bounds.bottom - self._char_height
    
    def get_character_position_at_pixel(self, pixel_x: int, pixel_y: int) -> Tuple[int, int]:
        """
        Converts pixel coordinates to character grid position.
        
        Returns:
            (column, line) tuple
        """
        column = max(0, (pixel_x - self._start_position.x) // self._char_width)
        line = max(0, (pixel_y - self._start_position.y) // self._char_height)
        
        # Clamp to valid ranges
        column = min(column, self._bounds.max_chars_per_line - 1)
        max_line = (self._bounds.height // self._char_height) - 1
        line = min(line, max_line)
        
        return column, line
    
    def get_pixel_position_from_character(self, column: int, line: int) -> Position:
        """
        Converts character grid position to pixel coordinates.
        
        Args:
            column: Character column (0-based)
            line: Line number (0-based)
            
        Returns:
            Pixel position
        """
        x = self._start_position.x + (column * self._char_width)
        y = self._start_position.y + (line * self._char_height)
        
        return Position(x, y)
    
    def configure(
        self,
        wrap_enabled: Optional[bool] = None,
        scroll_enabled: Optional[bool] = None
    ) -> None:
        """
        Updates cursor behavior configuration.
        
        Args:
            wrap_enabled: Enable/disable text wrapping
            scroll_enabled: Enable/disable scrolling
        """
        if wrap_enabled is not None:
            self._wrap_enabled = wrap_enabled
        if scroll_enabled is not None:
            self._scroll_enabled = scroll_enabled
    
    def get_stats(self) -> dict:
        """Returns cursor state statistics."""
        return {
            'position': {'x': self.x, 'y': self.y},
            'character_position': {'column': self._current_column, 'line': self._current_line},
            'canvas_bounds': {
                'left': self._bounds.left, 'top': self._bounds.top,
                'right': self._bounds.right, 'bottom': self._bounds.bottom
            },
            'settings': {
                'wrap_enabled': self._wrap_enabled,
                'scroll_enabled': self._scroll_enabled
            },
            'character_dimensions': {'width': self._char_width, 'height': self._char_height},
            'canvas_capacity': {
                'max_chars_per_line': self._bounds.max_chars_per_line,
                'max_lines': self._bounds.max_lines
            }
        }