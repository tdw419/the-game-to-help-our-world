from typing import Dict, Tuple, List, Optional, Union, Iterator, Any
from dataclasses import dataclass
from enum import Enum
import struct
import json
import logging
from collections import defaultdict


class EncodingMode(Enum):
    """Different encoding modes for storing data as RGB values."""
    SIMPLE_8BIT = "simple_8bit"      # 1 byte per pixel (original method)
    PACKED_24BIT = "packed_24bit"    # 3 bytes per pixel (full RGB utilization)
    COMPRESSED_16BIT = "compressed_16bit"  # 2 bytes per pixel with compression


@dataclass
class MemoryRegion:
    """Represents a contiguous memory region."""
    start_address: int
    size: int
    name: str = ""
    read_only: bool = False
    
    @property
    def end_address(self) -> int:
        return self.start_address + self.size - 1
    
    def contains(self, address: int) -> bool:
        """Check if address is within this region."""
        return self.start_address <= address <= self.end_address


@dataclass
class MemoryStats:
    """Memory usage statistics."""
    total_addresses: int
    used_addresses: int
    memory_efficiency: float
    largest_gap: int
    fragmentation_ratio: float
    regions_count: int


class PixelMemoryError(Exception):
    """Custom exception for pixel memory operations."""
    pass


class PixelMemory:
    """
    Advanced virtual memory system that encodes data as RGB pixel values.
    
    Features:
    - Multiple encoding modes for different efficiency/capacity tradeoffs
    - Memory regions for organization and protection
    - Bulk operations for performance
    - Memory statistics and analysis
    - Data persistence and serialization
    - Comprehensive error handling and validation
    """
    
    def __init__(
        self,
        encoding_mode: EncodingMode = EncodingMode.PACKED_24BIT,
        enable_regions: bool = True,
        validate_rgb: bool = True,
        logger: Optional[logging.Logger] = None
    ) -> None:
        """
        Initialize the PixelMemory system.
        
        Args:
            encoding_mode: How to encode data as RGB values
            enable_regions: Whether to support memory regions
            validate_rgb: Whether to validate RGB values are in valid range
            logger: Optional logger for debugging
        """
        self._encoding_mode = encoding_mode
        self._validate_rgb = validate_rgb
        self._enable_regions = enable_regions
        self._logger = logger or logging.getLogger(__name__)
        
        # Core memory storage: address → RGB tuple
        self._memory_map: Dict[int, Tuple[int, int, int]] = {}
        
        # Memory regions for organization
        self._regions: List[MemoryRegion] = [] if enable_regions else []
        
        # Performance tracking
        self._read_count = 0
        self._write_count = 0
        self._error_count = 0
        
        # Cache for frequently accessed addresses
        self._access_cache: Dict[int, Tuple[int, int, int]] = {}
        self._cache_hits = 0
        self._cache_misses = 0
        
        self._logger.info(f"PixelMemory initialized with {encoding_mode.value} encoding")
    
    @property
    def encoding_mode(self) -> EncodingMode:
        """Current encoding mode."""
        return self._encoding_mode
    
    @property
    def size(self) -> int:
        """Number of allocated memory addresses."""
        return len(self._memory_map)
    
    @property
    def regions(self) -> List[MemoryRegion]:
        """List of defined memory regions."""
        return self._regions.copy()
    
    def create_region(
        self,
        start_address: int,
        size: int,
        name: str = "",
        read_only: bool = False
    ) -> MemoryRegion:
        """
        Create a new memory region.
        
        Args:
            start_address: Starting address of the region
            size: Size of the region in bytes
            name: Optional name for the region
            read_only: Whether the region is read-only
            
        Returns:
            The created memory region
            
        Raises:
            PixelMemoryError: If region overlaps with existing region
        """
        if not self._enable_regions:
            raise PixelMemoryError("Memory regions are disabled")
        
        if size <= 0:
            raise PixelMemoryError("Region size must be positive")
        
        new_region = MemoryRegion(start_address, size, name, read_only)
        
        # Check for overlaps
        for existing in self._regions:
            if (new_region.start_address <= existing.end_address and
                new_region.end_address >= existing.start_address):
                raise PixelMemoryError(
                    f"Region overlaps with existing region '{existing.name}' "
                    f"({existing.start_address}-{existing.end_address})"
                )
        
        self._regions.append(new_region)
        self._regions.sort(key=lambda r: r.start_address)
        
        self._logger.info(f"Created region '{name}' at {start_address}-{new_region.end_address}")
        return new_region
    
    def find_region(self, address: int) -> Optional[MemoryRegion]:
        """Find the memory region containing the given address."""
        if not self._enable_regions:
            return None
        
        for region in self._regions:
            if region.contains(address):
                return region
        return None
    
    def encode_to_rgb(self, data: Union[int, bytes, List[int]]) -> Tuple[int, int, int]:
        """
        Encode data as RGB values based on current encoding mode.
        
        Args:
            data: Data to encode (single byte, bytes object, or list of ints)
            
        Returns:
            RGB tuple representing the encoded data
            
        Raises:
            PixelMemoryError: If data cannot be encoded
        """
        try:
            if self._encoding_mode == EncodingMode.SIMPLE_8BIT:
                return self._encode_simple_8bit(data)
            elif self._encoding_mode == EncodingMode.PACKED_24BIT:
                return self._encode_packed_24bit(data)
            elif self._encoding_mode == EncodingMode.COMPRESSED_16BIT:
                return self._encode_compressed_16bit(data)
            else:
                raise PixelMemoryError(f"Unsupported encoding mode: {self._encoding_mode}")
        except Exception as e:
            self._error_count += 1
            raise PixelMemoryError(f"Encoding failed: {str(e)}") from e
    
    def decode_from_rgb(self, rgb: Tuple[int, int, int]) -> Union[int, List[int]]:
        """
        Decode RGB values back to original data format.
        
        Args:
            rgb: RGB tuple to decode
            
        Returns:
            Decoded data (format depends on encoding mode)
            
        Raises:
            PixelMemoryError: If RGB cannot be decoded
        """
        if self._validate_rgb and not self._is_valid_rgb(rgb):
            raise PixelMemoryError(f"Invalid RGB values: {rgb}")
        
        try:
            if self._encoding_mode == EncodingMode.SIMPLE_8BIT:
                return self._decode_simple_8bit(rgb)
            elif self._encoding_mode == EncodingMode.PACKED_24BIT:
                return self._decode_packed_24bit(rgb)
            elif self._encoding_mode == EncodingMode.COMPRESSED_16BIT:
                return self._decode_compressed_16bit(rgb)
            else:
                raise PixelMemoryError(f"Unsupported encoding mode: {self._encoding_mode}")
        except Exception as e:
            self._error_count += 1
            raise PixelMemoryError(f"Decoding failed: {str(e)}") from e
    
    def write(self, address: int, value: Union[int, bytes, List[int]]) -> None:
        """
        Write data to a virtual memory address.
        
        Args:
            address: Memory address to write to
            value: Data to write
            
        Raises:
            PixelMemoryError: If write operation fails
        """
        if address < 0:
            raise PixelMemoryError(f"Invalid address: {address}")
        
        # Check region permissions
        region = self.find_region(address)
        if region and region.read_only:
            raise PixelMemoryError(f"Cannot write to read-only region '{region.name}'")
        
        try:
            rgb = self.encode_to_rgb(value)
            self._memory_map[address] = rgb
            
            # Update cache
            self._access_cache[address] = rgb
            
            self._write_count += 1
            self._logger.debug(f"Written to address {address}: {rgb}")
            
        except Exception as e:
            self._error_count += 1
            raise PixelMemoryError(f"Write failed at address {address}: {str(e)}") from e
    
    def read(self, address: int, default: Union[int, List[int]] = 0) -> Union[int, List[int]]:
        """
        Read data from a virtual memory address.
        
        Args:
            address: Memory address to read from
            default: Default value if address is not allocated
            
        Returns:
            Data stored at the address
            
        Raises:
            PixelMemoryError: If read operation fails
        """
        if address < 0:
            raise PixelMemoryError(f"Invalid address: {address}")
        
        try:
            # Check cache first
            if address in self._access_cache:
                rgb = self._access_cache[address]
                self._cache_hits += 1
            else:
                rgb = self._memory_map.get(address)
                if rgb is None:
                    return default
                
                self._access_cache[address] = rgb
                self._cache_misses += 1
            
            result = self.decode_from_rgb(rgb)
            self._read_count += 1
            
            return result
            
        except Exception as e:
            self._error_count += 1
            raise PixelMemoryError(f"Read failed at address {address}: {str(e)}") from e
    
    def write_block(self, start_address: int, data: bytes) -> int:
        """
        Write a block of data starting at the given address.
        
        Args:
            start_address: Starting address
            data: Data to write
            
        Returns:
            Number of addresses written
        """
        addresses_written = 0
        
        if self._encoding_mode == EncodingMode.PACKED_24BIT:
            # Write 3 bytes per address for maximum efficiency
            for i in range(0, len(data), 3):
                chunk = data[i:i+3]
                if len(chunk) < 3:
                    chunk += b'\x00' * (3 - len(chunk))  # Pad with zeros
                
                self.write(start_address + i // 3, list(chunk))
                addresses_written += 1
        else:
            # Write 1 byte per address
            for i, byte_val in enumerate(data):
                self.write(start_address + i, byte_val)
                addresses_written += 1
        
        return addresses_written
    
    def read_block(self, start_address: int, length: int) -> bytes:
        """
        Read a block of data starting at the given address.
        
        Args:
            start_address: Starting address
            length: Number of bytes to read
            
        Returns:
            Block of data as bytes
        """
        result = bytearray()
        
        if self._encoding_mode == EncodingMode.PACKED_24BIT:
            # Read 3 bytes per address
            addresses_needed = (length + 2) // 3
            for i in range(addresses_needed):
                data = self.read(start_address + i, [0, 0, 0])
                if isinstance(data, list):
                    result.extend(data)
                else:
                    result.append(data)
        else:
            # Read 1 byte per address
            for i in range(length):
                byte_val = self.read(start_address + i, 0)
                if isinstance(byte_val, list):
                    result.extend(byte_val)
                else:
                    result.append(byte_val)
        
        return bytes(result[:length])  # Trim to exact length
    
    def clear(self, start_address: Optional[int] = None, end_address: Optional[int] = None) -> int:
        """
        Clear memory addresses in the specified range.
        
        Args:
            start_address: Starting address (None for beginning)
            end_address: Ending address (None for end)
            
        Returns:
            Number of addresses cleared
        """
        if start_address is None and end_address is None:
            # Clear all memory
            count = len(self._memory_map)
            self._memory_map.clear()
            self._access_cache.clear()
            return count
        
        addresses_to_remove = []
        for addr in self._memory_map:
            if ((start_address is None or addr >= start_address) and
                (end_address is None or addr <= end_address)):
                addresses_to_remove.append(addr)
        
        for addr in addresses_to_remove:
            del self._memory_map[addr]
            self._access_cache.pop(addr, None)
        
        return len(addresses_to_remove)
    
    def get_allocated_addresses(self) -> List[int]:
        """Get list of all allocated memory addresses."""
        return sorted(self._memory_map.keys())
    
    def get_memory_gaps(self) -> List[Tuple[int, int]]:
        """
        Find gaps in allocated memory.
        
        Returns:
            List of (start, end) tuples representing memory gaps
        """
        addresses = self.get_allocated_addresses()
        if not addresses:
            return []
        
        gaps = []
        for i in range(len(addresses) - 1):
            if addresses[i + 1] - addresses[i] > 1:
                gaps.append((addresses[i] + 1, addresses[i + 1] - 1))
        
        return gaps
    
    def get_stats(self) -> MemoryStats:
        """Get comprehensive memory usage statistics."""
        if not self._memory_map:
            return MemoryStats(0, 0, 0.0, 0, 0.0, len(self._regions))
        
        addresses = self.get_allocated_addresses()
        total_span = addresses[-1] - addresses[0] + 1
        used_count = len(addresses)
        efficiency = (used_count / total_span) * 100 if total_span > 0 else 0
        
        gaps = self.get_memory_gaps()
        largest_gap = max((end - start + 1 for start, end in gaps), default=0)
        fragmentation = (len(gaps) / used_count) * 100 if used_count > 0 else 0
        
        return MemoryStats(
            total_addresses=total_span,
            used_addresses=used_count,
            memory_efficiency=efficiency,
            largest_gap=largest_gap,
            fragmentation_ratio=fragmentation,
            regions_count=len(self._regions)
        )
    
    def export_to_dict(self, include_metadata: bool = True) -> Dict[str, Any]:
        """
        Export memory contents to a dictionary.
        
        Args:
            include_metadata: Whether to include statistics and metadata
            
        Returns:
            Dictionary representation of memory contents
        """
        result = {
            'memory_map': {str(addr): rgb for addr, rgb in self._memory_map.items()},
            'encoding_mode': self._encoding_mode.value
        }
        
        if include_metadata:
            result.update({
                'stats': self.get_stats().__dict__,
                'performance': {
                    'reads': self._read_count,
                    'writes': self._write_count,
                    'errors': self._error_count,
                    'cache_hits': self._cache_hits,
                    'cache_misses': self._cache_misses
                },
                'regions': [
                    {
                        'start': r.start_address,
                        'size': r.size,
                        'name': r.name,
                        'read_only': r.read_only
                    }
                    for r in self._regions
                ]
            })
        
        return result
    
    def import_from_dict(self, data: Dict[str, Any], clear_existing: bool = True) -> None:
        """
        Import memory contents from a dictionary.
        
        Args:
            data: Dictionary containing memory data
            clear_existing: Whether to clear existing memory first
        """
        if clear_existing:
            self.clear()
            self._regions.clear()
        
        # Import memory map
        memory_map = data.get('memory_map', {})
        for addr_str, rgb in memory_map.items():
            try:
                addr = int(addr_str)
                if self._validate_rgb and not self._is_valid_rgb(rgb):
                    self._logger.warning(f"Skipping invalid RGB at address {addr}: {rgb}")
                    continue
                self._memory_map[addr] = tuple(rgb)
            except (ValueError, TypeError) as e:
                self._logger.warning(f"Skipping invalid address {addr_str}: {e}")
        
        # Import regions if available
        if 'regions' in data and self._enable_regions:
            for region_data in data['regions']:
                try:
                    self.create_region(
                        region_data['start'],
                        region_data['size'],
                        region_data.get('name', ''),
                        region_data.get('read_only', False)
                    )
                except Exception as e:
                    self._logger.warning(f"Failed to import region: {e}")
    
    def _encode_simple_8bit(self, data: Union[int, bytes, List[int]]) -> Tuple[int, int, int]:
        """Encode single byte using original 8-bit method."""
        if isinstance(data, (bytes, list)):
            byte_val = data[0] if data else 0
        else:
            byte_val = data
        
        byte_val = max(0, min(255, int(byte_val)))  # Clamp to byte range
        
        # More efficient bit distribution
        r = (byte_val >> 5) & 0x7   # 3 bits
        g = (byte_val >> 2) & 0x7   # 3 bits  
        b = byte_val & 0x3          # 2 bits
        
        return (r << 5, g << 5, b << 6)
    
    def _decode_simple_8bit(self, rgb: Tuple[int, int, int]) -> int:
        """Decode RGB back to single byte."""
        r, g, b = rgb
        return ((r >> 5) << 5) | ((g >> 5) << 2) | (b >> 6)
    
    def _encode_packed_24bit(self, data: Union[int, bytes, List[int]]) -> Tuple[int, int, int]:
        """Encode up to 3 bytes as full RGB values."""
        if isinstance(data, int):
            data = [data]
        elif isinstance(data, bytes):
            data = list(data)
        
        # Pad or truncate to exactly 3 bytes
        padded_data = (list(data) + [0, 0, 0])[:3]
        return tuple(max(0, min(255, val)) for val in padded_data)
    
    def _decode_packed_24bit(self, rgb: Tuple[int, int, int]) -> List[int]:
        """Decode RGB back to list of up to 3 bytes."""
        return list(rgb)
    
    def _encode_compressed_16bit(self, data: Union[int, bytes, List[int]]) -> Tuple[int, int, int]:
        """Encode 2 bytes with simple compression."""
        if isinstance(data, int):
            data = [data]
        elif isinstance(data, bytes):
            data = list(data)
        
        # Take up to 2 bytes
        bytes_data = (list(data) + [0, 0])[:2]
        
        # Simple compression: use blue channel for metadata
        r, g = bytes_data[0], bytes_data[1]
        b = len([x for x in bytes_data if x != 0])  # Count non-zero bytes
        
        return (r, g, b)
    
    def _decode_compressed_16bit(self, rgb: Tuple[int, int, int]) -> List[int]:
        """Decode compressed 2-byte format."""
        r, g, b = rgb
        result = [r, g]
        
        # Use metadata in blue channel to determine actual length
        if b == 1:
            result = [r] if r != 0 else [g]
        elif b == 0:
            result = []
        
        return result
    
    def _is_valid_rgb(self, rgb: Tuple[int, int, int]) -> bool:
        """Validate RGB values are in valid range."""
        return (len(rgb) == 3 and 
                all(isinstance(val, int) and 0 <= val <= 255 for val in rgb))
    
    def __len__(self) -> int:
        """Return number of allocated addresses."""
        return len(self._memory_map)
    
    def __contains__(self, address: int) -> bool:
        """Check if address is allocated."""
        return address in self._memory_map
    
    def __iter__(self) -> Iterator[int]:
        """Iterate over allocated addresses."""
        return iter(sorted(self._memory_map.keys()))
    
    def __getitem__(self, address: int) -> Union[int, List[int]]:
        """Allow dictionary-style access for reading."""
        return self.read(address)
    
    def __setitem__(self, address: int, value: Union[int, bytes, List[int]]) -> None:
        """Allow dictionary-style access for writing."""
        self.write(address, value)