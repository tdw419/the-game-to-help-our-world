import os

BASE = "./vault"
folders = [
    "incoming_batches",
    "processed_batches",
    "image_fragments",
    "logs",
    "scripts",
    "user_commands"
]

print("🛠️ Bootstrapping Vault structure...")
for folder in folders:
    path = os.path.join(BASE, folder)
    os.makedirs(path, exist_ok=True)
    print(f"✅ Created: {path}")

print("✅ Vault directory structure is ready.")
