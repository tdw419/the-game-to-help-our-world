import os

folders = [
    "vault/incoming_batches",
    "vault/processed_batches",
    "vault/image_fragments",
    "vault/logs",
    "vault/scripts",
    "vault/user_commands"
]

for folder in folders:
    os.makedirs(folder, exist_ok=True)

print("✅ Vault structure initialized.")
