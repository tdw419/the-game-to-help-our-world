import os
import tarfile
import time
import shutil

WATCH_DIR = "vault/incoming_batches"
PROCESSED_DIR = "vault/processed_batches"
EXTRACT_DIR = "vault/temp_extract"

os.makedirs(EXTRACT_DIR, exist_ok=True)

print("👁️ Watching for incoming batches...")

def process_batch(filepath):
    print(f"📦 Processing: {filepath}")
    with tarfile.open(filepath, "r:gz") as tar:
        tar.extractall(EXTRACT_DIR)

    # Check and run auto_sync if it exists
    auto_sync_path = os.path.join(EXTRACT_DIR, "auto_sync.py")
    if os.path.exists(auto_sync_path):
        exec(open(auto_sync_path).read(), {"__name__": "__main__"})

    # Move the processed file
    shutil.move(filepath, os.path.join(PROCESSED_DIR, os.path.basename(filepath)))
    shutil.rmtree(EXTRACT_DIR)
    os.makedirs(EXTRACT_DIR)

while True:
    for filename in os.listdir(WATCH_DIR):
        if filename.endswith(".tar.gz"):
            full_path = os.path.join(WATCH_DIR, filename)
            process_batch(full_path)
    time.sleep(5)
