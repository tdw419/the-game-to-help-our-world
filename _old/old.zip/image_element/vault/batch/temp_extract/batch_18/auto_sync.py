import os

print("Running Batch 18 auto_sync...")

# Run the pixel debugger with breakpoints
exec(open("batch_18/pixel_breakpoint_debugger.py").read(), {"__name__": "__main__"})

# Log the batch processing
with open("vault/logs/auto_sync_log.txt", "a") as log_file:
    log_file.write("Batch 18 executed: visual debugger with breakpoints and overlays.\n")

print("Batch 18 auto_sync complete.")
