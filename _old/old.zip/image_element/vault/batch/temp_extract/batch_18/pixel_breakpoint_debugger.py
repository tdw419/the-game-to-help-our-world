from PIL import Image, ImageDraw, ImageFont
import os
import json

image_path = "vault/image_fragments/generated_script.png"
map_path = "vault/logs/instruction_to_rgb.json"
debug_log = "vault/logs/debug_trace_with_breakpoints.txt"
frames_dir = "vault/debug_frames/"

breakpoints = ["MATH.ADD", "PRINT"]  # Pause if these instructions are found

os.makedirs(frames_dir, exist_ok=True)

def rgb_to_instruction(rgb, reverse_map):
    return reverse_map.get(f"{rgb[0]},{rgb[1]},{rgb[2]}", "NOOP")

def pixel_debug_with_breakpoints():
    if not os.path.exists(image_path) or not os.path.exists(map_path):
        print("Required files missing.")
        return

    with open(map_path, "r") as f:
        rgb_map = json.load(f)
        reverse_map = {v: k for k, v in rgb_map.items()}
        reverse_map = {k: v for v, k in reverse_map.items()}  # string to instruction

    with Image.open(image_path) as img:
        img = img.convert("RGB")
        pixels = list(img.getdata())
        w, h = img.size

    stack = []

    with open(debug_log, "a") as log:
        log.write("=== Debug Trace with Breakpoints Start ===\n")

        for i, pixel in enumerate(pixels):
            instr = rgb_to_instruction(pixel, reverse_map)
            log.write(f"Step {i} | Pixel: {pixel} -> {instr}\n")

            # Execute
            if instr == "PUSH 1":
                stack.append(1)
            elif instr == "PUSH 0":
                stack.append(0)
            elif instr == "MATH.ADD" and len(stack) >= 2:
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif instr == "PRINT":
                val = stack[-1] if stack else None
                log.write(f"PRINT: {val}\n")
            elif instr == "END":
                break

            log.write(f"STACK: {stack}\n")

            # Create debug frame
            frame = img.copy()
            draw = ImageDraw.Draw(frame)
            draw.rectangle([i, 0, i, 0], outline="red")  # mark current pixel
            frame.save(os.path.join(frames_dir, f"step_{i:03}.png"))

            if instr in breakpoints:
                log.write(f"BREAKPOINT hit: {instr} at step {i}\n")
                break

        log.write("=== Debug Trace End ===\n\n")

pixel_debug_with_breakpoints()
