from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 320, 200
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_popup/"
final_output = "vault/gui_tray_popup.png"
os.makedirs(frame_dir, exist_ok=True)

def draw_system_tray(draw):
    icons = [("📶", 260), ("🔊", 280), ("🔋", 300)]
    for icon, x in icons:
        draw.text((x, 180), icon, font=font, fill=(255, 255, 255))

def draw_battery_popup(draw):
    popup_x, popup_y = 240, 120
    popup_w, popup_h = 75, 55
    draw.rectangle([popup_x, popup_y, popup_x + popup_w, popup_y + popup_h], fill=(20, 20, 20), outline=(0, 255, 0))
    draw.text((popup_x + 5, popup_y + 3), "🔋 82%", font=font, fill=(0, 255, 0))
    draw.text((popup_x + 5, popup_y + 16), "Mode: Balanced", font=font, fill=(180, 255, 180))
    draw.rectangle([popup_x + 5, popup_y + 33, popup_x + 65, popup_y + 38], fill=(60, 60, 60), outline=(100, 255, 100))
    draw.rectangle([popup_x + 5, popup_y + 33, popup_x + 45, popup_y + 38], fill=(0, 255, 0))  # brightness bar

def run_tray_popup_simulation():
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.text((10, 10), "Desktop - Tray Popup", font=font, fill=(200, 200, 200))
    draw_system_tray(draw)
    draw_battery_popup(draw)
    img.save(f"{frame_dir}/frame_000.png")
    img.save(final_output)

run_tray_popup_simulation()
