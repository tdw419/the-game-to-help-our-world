from PIL import Image
import os

fragment_path = "vault/image_fragments/fragment_01.png"

INSTRUCTION_SET = {
    (0, 0, 1): "LOAD",
    (0, 0, 2): "STORE",
    (0, 0, 3): "JUMP",
    (0, 0, 4): "PUSH 1",
    (0, 0, 5): "PUSH 0",
    (0, 0, 6): "POP",
    (0, 0, 7): "JUMP_IF_ZERO",
    (255, 0, 255): "END"
}

def run_pixel_stack_vm(image_path):
    stack = []
    try:
        with Image.open(image_path) as img:
            img = img.convert("RGB")
            pixels = list(img.getdata())
            with open("vault/logs/stack_trace.txt", "a") as log:
                log.write("=== Stack VM Start ===\n")
                for i, pixel in enumerate(pixels[:10]):
                    instruction = INSTRUCTION_SET.get(pixel, "NOOP")
                    log.write(f"Pixel {i}: {pixel} -> {instruction}\n")

                    if instruction == "PUSH 1":
                        stack.append(1)
                    elif instruction == "PUSH 0":
                        stack.append(0)
                    elif instruction == "POP":
                        if stack:
                            stack.pop()
                    elif instruction == "JUMP_IF_ZERO":
                        if stack and stack[-1] == 0:
                            log.write("JUMP_IF_ZERO triggered\n")
                    elif instruction == "END":
                        break

                    log.write(f"STACK: {stack}\n")
                log.write("=== Stack VM End ===\n\n")
    except Exception as e:
        print("Error in Pixel Stack VM:", e)

if os.path.exists(fragment_path):
    run_pixel_stack_vm(fragment_path)
else:
    print("Fragment not found.")
