import os

print("Running Batch 8 auto_sync...")

# Run the pixel stack VM
exec(open("batch_8/pixel_stack_vm.py").read(), {"__name__": "__main__"})

# Log the batch processing
with open("vault/logs/auto_sync_log.txt", "a") as log_file:
    log_file.write("Batch 8 executed: pixel stack VM ran with interpreted instructions.\n")

print("Batch 8 auto_sync complete.")
