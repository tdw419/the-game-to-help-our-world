import os

print("Running Batch 6 auto_sync...")

# Run the pixel decoder
exec(open("batch_6/pixel_decoder.py").read(), {"__name__": "__main__"})

# Log the batch processing
with open("vault/logs/auto_sync_log.txt", "a") as log_file:
    log_file.write("Batch 6 executed: decoded RGB values into binary instructions.\n")

print("Batch 6 auto_sync complete.")
