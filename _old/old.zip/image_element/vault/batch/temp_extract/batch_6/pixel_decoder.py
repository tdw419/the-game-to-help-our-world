from PIL import Image
import os

fragment_path = "vault/image_fragments/fragment_01.png"

def rgb_to_binary(r, g, b):
    return f"{r:08b} {g:08b} {b:08b}"

def interpret_pixel_instructions(image_path):
    try:
        with Image.open(image_path) as img:
            img = img.convert("RGB")
            pixels = list(img.getdata())
            with open("vault/logs/instruction_log.txt", "a") as log:
                for i, (r, g, b) in enumerate(pixels[:10]):
                    binary = rgb_to_binary(r, g, b)
                    log.write(f"Pixel {i}: {binary}\n")
                    print(f"Pixel {i}: {binary}")
    except Exception as e:
        print("Error decoding pixels:", e)

if os.path.exists(fragment_path):
    interpret_pixel_instructions(fragment_path)
else:
    print("Fragment not found.")
