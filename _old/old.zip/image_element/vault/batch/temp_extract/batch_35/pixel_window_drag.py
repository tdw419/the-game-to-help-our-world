from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 320, 200
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_drag/"
final_output = "vault/gui_terminal_dragged.png"
os.makedirs(frame_dir, exist_ok=True)

# Simulated window drag path (3 positions)
drag_positions = [(40, 40), (60, 30), (90, 20)]

def draw_terminal_window(draw, x0, y0):
    x1, y1 = x0 + 220, y0 + 110
    draw.rectangle([x0, y0, x1, y1], fill=(0, 0, 0), outline=(0, 255, 0))
    draw.rectangle([x0, y0, x1, y0 + 15], fill=(40, 40, 40), outline=(0, 255, 0))
    draw.text((x0 + 5, y0 + 2), "Terminal", font=font, fill=(0, 255, 0))
    draw.rectangle([x1 - 15, y0, x1, y0 + 15], fill=(100, 0, 0))
    draw.text((x1 - 12, y0 + 1), "X", font=font, fill=(255, 255, 255))
    lines = ["$ whoami", "SysAdmin", "$ uptime", "up 2 days"]
    for i, line in enumerate(lines):
        draw.text((x0 + 5, y0 + 20 + i * 12), line, font=font, fill=(0, 255, 0))

def draw_taskbar(draw):
    draw.rectangle([0, screen_h - 20, screen_w, screen_h], fill=(20, 20, 20))
    draw.rectangle([10, screen_h - 18, 60, screen_h - 2], outline=(0, 255, 0))
    draw.text((15, screen_h - 16), "Terminal", font=font, fill=(0, 255, 0))

def run_window_drag_simulation():
    for i, (x, y) in enumerate(drag_positions):
        img = Image.new("RGB", (screen_w, screen_h), (10, 10, 10))
        draw = ImageDraw.Draw(img)
        draw_terminal_window(draw, x, y)
        draw_taskbar(draw)
        img.save(f"{frame_dir}/frame_{i:03}.png")
    # Save final position
    img.save(final_output)

run_window_drag_simulation()
