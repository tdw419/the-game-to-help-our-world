from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 240, 140
font = ImageFont.load_default()

users = [
    {"name": "User1", "avatar": (255, 100, 100), "rect": (20, 30, 100, 90)},
    {"name": "Admin", "avatar": (100, 255, 100), "rect": (130, 30, 210, 90)}
]

click_pos = (150, 60)  # Simulated click on Admin
frame_dir = "vault/debug_frames_accounts/"
final_output = "vault/gui_account_select.png"

os.makedirs(frame_dir, exist_ok=True)

def run_account_select():
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    selected_user = None

    for user in users:
        x0, y0, x1, y1 = user["rect"]
        if x0 <= click_pos[0] <= x1 and y0 <= click_pos[1] <= y1:
            selected_user = user["name"]

    for user in users:
        x0, y0, x1, y1 = user["rect"]
        color = user["avatar"]
        border = (255, 255, 255) if user["name"] == selected_user else (100, 100, 100)
        draw.rectangle([x0, y0, x1, y1], fill=color, outline=border)
        draw.text((x0 + 5, y1 + 2), user["name"], font=font, fill=(255, 255, 255))

    draw.ellipse([click_pos[0] - 3, click_pos[1] - 3, click_pos[0] + 3, click_pos[1] + 3], fill=(255, 0, 0))
    img.save(final_output)

    # Save frame
    img.save(f"{frame_dir}/frame_000.png")

run_account_select()
