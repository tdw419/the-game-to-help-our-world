from PIL import Image
import os

fragment_path = "vault/image_fragments/fragment_01.png"

INSTRUCTION_SET = {
    (0, 0, 4): "PUSH 1",
    (0, 0, 5): "PUSH 0",
    (0, 0, 6): "POP",
    (0, 0, 11): "WRITE",
    (0, 0, 12): "READ",
    (0, 0, 13): "INC",
    (0, 0, 14): "DEC",
    (0, 0, 15): "SET_ZERO_FLAG",
    (0, 0, 16): "JUMP_IF_ZERO",
    (0, 0, 17): "LABEL",
    (255, 0, 255): "END"
}

def run_pixel_control_vm(image_path):
    stack = []
    memory = {}
    pointer = 0
    zero_flag = False
    label_positions = {}
    pixel_pointer = 0
    program = []

    try:
        with Image.open(image_path) as img:
            img = img.convert("RGB")
            program = list(img.getdata())

        # First pass to collect labels
        for i, pixel in enumerate(program):
            if INSTRUCTION_SET.get(pixel) == "LABEL":
                label_positions["label"] = i  # simple label for demo

        # Execute with flow control
        with open("vault/logs/flow_trace.txt", "a") as log:
            log.write("=== Flow VM Start ===\n")
            while pixel_pointer < len(program):
                pixel = program[pixel_pointer]
                instruction = INSTRUCTION_SET.get(pixel, "NOOP")
                log.write(f"Pixel {pixel_pointer}: {pixel} -> {instruction}\n")

                if instruction == "PUSH 1":
                    stack.append(1)
                elif instruction == "PUSH 0":
                    stack.append(0)
                elif instruction == "POP":
                    if stack:
                        stack.pop()
                elif instruction == "WRITE":
                    if stack:
                        memory[pointer] = stack[-1]
                elif instruction == "READ":
                    value = memory.get(pointer, 0)
                    stack.append(value)
                elif instruction == "INC":
                    pointer += 1
                elif instruction == "DEC":
                    pointer = max(0, pointer - 1)
                elif instruction == "SET_ZERO_FLAG":
                    zero_flag = (stack[-1] == 0 if stack else True)
                elif instruction == "JUMP_IF_ZERO":
                    if zero_flag and "label" in label_positions:
                        pixel_pointer = label_positions["label"]
                        continue  # Jumped, skip pointer increment
                elif instruction == "END":
                    break

                log.write(f"STACK: {stack}, MEMORY: {memory}, POINTER: {pointer}, ZERO_FLAG: {zero_flag}\n")
                pixel_pointer += 1
            log.write("=== Flow VM End ===\n\n")
    except Exception as e:
        print("Error in Pixel Flow VM:", e)

if os.path.exists(fragment_path):
    run_pixel_control_vm(fragment_path)
else:
    print("Fragment not found.")
