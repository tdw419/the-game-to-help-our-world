from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 300, 180
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_dashboard/"
final_output = "vault/gui_dashboard.png"
os.makedirs(frame_dir, exist_ok=True)

user_profile = {
    "name": "SysAdmin",
    "role": "Administrator",
    "avatar_color": (100, 100, 255)
}

notifications = ["2 new messages", "System update available"]
activity_log = ["Logged in @ 08:43", "Edited profile", "Uploaded avatar"]

def draw_dashboard(draw):
    # Background
    draw.rectangle([0, 0, screen_w, screen_h], fill=(10, 10, 10))

    # Profile panel
    draw.text((10, 10), "Welcome,", font=font, fill=(200, 200, 200))
    draw.text((10, 25), user_profile["name"], font=font, fill=(0, 255, 0))
    draw.rectangle([200, 10, 240, 50], fill=user_profile["avatar_color"], outline=(255, 255, 255))
    draw.text((10, 45), f"Role: {user_profile['role']}", font=font, fill=(180, 180, 180))

    # Notification panel
    draw.rectangle([10, 70, 290, 100], outline=(255, 255, 0))
    draw.text((15, 72), "🔔 Notifications:", font=font, fill=(255, 255, 0))
    for i, note in enumerate(notifications):
        draw.text((20, 86 + i * 10), f"- {note}", font=font, fill=(255, 255, 255))

    # Activity log
    draw.rectangle([10, 115, 290, 170], outline=(0, 255, 255))
    draw.text((15, 117), "📋 Recent Activity:", font=font, fill=(0, 255, 255))
    for i, log in enumerate(activity_log[:3]):
        draw.text((20, 131 + i * 10), f"- {log}", font=font, fill=(200, 200, 200))

def run_dashboard():
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_dashboard(draw)
    img.save(f"{frame_dir}/frame_000.png")
    img.save(final_output)

run_dashboard()
