from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os

screen_w, screen_h = 320, 200
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_close/"
final_output = "vault/gui_task_switcher_close.png"
os.makedirs(frame_dir, exist_ok=True)

apps = [
    {"label": "Terminal", "rect": (50, 70, 110, 130), "active": True},
    {"label": "Settings", "rect": (210, 70, 270, 130), "active": False}
]

def draw_task_switch_overlay(draw):
    # Background blur (simulate by dim rectangle)
    draw.rectangle([0, 0, screen_w, screen_h], fill=(0, 0, 0, 180))

    # App thumbnails
    for app in apps:
        x0, y0, x1, y1 = app["rect"]
        fill = (0, 60, 0) if app["active"] else (40, 40, 40)
        outline = (0, 255, 0) if app["active"] else (120, 120, 120)
        draw.rectangle([x0, y0, x1, y1], fill=fill, outline=outline)

        # Title
        draw.text((x0 + 5, y1 + 5), app["label"], font=font, fill=(255, 255, 255))

        # Close button
        draw.rectangle([x1 - 12, y0, x1, y0 + 12], fill=(100, 0, 0))
        draw.text((x1 - 10, y0 + 1), "X", font=font, fill=(255, 255, 255))

def run_switcher_close_simulation():
    img = Image.new("RGB", (screen_w, screen_h), (20, 20, 20))
    draw = ImageDraw.Draw(img)
    draw_task_switch_overlay(draw)
    img.save(f"{frame_dir}/frame_000.png")
    img.save(final_output)

run_switcher_close_simulation()
