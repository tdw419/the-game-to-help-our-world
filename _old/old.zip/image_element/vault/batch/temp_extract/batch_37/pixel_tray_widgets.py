from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 320, 200
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_tray/"
final_output = "vault/gui_tray_widgets.png"
os.makedirs(frame_dir, exist_ok=True)

tray_icons = [
    {"label": "Wi-Fi", "icon": "📶", "pos": (260, 180), "selected": False},
    {"label": "Volume", "icon": "🔊", "pos": (280, 180), "selected": False},
    {"label": "Battery", "icon": "🔋", "pos": (300, 180), "selected": True}
]

widget_click_zone = (160, 30, 315, 120)  # Simulated clickable notes widget

def draw_widget_panel(draw):
    x0 = 160
    draw.rectangle([x0, 0, screen_w, screen_h - 20], fill=(30, 30, 30), outline=(100, 100, 100))
    draw.rectangle([x0, 0, screen_w, 15], fill=(60, 60, 60))
    draw.text((x0 + 5, 2), "Notes (clickable)", font=font, fill=(255, 255, 0))

    notes = [
        "- Batch 37 in progress",
        "- Add interactivity",
        "- Push to tray UI"
    ]
    for i, note in enumerate(notes):
        draw.text((x0 + 5, 20 + i * 12), note, font=font, fill=(255, 255, 255))

    # Click zone highlight
    draw.rectangle(widget_click_zone, outline=(0, 255, 255))

def draw_system_tray(draw):
    for icon in tray_icons:
        x, y = icon["pos"]
        color = (0, 255, 0) if icon["selected"] else (180, 180, 180)
        draw.text((x, y), icon["icon"], font=font, fill=color)

def run_tray_widget_simulation():
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_widget_panel(draw)
    draw_system_tray(draw)
    img.save(f"{frame_dir}/frame_000.png")
    img.save(final_output)

run_tray_widget_simulation()
