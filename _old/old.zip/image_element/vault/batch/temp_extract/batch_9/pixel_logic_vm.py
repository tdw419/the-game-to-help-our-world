from PIL import Image
import os

fragment_path = "vault/image_fragments/fragment_01.png"

INSTRUCTION_SET = {
    (0, 0, 4): "PUSH 1",
    (0, 0, 5): "PUSH 0",
    (0, 0, 6): "POP",
    (0, 0, 8): "AND",
    (0, 0, 9): "OR",
    (0, 0, 10): "NOT",
    (255, 0, 255): "END"
}

def run_pixel_logic_vm(image_path):
    stack = []
    try:
        with Image.open(image_path) as img:
            img = img.convert("RGB")
            pixels = list(img.getdata())
            with open("vault/logs/logic_trace.txt", "a") as log:
                log.write("=== Logic VM Start ===\n")
                for i, pixel in enumerate(pixels[:10]):
                    instruction = INSTRUCTION_SET.get(pixel, "NOOP")
                    log.write(f"Pixel {i}: {pixel} -> {instruction}\n")

                    if instruction == "PUSH 1":
                        stack.append(1)
                    elif instruction == "PUSH 0":
                        stack.append(0)
                    elif instruction == "POP":
                        if stack:
                            stack.pop()
                    elif instruction == "AND":
                        if len(stack) >= 2:
                            a = stack.pop()
                            b = stack.pop()
                            stack.append(a & b)
                    elif instruction == "OR":
                        if len(stack) >= 2:
                            a = stack.pop()
                            b = stack.pop()
                            stack.append(a | b)
                    elif instruction == "NOT":
                        if stack:
                            a = stack.pop()
                            stack.append(0 if a else 1)
                    elif instruction == "END":
                        break

                    log.write(f"STACK: {stack}\n")
                log.write("=== Logic VM End ===\n\n")
    except Exception as e:
        print("Error in Pixel Logic VM:", e)

if os.path.exists(fragment_path):
    run_pixel_logic_vm(fragment_path)
else:
    print("Fragment not found.")
