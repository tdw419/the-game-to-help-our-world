from PIL import Image
import os

# Output screen settings
screen_width, screen_height = 8, 8
screen_path = "vault/virtual_screen.png"
screen_color = (0, 0, 0)  # black background
draw_color = (0, 255, 0)  # green pixel

# Simulated input pixel instructions
instructions = [
    (10, 0, 1),  # CLEAR_SCREEN
    (10, 0, 0),  # DRAW_PIXEL
    (10, 0, 0),
    (10, 0, 0),
    (10, 0, 2)   # SHOW_SCREEN
]

def run_pixel_display_vm():
    img = Image.new("RGB", (screen_width, screen_height), screen_color)
    draw_x, draw_y = 0, 0

    for i, instr in enumerate(instructions):
        if instr == (10, 0, 1):  # CLEAR_SCREEN
            img = Image.new("RGB", (screen_width, screen_height), screen_color)
            draw_x, draw_y = 0, 0
        elif instr == (10, 0, 0):  # DRAW_PIXEL
            img.putpixel((draw_x, draw_y), draw_color)
            draw_x = (draw_x + 1) % screen_width
            if draw_x == 0:
                draw_y = (draw_y + 1) % screen_height
        elif instr == (10, 0, 2):  # SHOW_SCREEN
            img.save(screen_path)
            print(f"🖥️ Screen rendered to {screen_path}")

run_pixel_display_vm()
