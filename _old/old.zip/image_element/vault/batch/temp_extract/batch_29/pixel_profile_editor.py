from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 260, 160
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_profile_edit/"
final_output = "vault/gui_profile_editor.png"
os.makedirs(frame_dir, exist_ok=True)

# Simulated color picker and update action
available_colors = [(255, 100, 100), (100, 255, 100), (100, 100, 255), (255, 255, 0)]
selected_color_index = 2  # Simulate click on blue
updated_name = "SysAdmin"

def draw_editor(draw, selected_index, name):
    draw.rectangle([0, 0, screen_w, screen_h], fill=(0, 0, 0))
    draw.text((10, 10), "Edit Profile", font=font, fill=(255, 255, 255))

    # Name field
    draw.text((10, 30), "Display Name:", font=font, fill=(255, 255, 255))
    draw.rectangle([120, 30, 230, 45], outline=(255, 255, 255))
    draw.text((125, 32), name, font=font, fill=(0, 255, 0))

    # Avatar box
    draw.text((10, 60), "Avatar:", font=font, fill=(255, 255, 255))
    draw.rectangle([80, 60, 120, 100], fill=available_colors[selected_index], outline=(255, 255, 255))

    # Color picker
    for i, color in enumerate(available_colors):
        x0 = 140 + i * 25
        y0 = 65
        x1 = x0 + 20
        y1 = y0 + 20
        draw.rectangle([x0, y0, x1, y1], fill=color, outline=(255, 255, 255 if i == selected_index else 100))

def run_profile_editor():
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_editor(draw, selected_color_index, updated_name)
    img.save(f"{frame_dir}/frame_000.png")
    img.save(final_output)

run_profile_editor()
