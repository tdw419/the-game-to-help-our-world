from PIL import Image, ImageDraw
import os

img_w, img_h = 160, 80
button_coords = (40, 30, 120, 50)
mouse_path = [(10, 10), (50, 40), (90, 40), (130, 40)]
click_at = (90, 40)
output_image = "vault/gui_demo.png"
frame_dir = "vault/debug_frames_gui/"

os.makedirs(frame_dir, exist_ok=True)

def draw_button(draw, state="normal"):
    x0, y0, x1, y1 = button_coords
    color = {"normal": (50, 50, 255), "hover": (100, 100, 255), "click": (0, 255, 0)}[state]
    draw.rectangle([x0, y0, x1, y1], fill=color, outline=(255, 255, 255))
    draw.text((x0 + 10, y0 + 5), "Click Me", fill=(0, 0, 0))

def run_gui_demo():
    for i, (mx, my) in enumerate(mouse_path):
        img = Image.new("RGB", (img_w, img_h), (0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Determine button state
        x0, y0, x1, y1 = button_coords
        if x0 <= mx <= x1 and y0 <= my <= y1:
            state = "click" if (mx, my) == click_at else "hover"
        else:
            state = "normal"

        draw_button(draw, state=state)

        # Draw mouse
        draw.ellipse([mx - 3, my - 3, mx + 3, my + 3], fill=(255, 0, 0))

        # Save frame
        img.save(f"{frame_dir}/step_{i:03}.png")

    # Save final GUI state
    img.save(output_image)

run_gui_demo()
