
import tkinter as tk

def on_enter(event):
    button.config(bg="lightblue")

def on_leave(event):
    button.config(bg="SystemButtonFace")

def on_click(event):
    button.config(bg="lightgreen")
    status_label.config(text="✅ Button clicked!")

# Create main window
root = tk.Tk()
root.title("Pixel GUI Demo")
root.geometry("300x150")

# Create a label to display status
status_label = tk.Label(root, text="Hover or click the button below", font=("Arial", 10))
status_label.pack(pady=10)

# Create the button
button = tk.Button(root, text="Click Me", font=("Arial", 12), width=20, height=2)
button.pack(pady=20)

# Bind mouse events
button.bind("<Enter>", on_enter)
button.bind("<Leave>", on_leave)
button.bind("<Button-1>", on_click)

# Start the GUI loop
root.mainloop()
