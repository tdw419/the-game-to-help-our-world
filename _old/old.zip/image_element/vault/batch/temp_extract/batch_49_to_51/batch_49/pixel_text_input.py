from PIL import Image, ImageDraw, ImageFont
import os

font = ImageFont.load_default()
img = Image.new("RGB", (320, 200), (20, 20, 20))
draw = ImageDraw.Draw(img)
draw.text((10, 20), "Enter Username:", font=font, fill=(255, 255, 255))
draw.rectangle([10, 40, 250, 60], outline=(255, 255, 255))
draw.text((15, 43), "player_one", font=font, fill=(0, 255, 0))
img.save("vault/gui_text_input.png")
