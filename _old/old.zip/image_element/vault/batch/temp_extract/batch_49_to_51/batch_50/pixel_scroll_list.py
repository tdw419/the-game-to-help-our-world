from PIL import Image, ImageDraw, ImageFont
import os

font = ImageFont.load_default()
img = Image.new("RGB", (320, 200), (15, 15, 15))
draw = ImageDraw.Draw(img)
items = ["Item A", "Item B", "Item C", "Item D", "Item E", "Item F"]
draw.text((10, 10), "Choose an item:", font=font, fill=(255, 255, 0))
for i, item in enumerate(items[:4]):
    y = 30 + i * 20
    draw.rectangle([10, y, 200, y + 18], fill=(40, 40, 40), outline=(80, 80, 80))
    draw.text((15, y + 2), item, font=font, fill=(255, 255, 255))
draw.rectangle([300, 30, 310, 110], fill=(60, 60, 60))
draw.rectangle([300, 30, 310, 60], fill=(150, 150, 150))  # Scroll thumb
img.save("vault/gui_scroll_list.png")
