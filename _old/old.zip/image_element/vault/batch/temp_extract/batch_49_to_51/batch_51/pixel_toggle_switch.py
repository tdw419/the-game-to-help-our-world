from PIL import Image, ImageDraw, ImageFont
import os

font = ImageFont.load_default()
img = Image.new("RGB", (320, 200), (25, 25, 25))
draw = ImageDraw.Draw(img)
draw.text((10, 20), "Enable Notifications", font=font, fill=(255, 255, 255))
draw.rectangle([250, 18, 310, 38], fill=(100, 255, 100), outline=(0, 255, 0))  # On state
draw.ellipse([290, 18, 310, 38], fill=(255, 255, 255))  # Switch knob right
img.save("vault/gui_toggle_switch.png")
