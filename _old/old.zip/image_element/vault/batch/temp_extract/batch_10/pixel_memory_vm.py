from PIL import Image
import os

fragment_path = "vault/image_fragments/fragment_01.png"

INSTRUCTION_SET = {
    (0, 0, 4): "PUSH 1",
    (0, 0, 5): "PUSH 0",
    (0, 0, 6): "POP",
    (0, 0, 11): "WRITE",
    (0, 0, 12): "READ",
    (0, 0, 13): "INC",
    (0, 0, 14): "DEC",
    (255, 0, 255): "END"
}

def run_pixel_memory_vm(image_path):
    stack = []
    memory = {}
    pointer = 0

    try:
        with Image.open(image_path) as img:
            img = img.convert("RGB")
            pixels = list(img.getdata())
            with open("vault/logs/memory_trace.txt", "a") as log:
                log.write("=== Memory VM Start ===\n")
                for i, pixel in enumerate(pixels[:20]):
                    instruction = INSTRUCTION_SET.get(pixel, "NOOP")
                    log.write(f"Pixel {i}: {pixel} -> {instruction}\n")

                    if instruction == "PUSH 1":
                        stack.append(1)
                    elif instruction == "PUSH 0":
                        stack.append(0)
                    elif instruction == "POP":
                        if stack:
                            stack.pop()
                    elif instruction == "WRITE":
                        if stack:
                            memory[pointer] = stack[-1]
                    elif instruction == "READ":
                        value = memory.get(pointer, 0)
                        stack.append(value)
                    elif instruction == "INC":
                        pointer += 1
                    elif instruction == "DEC":
                        pointer = max(0, pointer - 1)
                    elif instruction == "END":
                        break

                    log.write(f"POINTER: {pointer}, STACK: {stack}, MEMORY: {memory}\n")
                log.write("=== Memory VM End ===\n\n")
    except Exception as e:
        print("Error in Pixel Memory VM:", e)

if os.path.exists(fragment_path):
    run_pixel_memory_vm(fragment_path)
else:
    print("Fragment not found.")
