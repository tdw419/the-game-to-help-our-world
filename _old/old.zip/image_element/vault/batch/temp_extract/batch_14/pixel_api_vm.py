from PIL import Image
import os
import json

fragment_path = "vault/image_fragments/fragment_01.png"
registry_path = "vault/logs/pixel_api_registry.json"

API_SET = {
    (1, 0, 0): "MATH.ADD",
    (1, 0, 1): "MATH.SUB",
    (2, 0, 0): "IO.SAVE",
    (255, 0, 255): "END"
}

def run_pixel_api_vm(image_path):
    stack = []

    try:
        with Image.open(image_path) as img:
            img = img.convert("RGB")
            pixels = list(img.getdata())

        with open("vault/logs/api_trace.txt", "a") as log:
            log.write("=== Pixel API VM Start ===\n")

            for i, pixel in enumerate(pixels[:20]):
                api_call = API_SET.get(pixel, "NOOP")
                log.write(f"Pixel {i}: {pixel} -> {api_call}\n")

                if api_call == "MATH.ADD" and len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(a + b)
                elif api_call == "MATH.SUB" and len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(a - b)
                elif api_call == "IO.SAVE":
                    log.write("Simulated saving data...\n")
                elif api_call == "END":
                    break

                log.write(f"STACK: {stack}\n")

            log.write("=== Pixel API VM End ===\n\n")

        # Save registry
        with open(registry_path, "w") as f:
            json.dump({f"{r},{g},{b}": name for (r, g, b), name in API_SET.items()}, f, indent=2)

    except Exception as e:
        print("Error in Pixel API VM:", e)

if os.path.exists(fragment_path):
    run_pixel_api_vm(fragment_path)
else:
    print("Fragment not found.")
