from PIL import Image, ImageDraw, ImageFont
import os
import datetime

screen_w, screen_h = 300, 200
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_launcher/"
final_output = "vault/gui_dashboard_launcher.png"
os.makedirs(frame_dir, exist_ok=True)

apps = [
    {"label": "Files", "icon": (255, 255, 0), "rect": (10, 170, 50, 190)},
    {"label": "Terminal", "icon": (0, 255, 255), "rect": (60, 170, 100, 190)},
    {"label": "Settings", "icon": (255, 0, 255), "rect": (110, 170, 150, 190)}
]
clicked_app = "Terminal"

def draw_launcher_dashboard(draw):
    # Dashboard header
    draw.rectangle([0, 0, screen_w, screen_h], fill=(15, 15, 15))
    draw.text((10, 10), "Dashboard", font=font, fill=(200, 200, 200))

    # Simulated profile summary
    draw.text((10, 30), "User: SysAdmin", font=font, fill=(0, 255, 0))
    draw.rectangle([240, 10, 280, 30], outline=(255, 255, 255))
    now = datetime.datetime.now().strftime("%H:%M")
    draw.text((245, 13), now, font=font, fill=(255, 255, 0))

    # App launcher bar
    for app in apps:
        x0, y0, x1, y1 = app["rect"]
        outline = (0, 255, 0) if app["label"] == clicked_app else (80, 80, 80)
        draw.rectangle([x0, y0, x1, y1], fill=app["icon"], outline=outline)
        draw.text((x0 + 2, y1 + 2), app["label"], font=font, fill=(255, 255, 255))

def run_dashboard_launcher():
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_launcher_dashboard(draw)
    img.save(f"{frame_dir}/frame_000.png")
    img.save(final_output)

run_dashboard_launcher()
