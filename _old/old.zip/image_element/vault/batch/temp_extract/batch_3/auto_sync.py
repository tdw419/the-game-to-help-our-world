import os
import shutil

print("Running Batch 3 auto_sync...")

# Move image fragment to vault/image_fragments
if not os.path.exists("vault/image_fragments"):
    os.makedirs("vault/image_fragments")
shutil.move("batch_3/fragment_01.png", "vault/image_fragments/fragment_01.png")

# Move image_index.txt to vault/logs
shutil.move("batch_3/image_index.txt", "vault/logs/image_index.txt")

# Log the batch processing
with open("vault/logs/auto_sync_log.txt", "a") as log_file:
    log_file.write("Batch 3 loaded image fragment and index.\n")

print("Batch 3 auto_sync complete.")
