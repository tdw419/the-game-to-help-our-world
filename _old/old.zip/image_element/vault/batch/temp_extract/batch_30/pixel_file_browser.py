from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 280, 160
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_file_browser/"
final_output = "vault/gui_file_browser.png"
os.makedirs(frame_dir, exist_ok=True)

file_list = ["dog.png", "cat.jpg", "avatar1.png", "tree.bmp"]
selected_file_index = 2  # Simulate clicking on "avatar1.png"

def draw_file_browser(draw, selected_index):
    draw.rectangle([0, 0, screen_w, screen_h], fill=(0, 0, 0))
    draw.text((10, 10), "Select Avatar Image", font=font, fill=(255, 255, 255))

    for i, fname in enumerate(file_list):
        y = 35 + i * 20
        color = (255, 255, 255) if i == selected_index else (180, 180, 180)
        draw.rectangle([10, y, 260, y + 18], fill=(40, 40, 40), outline=color)
        draw.text((15, y + 2), fname, font=font, fill=color)

    draw.rectangle([10, 125, 120, 145], outline=(0, 255, 0))
    draw.text((15, 127), "Upload Avatar", font=font, fill=(0, 255, 0))

def run_file_browser():
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_file_browser(draw, selected_file_index)
    img.save(f"{frame_dir}/frame_000.png")
    img.save(final_output)

run_file_browser()
