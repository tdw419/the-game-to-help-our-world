from PIL import Image
import os
import json

image_path = "vault/image_fragments/generated_script.png"
map_path = "vault/logs/instruction_to_rgb.json"
log_path = "vault/logs/compiled_run_trace.txt"

def rgb_to_instruction(rgb, reverse_map):
    return reverse_map.get(f"{rgb[0]},{rgb[1]},{rgb[2]}", "NOOP")

def run_compiled_pixel_program():
    if not os.path.exists(image_path) or not os.path.exists(map_path):
        print("Required files missing.")
        return

    with open(map_path, "r") as f:
        rgb_map = json.load(f)
        reverse_map = {v: k for k, v in rgb_map.items()}
        reverse_map = {k: v for v, k in reverse_map.items()}  # string to name

    with Image.open(image_path) as img:
        img = img.convert("RGB")
        pixels = list(img.getdata())

    stack = []

    with open(log_path, "a") as log:
        log.write("=== Compiled Script Execution Start ===\n")
        for i, pixel in enumerate(pixels):
            instr = rgb_to_instruction(pixel, reverse_map)
            log.write(f"Pixel {i}: {pixel} -> {instr}\n")

            if instr == "PUSH 1":
                stack.append(1)
            elif instr == "PUSH 0":
                stack.append(0)
            elif instr == "MATH.ADD" and len(stack) >= 2:
                b = stack.pop()
                a = stack.pop()
                stack.append(a + b)
            elif instr == "PRINT":
                val = stack[-1] if stack else None
                log.write(f"PRINT: {val}\n")
            elif instr == "END":
                break

            log.write(f"STACK: {stack}\n")
        log.write("=== Compiled Script Execution End ===\n\n")

run_compiled_pixel_program()
