from PIL import Image
import os

fragment_path = "vault/image_fragments/fragment_01.png"

INSTRUCTION_SET = {
    (0, 0, 4): "PUSH 1",
    (0, 0, 5): "PUSH 0",
    (0, 0, 6): "POP",
    (0, 0, 21): "SET_FUNC_A",
    (0, 0, 22): "CALL_FUNC_A",
    (0, 0, 23): "RETURN_VAL",
    (0, 0, 24): "PRINT",
    (255, 0, 255): "END"
}

def run_pixel_function_vm(image_path):
    stack = []
    call_stack = []
    func_registry = {}
    pointer = 0
    program = []

    try:
        with Image.open(image_path) as img:
            img = img.convert("RGB")
            program = list(img.getdata())

        # First pass to index SET_FUNC_A
        for i, pixel in enumerate(program):
            if INSTRUCTION_SET.get(pixel) == "SET_FUNC_A":
                func_registry["func_a"] = i + 1  # label starts after SET_FUNC_A

        with open("vault/logs/function_trace.txt", "a") as log:
            log.write("=== Function VM Start ===\n")
            while pointer < len(program):
                pixel = program[pointer]
                instruction = INSTRUCTION_SET.get(pixel, "NOOP")
                log.write(f"Pointer {pointer}: {pixel} -> {instruction}\n")

                if instruction == "PUSH 1":
                    stack.append(1)
                elif instruction == "PUSH 0":
                    stack.append(0)
                elif instruction == "POP":
                    if stack:
                        stack.pop()
                elif instruction == "CALL_FUNC_A":
                    call_stack.append(pointer + 1)
                    pointer = func_registry.get("func_a", pointer + 1)
                    continue
                elif instruction == "RETURN_VAL":
                    if call_stack:
                        pointer = call_stack.pop()
                        continue
                elif instruction == "PRINT":
                    value = stack[-1] if stack else None
                    log.write(f"PRINT: {value}\n")
                elif instruction == "END":
                    break

                log.write(f"STACK: {stack}, CALL_STACK: {call_stack}\n")
                pointer += 1
            log.write("=== Function VM End ===\n\n")
    except Exception as e:
        print("Error in Pixel Function VM:", e)

if os.path.exists(fragment_path):
    run_pixel_function_vm(fragment_path)
else:
    print("Fragment not found.")
