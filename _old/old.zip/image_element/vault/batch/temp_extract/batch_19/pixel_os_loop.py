from PIL import Image
import os
import json

image_path = "vault/image_fragments/generated_script.png"
map_path = "vault/logs/instruction_to_rgb.json"
log_path = "vault/logs/register_trace.txt"

def rgb_to_instruction(rgb, reverse_map):
    return reverse_map.get(f"{rgb[0]},{rgb[1]},{rgb[2]}", "NOOP")

def run_pixel_os_loop():
    if not os.path.exists(image_path) or not os.path.exists(map_path):
        print("Required files missing.")
        return

    with open(map_path, "r") as f:
        rgb_map = json.load(f)
        reverse_map = {v: k for k, v in rgb_map.items()}
        reverse_map = {k: v for v, k in reverse_map.items()}  # string to instruction

    with Image.open(image_path) as img:
        img = img.convert("RGB")
        pixels = list(img.getdata())
        w, h = img.size

    # Simulated registers
    A = 0
    B = 0
    PC = 0
    FLAGS = {"Z": False}

    with open(log_path, "a") as log:
        log.write("=== Pixel OS Loop Start ===\n")
        while PC < len(pixels):
            pixel = pixels[PC]
            instr = rgb_to_instruction(pixel, reverse_map)
            log.write(f"PC {PC} | Pixel: {pixel} -> {instr}\n")

            if instr == "PUSH 1":
                A = 1
            elif instr == "PUSH 0":
                A = 0
            elif instr == "MATH.ADD":
                A = A + B
            elif instr == "MATH.SUB":
                A = A - B
            elif instr == "PRINT":
                log.write(f"PRINT A: {A}\n")
            elif instr == "END":
                break

            FLAGS["Z"] = (A == 0)
            log.write(f"REGISTERS -> A: {A}, B: {B}, PC: {PC}, FLAGS: {FLAGS}\n")
            PC += 1
        log.write("=== Pixel OS Loop End ===\n\n")

run_pixel_os_loop()
