from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 260, 140
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_profile/"
final_output = "vault/gui_profile_screen.png"
os.makedirs(frame_dir, exist_ok=True)

users = [
    {
        "name": "User1",
        "avatar": (255, 100, 100),
        "role": "Guest",
        "last_login": "2025-05-25",
        "rect": (20, 30, 100, 90)
    },
    {
        "name": "Admin",
        "avatar": (100, 255, 100),
        "role": "Root",
        "last_login": "2025-05-26",
        "rect": (130, 30, 210, 90)
    }
]

click_pos = (150, 60)  # Simulated click on Admin

def draw_profile(draw, user):
    draw.rectangle([0, 0, screen_w, screen_h], fill=(0, 0, 0))
    draw.rectangle([10, 10, 250, 130], outline=(255, 255, 255))
    draw.rectangle([20, 20, 60, 60], fill=user["avatar"])
    draw.text((70, 20), f"Name: {user['name']}", font=font, fill=(255, 255, 255))
    draw.text((70, 40), f"Role: {user['role']}", font=font, fill=(0, 255, 255))
    draw.text((70, 60), f"Last login: {user['last_login']}", font=font, fill=(255, 255, 0))

def run_profile_switch():
    selected_user = None
    for user in users:
        x0, y0, x1, y1 = user["rect"]
        if x0 <= click_pos[0] <= x1 and y0 <= click_pos[1] <= y1:
            selected_user = user
            break

    if selected_user:
        img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw_profile(draw, selected_user)
        img.save(f"{frame_dir}/frame_000.png")
        img.save(final_output)

run_profile_switch()
