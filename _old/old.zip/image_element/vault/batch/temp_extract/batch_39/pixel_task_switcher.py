from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 320, 200
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_switcher/"
final_output = "vault/gui_task_switcher.png"
os.makedirs(frame_dir, exist_ok=True)

apps = [
    {"label": "Terminal", "rect": (50, 70, 110, 130), "active": True},
    {"label": "Files", "rect": (130, 70, 190, 130), "active": False},
    {"label": "Settings", "rect": (210, 70, 270, 130), "active": False}
]

def draw_task_switch_overlay(draw):
    # Dim background
    draw.rectangle([0, 0, screen_w, screen_h], fill=(0, 0, 0, 180))

    # Draw app thumbnails
    for app in apps:
        x0, y0, x1, y1 = app["rect"]
        outline = (0, 255, 0) if app["active"] else (100, 100, 100)
        fill = (40, 40, 40) if not app["active"] else (0, 60, 0)
        draw.rectangle([x0, y0, x1, y1], fill=fill, outline=outline)
        draw.text((x0 + 5, y1 + 5), app["label"], font=font, fill=(255, 255, 255))

def run_task_switcher():
    img = Image.new("RGB", (screen_w, screen_h), (30, 30, 30))
    draw = ImageDraw.Draw(img)
    draw_task_switch_overlay(draw)
    img.save(f"{frame_dir}/frame_000.png")
    img.save(final_output)

run_task_switcher()
