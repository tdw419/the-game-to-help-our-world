from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 300, 200
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_terminal_app/"
final_output = "vault/gui_terminal_open.png"
os.makedirs(frame_dir, exist_ok=True)

def draw_terminal_window(draw):
    # Window frame
    term_x0, term_y0 = 40, 40
    term_x1, term_y1 = 260, 150
    draw.rectangle([term_x0, term_y0, term_x1, term_y1], fill=(0, 0, 0), outline=(0, 255, 0))

    # Title bar
    draw.rectangle([term_x0, term_y0, term_x1, term_y0 + 15], fill=(40, 40, 40), outline=(0, 255, 0))
    draw.text((term_x0 + 5, term_y0 + 2), "Terminal", font=font, fill=(0, 255, 0))
    draw.rectangle([term_x1 - 15, term_y0, term_x1, term_y0 + 15], fill=(100, 0, 0))
    draw.text((term_x1 - 12, term_y0 + 1), "X", font=font, fill=(255, 255, 255))

    # Terminal content
    lines = [
        "$ whoami",
        "SysAdmin",
        "$ uptime",
        "12:45:32 up 2 days, 3:42"
    ]
    for i, line in enumerate(lines):
        draw.text((term_x0 + 5, term_y0 + 20 + i * 12), line, font=font, fill=(0, 255, 0))

def run_terminal_app_window():
    img = Image.new("RGB", (screen_w, screen_h), (10, 10, 10))
    draw = ImageDraw.Draw(img)
    draw.text((10, 10), "Dashboard (Terminal Open)", font=font, fill=(200, 200, 200))
    draw_terminal_window(draw)
    img.save(f"{frame_dir}/frame_000.png")
    img.save(final_output)

run_terminal_app_window()
