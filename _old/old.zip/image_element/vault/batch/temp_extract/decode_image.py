from PIL import Image

input_path = "command_map_sample.png"
output_path = "commands_decoded.txt"

COMMANDS = {
    (255, 0, 0): "START",
    (0, 255, 0): "SAVE",
    (0, 0, 255): "STOP",
    (255, 255, 0): "JUMP",
    (0, 255, 255): "WAIT"
}

try:
    img = Image.open(input_path)
    pixels = img.load()
    width, height = img.size

    with open(output_path, "w") as f:
        f.write(f"Decoded commands from {input_path} ({width}x{height}):\n")
        for y in range(height):
            for x in range(width):
                r, g, b = pixels[x, y][:3]
                cmd = COMMANDS.get((r, g, b))
                if cmd:
                    f.write(f"({x}, {y}) -> {cmd}\n")

    print(f"✅ Commands decoded from {input_path} to {output_path}")

except Exception as e:
    print(f"❌ Error decoding commands: {e}")
