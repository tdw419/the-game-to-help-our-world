input_path = "commands_decoded.txt"
log_path = "execution_log.txt"

ACTIONS = {
    "START": lambda: print("🚀 System started."),
    "SAVE": lambda: open("saved.txt", "w").write("📁 Save operation completed."),
    "STOP": lambda: print("🛑 System halted."),
    "JUMP": lambda: print("⏩ Jumping to next routine..."),
    "WAIT": lambda: print("⏳ Waiting..."),
}

try:
    with open(input_path, "r") as f:
        lines = [line.strip() for line in f if "->" in line]

    with open(log_path, "w") as log:
        for line in lines:
            _, cmd = line.split("->")
            cmd = cmd.strip().upper()
            action = ACTIONS.get(cmd)
            if action:
                action()
                log.write(f"Executed: {cmd}\n")
            else:
                log.write(f"Ignored: {cmd}\n")

    print("✅ Logic chain interpreted and executed.")
except Exception as e:
    print(f"❌ Error executing commands: {e}")
