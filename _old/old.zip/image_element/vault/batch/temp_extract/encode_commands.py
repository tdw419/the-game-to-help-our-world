from PIL import Image

COMMAND_COLORS = {
    "START": (255, 0, 0),
    "SAVE": (0, 255, 0),
    "STOP": (0, 0, 255),
    "JUMP": (255, 255, 0),
    "WAIT": (0, 255, 255)
}

input_path = "commands_input.txt"
output_path = "encoded_image.png"

try:
    with open(input_path, "r") as f:
        commands = [line.strip().upper() for line in f if line.strip()]

    img = Image.new("RGB", (len(commands), 1), "black")
    for i, cmd in enumerate(commands):
        color = COMMAND_COLORS.get(cmd, (0, 0, 0))
        img.putpixel((i, 0), color)

    img.save(output_path)
    print(f"✅ Encoded {len(commands)} commands into {output_path}")

except Exception as e:
    print(f"❌ Error encoding commands: {e}")
