from PIL import Image
import os
import json

script_path = "vault/scripts/hello_script.txt"
output_image_path = "vault/image_fragments/generated_script.png"
map_path = "vault/logs/instruction_to_rgb.json"

instruction_map = {
    "PUSH 1": (0, 0, 4),
    "PUSH 0": (0, 0, 5),
    "MATH.ADD": (1, 0, 0),
    "MATH.SUB": (1, 0, 1),
    "PRINT": (0, 0, 24),
    "END": (255, 0, 255)
}

def compile_script_to_pixels():
    if not os.path.exists(script_path):
        print("Script not found.")
        return

    with open(script_path, "r") as script:
        instructions = [line.strip() for line in script if line.strip()]

    pixels = [instruction_map.get(instr, (128, 128, 128)) for instr in instructions]

    img = Image.new("RGB", (len(pixels), 1))
    img.putdata(pixels)
    os.makedirs(os.path.dirname(output_image_path), exist_ok=True)
    img.save(output_image_path)

    with open(map_path, "w") as f:
        json.dump({k: list(v) for k, v in instruction_map.items()}, f, indent=2)

    print(f"Compiled script to {output_image_path}")

compile_script_to_pixels()
