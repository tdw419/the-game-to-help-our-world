import os

print("Running Batch 15 auto_sync...")

# Run the pixel script compiler
exec(open("batch_15/pixel_script_compiler.py").read(), {"__name__": "__main__"})

# Log the batch processing
with open("vault/logs/auto_sync_log.txt", "a") as log_file:
    log_file.write("Batch 15 executed: compiled text script into pixel image fragment.\n")

print("Batch 15 auto_sync complete.")
