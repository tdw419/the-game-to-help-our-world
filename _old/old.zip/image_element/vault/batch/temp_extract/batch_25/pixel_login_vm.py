from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 200, 100
font = ImageFont.load_default()
text_input = ["a", "d", "m", "i", "n"]
frame_dir = "vault/debug_frames_login/"
final_output = "vault/gui_login_demo.png"

os.makedirs(frame_dir, exist_ok=True)

def run_login_vm():
    user_input = ""
    cursor_visible = True

    for i, char in enumerate(text_input):
        img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Labels and input box
        draw.text((10, 10), "Username:", font=font, fill=(255, 255, 255))
        draw.rectangle([10, 30, 190, 50], outline=(255, 255, 255))
        draw.text((12, 32), user_input, font=font, fill=(0, 255, 0))

        # Blinking cursor (even frames only)
        if cursor_visible:
            cursor_x = 12 + font.getsize(user_input)[0]
            draw.line([(cursor_x, 32), (cursor_x, 46)], fill=(255, 255, 255))

        # Save frame
        img.save(f"{frame_dir}/frame_{i:03}.png")

        user_input += char
        cursor_visible = not cursor_visible

    # Final screen
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.text((10, 10), "Username:", font=font, fill=(255, 255, 255))
    draw.rectangle([10, 30, 190, 50], outline=(255, 255, 255))
    draw.text((12, 32), user_input, font=font, fill=(0, 255, 0))
    img.save(final_output)

run_login_vm()
