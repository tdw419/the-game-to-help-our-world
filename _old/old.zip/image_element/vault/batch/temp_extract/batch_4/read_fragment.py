from PIL import Image
import os

fragment_path = "vault/image_fragments/fragment_01.png"

if os.path.exists(fragment_path):
    try:
        with Image.open(fragment_path) as img:
            img.load()
            print(f"Fragment loaded: {fragment_path}")
            print(f"Size: {img.size}, Mode: {img.mode}")
    except Exception as e:
        print("Error reading fragment:", e)
else:
    print("Fragment not found.")
