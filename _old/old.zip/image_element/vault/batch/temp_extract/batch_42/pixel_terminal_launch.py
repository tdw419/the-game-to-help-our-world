from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 320, 200
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_launch/"
final_output = "vault/gui_terminal_launched.png"
os.makedirs(frame_dir, exist_ok=True)

start_rect = (50, 70, 110, 130)
end_rect = (0, 0, screen_w, screen_h)

def interpolate(start, end, step, total_steps):
    return int(start + (end - start) * (step / total_steps))

def draw_terminal_launch_frame(draw, step, total_steps):
    # Fade background
    fade = int(200 * (step / total_steps))
    draw.rectangle([0, 0, screen_w, screen_h], fill=(fade, fade, fade))

    # Terminal window expanding
    x0 = interpolate(start_rect[0], end_rect[0], step, total_steps)
    y0 = interpolate(start_rect[1], end_rect[1], step, total_steps)
    x1 = interpolate(start_rect[2], end_rect[2], step, total_steps)
    y1 = interpolate(start_rect[3], end_rect[3], step, total_steps)

    draw.rectangle([x0, y0, x1, y1], fill=(0, 0, 0), outline=(0, 255, 0))
    if step == total_steps:
        draw.text((10, 10), "Terminal - Fullscreen", font=font, fill=(0, 255, 0))
        lines = ["$ whoami", "SysAdmin", "$ uptime", "up 2 days"]
        for i, line in enumerate(lines):
            draw.text((10, 30 + i * 12), line, font=font, fill=(0, 255, 0))

def run_terminal_launch():
    total_steps = 6
    for step in range(total_steps + 1):
        img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw_terminal_launch_frame(draw, step, total_steps)
        img.save(f"{frame_dir}/frame_{step:03}.png")
        if step == total_steps:
            img.save(final_output)

run_terminal_launch()
