from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 260, 160
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_avatar_upload/"
final_output = "vault/gui_avatar_confirmation.png"
os.makedirs(frame_dir, exist_ok=True)

avatar_color = (100, 100, 255)  # Simulated avatar preview color
confirm_clicked = True          # Simulate confirm click

def draw_avatar_confirmation(draw, show_success):
    draw.rectangle([0, 0, screen_w, screen_h], fill=(0, 0, 0))
    draw.text((10, 10), "Avatar Preview", font=font, fill=(255, 255, 255))

    # Avatar preview box
    draw.rectangle([20, 30, 80, 90], fill=avatar_color, outline=(255, 255, 255))

    # Buttons
    draw.rectangle([100, 40, 180, 60], outline=(0, 255, 0))
    draw.text((105, 43), "Confirm", font=font, fill=(0, 255, 0))

    draw.rectangle([100, 70, 180, 90], outline=(255, 0, 0))
    draw.text((105, 73), "Cancel", font=font, fill=(255, 0, 0))

    if show_success:
        draw.text((10, 120), "Avatar updated!", font=font, fill=(0, 255, 0))

def run_avatar_confirmation():
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_avatar_confirmation(draw, show_success=False)
    img.save(f"{frame_dir}/frame_000.png")

    # Show confirmation result
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_avatar_confirmation(draw, show_success=confirm_clicked)
    img.save(f"{frame_dir}/frame_001.png")
    img.save(final_output)

run_avatar_confirmation()
