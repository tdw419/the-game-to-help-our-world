from PIL import Image, ImageDraw, ImageFont
import os
from datetime import datetime

screen_w, screen_h = 320, 200
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_snap/"
final_output = "vault/gui_snap_widgets.png"
os.makedirs(frame_dir, exist_ok=True)

def draw_terminal_panel(draw):
    draw.rectangle([0, 0, screen_w // 2, screen_h], fill=(0, 0, 0), outline=(0, 255, 0))
    draw.rectangle([0, 0, screen_w // 2, 15], fill=(40, 40, 40), outline=(0, 255, 0))
    draw.text((5, 2), "Terminal", font=font, fill=(0, 255, 0))
    lines = ["$ whoami", "SysAdmin", "$ date", datetime.now().strftime("%a %b %d %H:%M:%S")]
    for i, line in enumerate(lines):
        draw.text((5, 20 + i * 12), line, font=font, fill=(0, 255, 0))

def draw_widget_panel(draw):
    x0 = screen_w // 2
    draw.rectangle([x0, 0, screen_w, screen_h], fill=(25, 25, 25), outline=(100, 100, 100))
    draw.rectangle([x0, 0, screen_w, 15], fill=(60, 60, 60))
    draw.text((x0 + 5, 2), "Notes", font=font, fill=(255, 255, 0))
    notes = [
        "- Finish Batch 36",
        "- Review dashboard UI",
        "- Launch snapshot build"
    ]
    for i, note in enumerate(notes):
        draw.text((x0 + 5, 20 + i * 12), note, font=font, fill=(255, 255, 255))

def run_snap_and_widgets():
    img = Image.new("RGB", (screen_w, screen_h), (10, 10, 10))
    draw = ImageDraw.Draw(img)
    draw_terminal_panel(draw)
    draw_widget_panel(draw)
    img.save(f"{frame_dir}/frame_000.png")
    img.save(final_output)

run_snap_and_widgets()
