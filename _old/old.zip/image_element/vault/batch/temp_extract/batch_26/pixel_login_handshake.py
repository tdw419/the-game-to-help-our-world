from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 240, 120
font = ImageFont.load_default()
username = "admin"
password = "12345"
frame_dir = "vault/debug_frames_login_handshake/"
final_output = "vault/gui_login_result.png"

os.makedirs(frame_dir, exist_ok=True)

def draw_input_screen(draw, user_input, pass_input, show_result=False, success=False):
    # Labels
    draw.text((10, 10), "Username:", font=font, fill=(255, 255, 255))
    draw.text((10, 50), "Password:", font=font, fill=(255, 255, 255))

    # Input boxes
    draw.rectangle([90, 10, 210, 30], outline=(255, 255, 255))
    draw.rectangle([90, 50, 210, 70], outline=(255, 255, 255))

    draw.text((92, 12), user_input, font=font, fill=(0, 255, 0))
    draw.text((92, 52), "●" * len(pass_input), font=font, fill=(0, 255, 0))

    if show_result:
        msg = "Login successful" if success else "Invalid credentials"
        color = (0, 255, 0) if success else (255, 0, 0)
        draw.text((10, 90), msg, font=font, fill=color)

def run_login_handshake():
    user_input = ""
    pass_input = ""
    frame_count = 0

    for char in username:
        img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
        draw = ImageDraw.Draw(img)
        user_input += char
        draw_input_screen(draw, user_input, pass_input)
        img.save(f"{frame_dir}/frame_{frame_count:03}.png")
        frame_count += 1

    for char in password:
        img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
        draw = ImageDraw.Draw(img)
        pass_input += char
        draw_input_screen(draw, user_input, pass_input)
        img.save(f"{frame_dir}/frame_{frame_count:03}.png")
        frame_count += 1

    # Final screen with result
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    success = user_input == "admin" and password == "12345"
    draw_input_screen(draw, user_input, pass_input, show_result=True, success=success)
    img.save(f"{frame_dir}/frame_{frame_count:03}.png")
    img.save(final_output)

run_login_handshake()
