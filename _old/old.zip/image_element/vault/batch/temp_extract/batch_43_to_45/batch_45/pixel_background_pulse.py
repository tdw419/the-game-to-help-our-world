from PIL import Image, ImageDraw
import os

screen_w, screen_h = 320, 200
frame_dir = "vault/debug_frames_pulse/"
final_output = "vault/gui_background_pulse.png"
os.makedirs(frame_dir, exist_ok=True)

def draw_pulse_frame(draw, brightness):
    color = (brightness, brightness, brightness)
    draw.rectangle([0, 0, screen_w, screen_h], fill=color)

def run_background_pulse():
    for i in range(6):
        level = 40 + (i % 2) * 80  # Pulse between dark and lighter
        img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw_pulse_frame(draw, level)
        img.save(f"{frame_dir}/frame_{i:03}.png")
        if i == 5:
            img.save(final_output)

run_background_pulse()
