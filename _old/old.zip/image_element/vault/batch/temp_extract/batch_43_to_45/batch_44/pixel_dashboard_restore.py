from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 320, 200
font = ImageFont.load_default()
final_output = "vault/gui_dashboard_restored.png"

def draw_dashboard(draw):
    draw.rectangle([0, 0, screen_w, screen_h], fill=(10, 10, 10))
    draw.text((10, 10), "Dashboard Restored", font=font, fill=(0, 255, 0))
    draw.text((10, 30), "Widgets active.", font=font, fill=(255, 255, 0))

def run_dashboard_restore():
    img = Image.new("RGB", (screen_w, screen_h), (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_dashboard(draw)
    img.save(final_output)

run_dashboard_restore()
