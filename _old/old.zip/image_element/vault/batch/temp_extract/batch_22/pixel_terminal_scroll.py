from PIL import Image, ImageDraw, ImageFont
import os

screen_width, screen_height = 16, 4
font_size = 12
cell_w, cell_h = 8, 16
image_w, image_h = screen_width * cell_w, screen_height * cell_h
font = ImageFont.load_default()

text = "Welcome to PixelOS!"
output_folder = "vault/debug_frames_terminal/"
screen_path = "vault/virtual_terminal_scroll.png"
log_path = "vault/logs/terminal_scroll_trace.txt"

os.makedirs(output_folder, exist_ok=True)

def scroll_terminal_buffer(buffer):
    return buffer[1:] + ["" * screen_width]

def run_terminal_scroll_vm():
    buffer = ["" for _ in range(screen_height)]
    cursor_x, cursor_y = 0, 0
    frame_num = 0

    with open(log_path, "a") as log:
        log.write("=== Scrolling Terminal Start ===\n")
        for char in text:
            if cursor_x >= screen_width:
                cursor_x = 0
                cursor_y += 1
            if cursor_y >= screen_height:
                buffer = buffer[1:] + [""]
                cursor_y = screen_height - 1

            line = buffer[cursor_y]
            if len(line) < screen_width:
                line = line.ljust(cursor_x) + char
                buffer[cursor_y] = line
            else:
                buffer[cursor_y] = line[:cursor_x] + char + line[cursor_x+1:]

            # Draw screen
            img = Image.new("RGB", (image_w, image_h), (0, 0, 0))
            draw = ImageDraw.Draw(img)
            for y, line in enumerate(buffer):
                draw.text((0, y * cell_h), line, fill=(0, 255, 0), font=font)

            # Cursor blink simulation
            if frame_num % 2 == 0:
                cx = cursor_x * cell_w
                cy = cursor_y * cell_h
                draw.rectangle([cx, cy, cx + cell_w - 1, cy + cell_h - 1], outline=(255, 255, 255))

            img.save(f"{output_folder}/step_{frame_num:03}.png")
            frame_num += 1
            cursor_x += 1

            log.write(f"Char '{char}' -> Cursor: ({cursor_x}, {cursor_y})\n")

        img.save(screen_path)
        log.write(f"Saved final screen to {screen_path}\n")
        log.write("=== Scrolling Terminal End ===\n\n")

run_terminal_scroll_vm()
