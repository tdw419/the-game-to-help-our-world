import os

print("Running Batch 17 auto_sync...")

# Run the pixel debugger
exec(open("batch_17/pixel_debugger.py").read(), {"__name__": "__main__"})

# Log the batch processing
with open("vault/logs/auto_sync_log.txt", "a") as log_file:
    log_file.write("Batch 17 executed: step-through debugger trace generated.\n")

print("Batch 17 auto_sync complete.")
