from PIL import Image, ImageDraw
import os

img_w, img_h = 160, 100
menu_items = {
    "Home": (10, 10, 70, 30),
    "Settings": (80, 10, 150, 30)
}
views = {
    "Home": "Welcome Home!",
    "Settings": "Configure Settings..."
}
click_sequence = [(15, 20), (85, 20)]  # clicks on Home then Settings
frame_dir = "vault/debug_frames_menu/"
output_image = "vault/gui_menu_demo.png"

os.makedirs(frame_dir, exist_ok=True)

def draw_menu(draw, active):
    for name, (x0, y0, x1, y1) in menu_items.items():
        color = (100, 100, 255) if name == active else (60, 60, 60)
        draw.rectangle([x0, y0, x1, y1], fill=color, outline=(255, 255, 255))
        draw.text((x0 + 5, y0 + 5), name, fill=(255, 255, 255))

def draw_view(draw, view_name):
    message = views.get(view_name, "Unknown")
    draw.text((10, 50), message, fill=(0, 255, 0))

def detect_view_from_click(x, y):
    for name, (x0, y0, x1, y1) in menu_items.items():
        if x0 <= x <= x1 and y0 <= y <= y1:
            return name
    return None

def run_pixel_menu_vm():
    current_view = "Home"
    for i, (mx, my) in enumerate(click_sequence):
        img = Image.new("RGB", (img_w, img_h), (0, 0, 0))
        draw = ImageDraw.Draw(img)

        clicked_view = detect_view_from_click(mx, my)
        if clicked_view:
            current_view = clicked_view

        draw_menu(draw, current_view)
        draw_view(draw, current_view)
        draw.ellipse([mx-3, my-3, mx+3, my+3], fill=(255, 0, 0))  # cursor

        img.save(f"{frame_dir}/step_{i:03}.png")

    img.save(output_image)

run_pixel_menu_vm()
