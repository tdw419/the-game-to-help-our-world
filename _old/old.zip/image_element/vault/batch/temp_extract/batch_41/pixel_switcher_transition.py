from PIL import Image, ImageDraw, ImageFont
import os

screen_w, screen_h = 320, 200
font = ImageFont.load_default()
frame_dir = "vault/debug_frames_transition/"
final_output = "vault/gui_switcher_transition.png"
os.makedirs(frame_dir, exist_ok=True)

# Starting layout includes Terminal, Files, Settings
apps_start = [
    {"label": "Terminal", "start": (50, 70), "end": (80, 70), "active": True},
    {"label": "Files", "start": (130, 70), "end": (None, None), "active": False},
    {"label": "Settings", "start": (210, 70), "end": (180, 70), "active": False}
]

def interpolate(start, end, step, total_steps):
    if start is None or end is None:
        return None
    return int(start + (end - start) * (step / total_steps))

def draw_frame(draw, step, total_steps):
    # Dim background
    draw.rectangle([0, 0, screen_w, screen_h], fill=(0, 0, 0))

    for app in apps_start:
        if app["label"] == "Files" and step == total_steps:
            continue  # fully gone
        sx, sy = app["start"]
        ex, ey = app["end"]
        if app["label"] == "Files":
            scale = 1 - step / total_steps
            x = interpolate(sx, ex or sx, step, total_steps)
            y = interpolate(sy, ey or sy, step, total_steps)
            size = int(60 * scale)
            if size <= 0:
                continue
            x0, y0 = x, y
            x1, y1 = x + size, y + size
        else:
            x = interpolate(sx, ex, step, total_steps)
            y = interpolate(sy, ey, step, total_steps)
            x0, y0, x1, y1 = x, y, x + 60, y + 60

        fill = (0, 60, 0) if app["active"] else (40, 40, 40)
        outline = (0, 255, 0) if app["active"] else (100, 100, 100)
        draw.rectangle([x0, y0, x1, y1], fill=fill, outline=outline)
        draw.text((x0 + 5, y1 + 5), app["label"], font=font, fill=(255, 255, 255))

def run_switcher_transition():
    total_steps = 5
    for step in range(total_steps + 1):
        img = Image.new("RGB", (screen_w, screen_h), (10, 10, 10))
        draw = ImageDraw.Draw(img)
        draw_frame(draw, step, total_steps)
        img.save(f"{frame_dir}/frame_{step:03}.png")
        if step == total_steps:
            img.save(final_output)

run_switcher_transition()
