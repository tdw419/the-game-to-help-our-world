from PIL import Image
import os

fragment_path = "vault/image_fragments/fragment_01.png"

def interpret_pixel_data(image_path):
    try:
        with Image.open(image_path) as img:
            img = img.convert("RGB")
            pixels = list(img.getdata())
            print("First 10 pixels:")
            for i, pixel in enumerate(pixels[:10]):
                print(f"Pixel {i}: R={pixel[0]}, G={pixel[1]}, B={pixel[2]}")
    except Exception as e:
        print("Error interpreting pixels:", e)

if os.path.exists(fragment_path):
    interpret_pixel_data(fragment_path)
else:
    print("Fragment not found.")
