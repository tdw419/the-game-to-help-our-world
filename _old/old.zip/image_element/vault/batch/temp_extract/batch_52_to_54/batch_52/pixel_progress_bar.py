from PIL import Image, ImageDraw, ImageFont
import os

font = ImageFont.load_default()
img = Image.new("RGB", (320, 200), (10, 10, 10))
draw = ImageDraw.Draw(img)
draw.text((10, 30), "Loading...", font=font, fill=(255, 255, 255))
draw.rectangle([10, 60, 310, 90], outline=(255, 255, 255))
draw.rectangle([10, 60, 210, 90], fill=(0, 255, 0))
img.save("vault/gui_progress_bar.png")
