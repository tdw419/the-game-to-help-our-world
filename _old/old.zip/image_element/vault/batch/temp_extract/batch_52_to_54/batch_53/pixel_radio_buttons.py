from PIL import Image, ImageDraw, ImageFont
import os

font = ImageFont.load_default()
img = Image.new("RGB", (320, 200), (15, 15, 15))
draw = ImageDraw.Draw(img)
options = ["Option 1", "Option 2", "Option 3"]
selected = 1
for i, label in enumerate(options):
    y = 30 + i * 30
    draw.ellipse([10, y, 30, y + 20], outline=(255, 255, 255), fill=(0, 0, 0))
    if i == selected:
        draw.ellipse([14, y + 4, 26, y + 16], fill=(255, 255, 255))
    draw.text((40, y + 3), label, font=font, fill=(255, 255, 255))
img.save("vault/gui_radio_buttons.png")
