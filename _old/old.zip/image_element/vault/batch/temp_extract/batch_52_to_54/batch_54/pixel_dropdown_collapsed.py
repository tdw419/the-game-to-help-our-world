from PIL import Image, ImageDraw, ImageFont
import os

font = ImageFont.load_default()
img = Image.new("RGB", (320, 200), (20, 20, 20))
draw = ImageDraw.Draw(img)
draw.text((10, 20), "Select category:", font=font, fill=(255, 255, 255))
draw.rectangle([10, 40, 250, 65], fill=(50, 50, 50), outline=(255, 255, 255))
draw.text((15, 45), "Hardware", font=font, fill=(255, 255, 255))
draw.polygon([(230, 48), (240, 48), (235, 58)], fill=(255, 255, 255))  # Dropdown arrow
img.save("vault/gui_dropdown_collapsed.png")
