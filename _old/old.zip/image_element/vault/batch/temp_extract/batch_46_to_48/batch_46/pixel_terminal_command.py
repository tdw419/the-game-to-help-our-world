from PIL import Image, ImageDraw, ImageFont
import os

font = ImageFont.load_default()
img = Image.new("RGB", (320, 200), (0, 0, 0))
draw = ImageDraw.Draw(img)
draw.rectangle([0, 0, 320, 200], fill=(0, 0, 0))
draw.text((10, 10), "$ ls", font=font, fill=(0, 255, 0))
draw.text((10, 30), "file1.txt  file2.png  notes/", font=font, fill=(0, 255, 0))
img.save("vault/gui_terminal_command.png")
