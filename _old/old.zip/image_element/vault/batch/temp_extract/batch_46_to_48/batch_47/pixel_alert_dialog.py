from PIL import Image, ImageDraw, ImageFont
import os

font = ImageFont.load_default()
img = Image.new("RGB", (320, 200), (30, 30, 30))
draw = ImageDraw.Draw(img)
draw.rectangle([60, 60, 260, 140], fill=(255, 255, 255), outline=(255, 0, 0))
draw.text((70, 70), "Are you sure you want to exit?", font=font, fill=(0, 0, 0))
draw.rectangle([80, 110, 130, 130], fill=(200, 200, 200))
draw.text((90, 113), "OK", font=font, fill=(0, 0, 0))
draw.rectangle([180, 110, 230, 130], fill=(200, 200, 200))
draw.text((185, 113), "Cancel", font=font, fill=(0, 0, 0))
img.save("vault/gui_alert_dialog.png")
