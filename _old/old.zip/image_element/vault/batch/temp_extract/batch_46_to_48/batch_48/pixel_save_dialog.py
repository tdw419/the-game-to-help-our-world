from PIL import Image, ImageDraw, ImageFont
import os

font = ImageFont.load_default()
img = Image.new("RGB", (320, 200), (40, 40, 40))
draw = ImageDraw.Draw(img)
draw.rectangle([40, 60, 280, 140], fill=(220, 220, 220), outline=(0, 0, 255))
draw.text((50, 70), "Save file as:", font=font, fill=(0, 0, 0))
draw.rectangle([50, 90, 270, 110], fill=(255, 255, 255), outline=(0, 0, 0))
draw.text((55, 92), "/home/user/doc.txt", font=font, fill=(0, 0, 0))
draw.rectangle([120, 120, 180, 140], fill=(100, 200, 255))
draw.text((135, 123), "Save", font=font, fill=(0, 0, 0))
img.save("vault/gui_save_dialog.png")
