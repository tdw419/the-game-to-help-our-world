import os
import tarfile
import time
import subprocess

INCOMING_DIR = "C:/zion/wwwroot/projects/the_game_to_help_our_world/image_element/vault/batch/incoming_batches"
PROCESSED_DIR = "C:/zion/wwwroot/projects/the_game_to_help_our_world/image_element/vault/batch/processed_batches"
EXTRACT_DIR = "C:/zion/wwwroot/projects/the_game_to_help_our_world/image_element/vault/batch/temp_extract"

os.makedirs(EXTRACT_DIR, exist_ok=True)

def process_batch(file_path):
    print(f"📦 Processing batch: {file_path}")
    with tarfile.open(file_path, "r:gz") as tar:
        tar.extractall(path=EXTRACT_DIR)

    auto_sync_path = os.path.join(EXTRACT_DIR, "auto_sync.py")
    if os.path.exists(auto_sync_path):
        print("⚙️  Running auto_sync.py...")
        subprocess.run(["python", auto_sync_path], check=False)

    dest = os.path.join(PROCESSED_DIR, os.path.basename(file_path))
    if os.path.exists(dest):
        os.remove(dest)  # prevent file move conflict
    os.rename(file_path, dest)
    print(f"✅ Moved to processed: {dest}")

def watch_folder():
    print("👁️ Watching for new batch files...")
    while True:
        for file in os.listdir(INCOMING_DIR):
            if file.endswith(".tar.gz"):
                full_path = os.path.join(INCOMING_DIR, file)
                process_batch(full_path)
        time.sleep(5)

if __name__ == "__main__":
    watch_folder()
