import socket
import json

# Sample pixel update data: [x, y, r, g, b]
updates = [
    [10, 20, 255, 0, 0],   # red pixel at (10,20)
    [100, 100, 0, 255, 0], # green pixel at (100,100)
]

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect(("localhost", 5000))
sock.sendall(json.dumps(updates).encode())
sock.close()
