from flask import Flask, request
import os

app = Flask(__name__)

TARGET_FILE = "canvas.py"

@app.route("/update_canvas_file", methods=["POST"])
def update_canvas_file():
    content = request.get_data(as_text=True)
    try:
        with open(TARGET_FILE, "w", encoding="utf-8") as f:
            f.write(content)
        print("✅ canvas.py updated remotely.")
        return "OK", 200
    except Exception as e:
        print(f"⚠️ Error updating file: {e}")
        return "Error", 500

if __name__ == "__main__":
    app.run(port=5000)  # Run on a separate port to not conflict with pygame
