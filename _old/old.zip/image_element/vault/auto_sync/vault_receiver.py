from flask import Flask, request
import os

app = Flask(__name__)
VAULT_PATH = r"C:\zion\wwwroot\projects\the-game-to-help-our-world\image_element\vault\sync\image_element_vault.png"

@app.route('/upload', methods=['POST'])
def upload_vault():
    file = request.files.get('vault')
    if file:
        file.save(VAULT_PATH)
        return "Vault received and saved", 200
    return "No file uploaded", 400

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000)
