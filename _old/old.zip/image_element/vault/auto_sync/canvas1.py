import pygame
import threading
import time
import random
import socket
import json

# Configurable canvas size
WIDTH, HEIGHT = 256, 256
PIXEL_SIZE = 2  # scale for viewing
WINDOW_WIDTH, WINDOW_HEIGHT = WIDTH * PIXEL_SIZE, HEIGHT * PIXEL_SIZE

# Initialize the pixel matrix
pixel_matrix = [[(0, 0, 0) for _ in range(WIDTH)] for _ in range(HEIGHT)]

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Covenant Canvas")
clock = pygame.time.Clock()

# Function to draw the matrix onto the screen
def draw_canvas():
    for y in range(HEIGHT):
        for x in range(WIDTH):
            color = pixel_matrix[y][x]
            pygame.draw.rect(screen, color, (x * PIXEL_SIZE, y * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE))

# Function to set a pixel value
def set_pixel(x, y, color):
    if 0 <= x < WIDTH and 0 <= y < HEIGHT:
        pixel_matrix[y][x] = color

# Thread to listen for remote pixel updates via socket

def pixel_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('0.0.0.0', 5000))
    server.listen(1)
    print("🟢 Covenant Canvas listening on port 5000...")
    while True:
        conn, addr = server.accept()
        print(f"🔗 Connection from {addr}")
        with conn:
            data = conn.recv(5000)
            if not data:
                continue
            try:
                updates = json.loads(data.decode())
                for update in updates:
                    x, y, r, g, b = update
                    set_pixel(x, y, (r, g, b))
            except Exception as e:
                print("❌ Failed to apply update:", e)

# Launch pixel server in a separate thread
threading.Thread(target=pixel_server, daemon=True).start()

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((0, 0, 0))
    draw_canvas()
    pygame.display.flip()
    clock.tick(30)

pygame.quit()
