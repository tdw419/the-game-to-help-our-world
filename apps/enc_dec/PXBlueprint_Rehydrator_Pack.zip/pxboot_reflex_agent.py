
import hashlib
from PIL import Image

# Expected SHA-256 of the 4-pixel boot block for Ubuntu 25.04
EXPECTED_SHA256 = "1b144b9d64effd66b5332c8a29961d171bc15a03cd7b80f4df3f26b3e888320e"
DIGEST_FILE = "pxboot_ubuntu25_full.pxdigest"

def extract_boot_block(canvas_image):
    """Extracts the RGB values of the first 4 horizontal pixels."""
    boot_bytes = b""
    for x in range(4):
        r, g, b = canvas_image.getpixel((x, 0))
        boot_bytes += bytes([r, g, b])
    return boot_bytes

def check_boot_trigger(canvas_path):
    """Checks the canvas for the boot signature and triggers loading."""
    try:
        img = Image.open(canvas_path)
        boot_block = extract_boot_block(img)
        digest = hashlib.sha256(boot_block).hexdigest()
        print(f"[pxboot_reflex] Canvas SHA256: {digest}")
        if digest == EXPECTED_SHA256:
            print("[pxboot_reflex] ✅ Match found. Booting...")
            with open(DIGEST_FILE, "r", encoding="utf-8") as f:
                content = f.read()
            print("[pxboot_reflex] Loaded .pxdigest:")
            print(content[:500] + "..." if len(content) > 500 else content)
            return content
        else:
            print("[pxboot_reflex] No match. Waiting...")
    except Exception as e:
        print(f"[pxboot_reflex] Error: {e}")

if __name__ == "__main__":
    check_boot_trigger("pxboot_ubuntu25.png")  # Replace with live canvas path in PXOS
