# PXLinux Boot Runtime

This package launches a visual boot simulation for a pixel-based Linux virtual machine.

## Files

- `launch.bat`: Runs the PXScreenVM.
- `pxscreenvm.exe`: Simulated EXE (replace with compiled C++ binary).
- `readme.md`: Usage instructions.

## Next Steps

1. Replace `pxscreenvm.exe` with the compiled C++ binary.
2. Launch with `launch.bat`.
3. Extend EXE to read and execute from pixel memory (e.g., 8.png, pxdigest_boot.png).
