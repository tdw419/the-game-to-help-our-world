# PX Framebuffer Trigger

This package demonstrates direct pixel manipulation outside the browser.

## Files

- `launch.bat`: Starts the screen writer.
- `pxscreen_writer.exe`: Writes a green square and 'HELLO' to your screen.
- `trigger_input.txt`: (Optional) Can be used to queue logic.
- `pxvm_overlay_config.txt`: (Optional) Used for logic injection overlays.
- `readme.md`: This file.

## Usage

1. Extract the ZIP.
2. Double-click `launch.bat`.
3. You should see a black screen flash green, write 'HELLO', and blink red at the corners.

This confirms that you control the framebuffer. Next step: boot logic from 8.png.

